/**
 * User: Clinton Begin
 * Date: Aug 21, 2003
 * Time: 1:41:27 PM
 */
package com.ibatis.db.sqlmap.cache.oscache;

import com.ibatis.db.sqlmap.cache.*;
import com.opensymphony.oscache.base.*;
import com.opensymphony.oscache.general.*;

import java.util.*;

public class OSCacheController implements CacheController {

  private static final GeneralCacheAdministrator cache = new GeneralCacheAdministrator();

  public void flush(CacheModel cacheModel) {
    synchronized (cacheModel) {
      cache.flushGroup(cacheModel.getName());
    }
  }

  public Object getObject(CacheModel cacheModel, Object key) {
    try {
      synchronized (cacheModel) {
        int refreshPeriod = (int)(cacheModel.getFlushIntervalSeconds());
        return cache.getFromCache(key.toString(), refreshPeriod, cacheModel.getName());
      }
    } catch (NeedsRefreshException e) {
      return null;
    }
  }

  public void putObject(CacheModel cacheModel, Object key, Object object) {
    synchronized (cacheModel) {
      cache.putInCache(key.toString(), object, new String[]{cacheModel.getName()});
    }
  }

  public void configure(Properties props) {
  }

}
