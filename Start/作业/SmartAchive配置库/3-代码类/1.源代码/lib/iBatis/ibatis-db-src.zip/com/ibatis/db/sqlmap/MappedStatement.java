package com.ibatis.db.sqlmap;

import com.ibatis.common.beans.*;
import com.ibatis.common.util.*;
import com.ibatis.common.exception.*;
import com.ibatis.db.sqlmap.value.*;
import com.ibatis.db.sqlmap.typehandler.*;
import com.ibatis.db.sqlmap.cache.*;
import com.ibatis.db.jdbc.logging.*;

import javax.sql.*;
import java.sql.*;
import java.util.*;
import java.lang.reflect.*;
import java.io.*;

import org.apache.commons.logging.*;
import net.sf.cglib.*;
import net.sf.cglib.UndeclaredThrowableException;

/** One of the core classes in the iBATIS database framework, the MappedStatement
 * represents an SQL statement that will have a parameter bean and/or result beans
 * mapped to it.
 */
public class MappedStatement {

  private static final Log log = LogFactory.getLog(MappedStatement.class);

  /** Magic number used to set the the maximum number of rows returned to 'all'. */
  public static final int NO_MAXIMUM_RESULTS = -1;
  /** Magic number used to set the the number of rows skipped to 'none'. */
  public static final int NO_SKIPPED_RESULTS = -1;

  private static final String CHECK_SQL_STATEMENT = "Check the SQL statement.";
  private static final String CHECK_PARAMETER_MAP =
      "Check the Parameter Map (or inline parameters).";
  private static final String CHECK_RESULT_MAP = "Check the Result Map.";

  private static final String ELEMENT_TOKEN = "$";

  private List executeListeners = new ArrayList();

  private String resourceName;
  private String name;
  private String sql;
  private String parameterClass;
  private String resultClass;
  private String parameterMapName;
  private String resultMapName;
  private SqlMap sqlMap;
  private boolean isInline;
  private boolean storedProcedure;
  private CacheModel cache;
  private StatementFactory statementFactory;

  //added by bigtimber
  private int rowAmount;

  /** Default constructor. Sets hasDynamicElements, storedProcedure and isInline to
   * false.
   */
  public MappedStatement() {
    storedProcedure = false;
    isInline = false;
  }

  /** Getter for name property
   * @return The name of the object
   */
  public String getName() {
    return name;
  }

  /** Setter for name property
   * @param name The new name of the object
   */
  public void setName(String name) {
    this.name = name;
  }

  /** Getter for resourceName property
   * @return The resourceName of the object
   */
  public String getResourceName() {
    return resourceName;
  }

  /** Setter for resourceName property
   * @param resourceName The new resourceName of the object
   */
  public void setResourceName(String resourceName) {
    this.resourceName = resourceName;
  }

  /** Getter for inline property
   * @return True if statement is to be processed for inline parameters
   */
  public boolean isInline() {
    return isInline;
  }

  /** Setter for inline property
   * @param inline The new inline setting for the object
   */
  public void setInline(boolean inline) {
    isInline = inline;
  }

  /** Returns the SQL statement for the object
   * @param parameterObject The bean containing the parameters for the SQL statement
   * @return The SQL statement
   */
  public String getSql(Object parameterObject) {
    return sql;
  }

  /** Sets the SQL statement for the object
   * @param sql The new SQL statement for the object
   */
  public void setSql(String sql) {
    this.sql = sql;
  }

  /** Getter for the SqlMap object that contains this MappedStatement
   * @return The containing SqlMAp
   */
  public SqlMap getSqlMap() {
    return sqlMap;
  }

  /** Setter for the SqlMap object that contains this MappedStatement
   * @param sqlMap The new SqlMap object
   */
  public void setSqlMap(SqlMap sqlMap) {
    this.sqlMap = sqlMap;
    this.statementFactory = sqlMap.getStatementFactory();
  }

      /** Getter for the class name of the parameter object (if any) related to this
   * MappedStatement.
   * @return The class name
   */
  public String getParameterClass() {
    return parameterClass;
  }

      /** Setter for the class name of the parameter object (if any) related to this
   * MappedStatement.
   * @param parameterClass The new class name
   */
  public void setParameterClass(String parameterClass) {
    this.parameterClass = parameterClass;
  }

  /** Getter for the class name of the result object (if any) related to this
   * MappedStatement.
   * @return The class name
   */
  public String getResultClass() {
    return resultClass;
  }

  /** Setter for the class name of the result object (if any) related to this
   * MappedStatement.
   * @param resultClass The new class name
   */
  public void setResultClass(String resultClass) {
    this.resultClass = resultClass;
  }

  /** Getter for the name of the parameter map object (if any) related to this MappedStatement.
   * @return The name of the parameter map
   */
  public String getParameterMapName() {
    return parameterMapName;
  }

  /** Setter for the name of the parameter map object (if any) related to this MappedStatement.
   * @param parameterMapName The new name of the parameter map
   */
  public void setParameterMapName(String parameterMapName) {
    this.parameterMapName = parameterMapName;
  }

  /** Getter for the name of the result map object (if any) related to this MappedStatement.
   * @return The name of the result map
   */
  public String getResultMapName() {
    return resultMapName;
  }

  /** Setter for the name of the result map object (if any) related to this MappedStatement.
   * @param resultMapName The new name of the result map
   */
  public void setResultMapName(String resultMapName) {
    this.resultMapName = resultMapName;
  }

  /** Getter for the cache object used by this object
   * @return The cache
   */
  public CacheModel getCache() {
    return cache;
  }

  /** Setter for the cache object used by this object
   * @param cache The new cache to use
   */
  public void setCache(CacheModel cache) {
    this.cache = cache;
  }

  /**
   * Getter for the row amount used for other object
   * @return row amount of this amount
   */
  public int getRowAmount() {
    return rowAmount;
  }

  /**
   * Setter for the row amount used for other object
   * @param rowAmount this amount
   */
  public void setRowAmount(int rowAmount) {
    this.rowAmount = rowAmount;
  }

  /** Getter for a flag that indicates that this MappedStatement represents a stored
   * procedure.
   * @return True if the MappedStatement is for a stored procedure
   */
  public boolean isStoredProcedure() {
    return storedProcedure;
  }

  /** Setter for a flag that indicates that this MappedStatement represents a stored
   * procedure.
       * @param storedProcedure True if this MappedStatement is for a stored procedure
   */
  public void setStoredProcedure(boolean storedProcedure) {
    this.storedProcedure = storedProcedure;
  }

  /** Getter for flag that indicates if this MappedStatement is 'dynamic'
   * @return True if the MappedStatement is dynamic
   */
  public boolean isDynamic() {
    return false;
  }

  /** Gets a percentage of successful cache hits achieved
   * @return The percentage of hits (0-1), or null if cache is disabled.
   */
  public Double getDataCacheHitRatio() {
    if (cache != null) {
      return new Double(cache.getHitRatio());
    }
    else {
      return null;
    }
  }

  /** Adds an instance of a class that implements the ExecuteListener interface to a
   * list of objects that will be notified after an execute method is run.
   * @param listener The object to add to the list
   */
  public void addExecuteListener(ExecuteListener listener) {
    executeListeners.add(listener);
  }

  /** Simple toString implementation
   * @return A string that describes the MappedStatement
   */
  public String toString() {
    StringBuffer buffer = new StringBuffer();
    buffer.append("\tMappedStatement: " + getName() + "\n");
    if (getParameterMapName() != null)
      buffer.append(getParameterMapName());
    if (getResultMapName() != null)
      buffer.append(getResultMapName());

    return buffer.toString();
  }

  private void notifyListeners() {
    for (int i = 0, n = executeListeners.size(); i < n; i++) {
      ExecuteListener listener = (ExecuteListener) executeListeners.get(i);
      listener.onExecuteStatement(this);
    }
  }

  private String processDynamicElements(String sql, Object parameterObject) {
    StringTokenizer parser = new StringTokenizer(sql, ELEMENT_TOKEN, true);
    StringBuffer newSql = new StringBuffer();

    String token = null;
    String lastToken = null;
    while (parser.hasMoreTokens()) {
      token = parser.nextToken();

      if (ELEMENT_TOKEN.equals(lastToken)) {
        if (ELEMENT_TOKEN.equals(token)) {
          newSql.append(ELEMENT_TOKEN);
          token = null;
        }
        else {

          Object value = null;
          if (parameterObject != null) {
            if (isSimpleType(parameterObject.getClass())) {
              value = parameterObject;
            }
            else {
              value = StaticBeanProbe.getObject(parameterObject, token);
            }
          }
          if (value != null) {
            newSql.append(String.valueOf(value));
          }

          token = parser.nextToken();
          if (!ELEMENT_TOKEN.equals(token)) {
            throw new SqlMapException(
                "Unterminated inline parameter in mapped statement (" + getName() +
                ").");
          }
          token = null;
        }
      }
      else {
        if (!ELEMENT_TOKEN.equals(token)) {
          newSql.append(token);
        }
      }

      lastToken = token;
    }

    return newSql.toString();
  }

  private PreparedStatement createStatement(Connection conn,
                                            SqlStatement localSql,
                                            Object parameterObject) throws
      SQLException {

    String processedSql = null;
    PreparedStatement ps = null;

    if (localSql.isDynamicElements() && parameterObject != null) {
      processedSql = processDynamicElements(localSql.getSql(), parameterObject);
    }
    else {
      processedSql = localSql.getSql();
    }

    boolean cacheable = !localSql.isDynamicElements() && !isDynamic();

    if (cacheable) {
      ps = statementFactory.getStatement(conn, processedSql);
    }

    if (ps == null) {
      if (isStoredProcedure()) {
        ps = statementFactory.newCallable(conn, processedSql, cacheable);
      }
      else {
        ps = statementFactory.newStatement(conn, processedSql, cacheable);
      }
    }
    return ps;
  }

  private PreparedStatement createStatement(Connection conn,
                                            SqlStatement localSql,
                                            Object parameterObject,
                                            int resultSetType,
                                            int resultSetConcurrency) throws
      SQLException {

    String processedSql = null;
    PreparedStatement ps = null;

    if (localSql.isDynamicElements() && parameterObject != null) {
      processedSql = processDynamicElements(localSql.getSql(), parameterObject);
    }
    else {
      processedSql = localSql.getSql();
    }

    boolean cacheable = !localSql.isDynamicElements() && !isDynamic();

    if (cacheable) {
      ps = statementFactory.getStatement(conn, processedSql);
    }

    if (ps == null) {
      if (isStoredProcedure()) {
        ps = statementFactory.newCallable(conn, processedSql, cacheable);
      }
      else {
        ps = statementFactory.newStatement(conn, processedSql, cacheable,
                                           resultSetType, resultSetConcurrency);
      }
    }
    return ps;
  }

  protected void assertParameterClass(Object parameterObject) throws
      SQLException {
    if (parameterClass != null) {
      if (!isDynamic() && parameterObject == null) {
        throw new SQLException("The parameter object passed to '" + getName() +
                               "' must be an instance of type '" +
                               parameterClass +
            "', but was NULL.  Only dynamic mapped statements allow null parameter objects.");
      }
      else {
        String parameterObjectType = parameterObject.getClass().getName();
        if (!parameterClass.equals(parameterObjectType)) {
          throw new SQLException("The parameter object passed to '" + getName() +
                                 "' must be of type '" + parameterClass +
                                 "', but was of type '" + parameterObjectType +
                                 "'.");
        }
      }
    }
  }

  /** Executes an SQL statement that could change the database.
   * Listeners are notified at the end of this method.
   * @param conn The connection to use to execute the update
   * @param parameterObject The parameter object that will be mapped to the SQL
   * @throws SQLException If an exception occurs in the database
   * @return The number of rows changed
   */
  public int executeUpdate(Connection conn, Object parameterObject) throws
      SQLException {

    if (log.isDebugEnabled()) {
      log.debug("executeUpdate: " + name);
      conn = ConnectionLogProxy.newInstance(conn);
    }

    ErrorField errorField = new ErrorField();

    assertParameterClass(parameterObject);
    SqlStatement localSql = getSqlStatement(parameterObject);

    boolean isBatch = sqlMap.isInsideBatch();

    int rows = -1;

    PreparedStatement ps = null;

    String errorMessage = CHECK_SQL_STATEMENT;
    try {

      if (isBatch) {
        ps = sqlMap.getStatementFromBatch(this);
        if (ps == null) {
          ps = createStatement(conn, localSql, parameterObject);
          sqlMap.registerStatementWithBatch(this, ps);
        }
      }
      else {
        sqlMap.incrementExecutionThrottle(conn);
        ps = createStatement(conn, localSql, parameterObject);
      }

      errorMessage = CHECK_PARAMETER_MAP;
      applyParameterMap(localSql, ps, parameterObject, errorField);
      errorField.errorField = null;

      errorMessage = CHECK_SQL_STATEMENT;

      if (isBatch) {
        ps.addBatch();

      }
      else {
        rows = ps.executeUpdate();

      }

    }
    catch (Throwable t) {
      t = unwrapProxyException(t);
      String msg = "";
      if (errorField.errorField != null) {
        msg = "Error executing '" + name + "' in '" + resourceName + "'. " +
            errorMessage + "  Check the '" + errorField + "' property. Cause: " +
            t;
      }
      else {
        msg = "Error executing '" + name + "' in '" + resourceName + "'. " +
            errorMessage + " Cause: " + t;
      }
      if (log.isErrorEnabled()) {
        log.error(msg, t.fillInStackTrace());
      }
      if (t instanceof SQLException) {
        throw (SQLException) t;
      }
      else {
        throw new SQLException(msg);
      }
    }
    finally {
      if (!isBatch) {
        closeStatement(ps);
        sqlMap.decrementExecutionThrottle(conn);
      }
    }

    notifyListeners();

    return rows;
  }

  /** Runs a query with a custom object that gets a chance to deal with each row as it
   * is processed.
   * @param conn The connection used to execute the query
   * @param parameterObject The parameter object mapped the the statement
   * @param rowHandler The custom row handler object
   * @throws SQLException If an exception occurs in the database
   */
  public void executeQueryWithRowHandler(Connection conn,
                                         Object parameterObject,
                                         RowHandler rowHandler) throws
      SQLException {

    if (rowHandler == null) {
      throw new SQLException(
          "A null RowHandler was passed to executeQueryWithRowHandler.");
    }
    assertParameterClass(parameterObject);
    SqlStatement localSql = getSqlStatement(parameterObject);
    runQueryForList(localSql, conn, parameterObject, NO_SKIPPED_RESULTS,
                    NO_MAXIMUM_RESULTS, rowHandler);

  }

  /** Executes the SQL and retuns all rows selected in a map that is keyed on the property named
   * in the keyProperty parameter.  The value at each key will be the entire result object.
   * @param conn The connection used to execute the statement
   * @param parameterObject The object used to set the parameters in the SQL
   * @param keyProperty The property of the result object to be used as the key
   * @throws SQLException If an exception occurs in the database
   * @return A Map of beans containing the rows keyed by keyProperty
   */
  public Map executeQueryForMap(Connection conn, Object parameterObject,
                                String keyProperty) throws SQLException {
    return executeQueryForMap(conn, parameterObject, keyProperty, null);
  }

  /** Executes the SQL and retuns all rows selected in a map that is keyed on the property named
   * in the keyProperty parameter.  The value at each key will be the value of the property specified
   * in the valueProperty parameter.  If valueProperty is null, the entire result object will be entered.
   * @param conn The connection used to execute the statement
   * @param parameterObject The object used to set the parameters in the SQL
   * @param keyProperty The property of the result object to be used as the key
   * @param valueProperty The property of the result object to be used as the value (or null)
   * @throws SQLException If an exception occurs in the database
   * @return A Map of beans containing the rows keyed by keyProperty
   */
  public Map executeQueryForMap(Connection conn, Object parameterObject,
                                String keyProperty, String valueProperty) throws
      SQLException {

    assertParameterClass(parameterObject);
    SqlStatement localSql = getSqlStatement(parameterObject);

    Map map = null;

    if (cache == null) {
      map = runQueryForMap(conn, parameterObject, keyProperty, valueProperty);
    }
    else {
      ParameterMap parameterMap = localSql.getParameterMap();

      CacheKey key;
      if (parameterMap != null) {
        key = new CacheKey(name, localSql.getSql(), parameterObject,
                           parameterMap.getPropertyNameArray(),
                           NO_SKIPPED_RESULTS, NO_MAXIMUM_RESULTS,
                           CacheKey.MAP_TYPE);
      }
      else {
        key = new CacheKey(name, localSql.getSql(), parameterObject,
                           new String[0], NO_SKIPPED_RESULTS,
                           NO_MAXIMUM_RESULTS, CacheKey.MAP_TYPE);
      }

      map = (Map) cache.getObject(key);
      if (map == null) {
        map = runQueryForMap(conn, parameterObject, keyProperty, valueProperty);
        cache.putObject(key, map);
      }
    }

    return map;

  }

  private Map runQueryForMap(Connection conn, Object parameterObject,
                             String keyProperty, String valueProperty) throws
      SQLException {
    Map map = new HashMap();
    List list = executeQueryForList(conn, parameterObject);
    for (int i = 0, n = list.size(); i < n; i++) {
      Object object = list.get(i);
      if (object != null) {
        Object key = StaticBeanProbe.getObject(object, keyProperty);
        Object value = object;
        if (valueProperty != null) {
          value = StaticBeanProbe.getObject(object, valueProperty);
        }
        map.put(key, value);
      }
    }
    return map;
  }

  /** Executes the SQL and retuns a subset of the results in a dynamic PaginatedList that can be used to
   * automatically scroll through results from a database table.
   * @param parameterObject The object used to set the parameters in the SQL
   * @param pageSize The maximum number of objects to store in each page
   * @throws SQLException If an exception occurs in the database
   * @return A PaginatedList of beans containing the rows
   */
  public PaginatedList executeQueryForPaginatedList(Object parameterObject,
      int pageSize) throws SQLException {
    if (sqlMap.getCurrentDataSource() == null) {
      throw new SQLException("Error in executeQueryForPaginatedList().  SqlMap.getCurrentDataSource() returned null.  " +
                             "A DataSource must be set in the SqlMap for PaginatedList support.  Try SqlMap.addDataSource() and " +
                             "SqlMap.setCurrentDataSource().");
    }
    return new PaginatedDataList(this, parameterObject, pageSize);
  }

      /** Executes the SQL and retuns all rows selected. This is exactly the same as
   * calling executeQueryForList(conn, parameterObject, NO_SKIPPED_RESULTS, NO_MAXIMUM_RESULTS)
   * because that is what it does.
   * @param conn The connection used to execute the statement
   * @param parameterObject The object used to set the parameters in the SQL
   * @throws SQLException If an exception occurs in the database
   * @return A List of beans containing the rows
   */
  public List executeQueryForList(Connection conn, Object parameterObject) throws
      SQLException {
    return executeQueryForList(conn, parameterObject, NO_SKIPPED_RESULTS,
                               NO_MAXIMUM_RESULTS);
  }

  /** Executes the SQL and retuns a subset of the rows selected.
   * @param conn The connection used to execute the statement
   * @param parameterObject The object used to set the parameters in the SQL
   * @param skipResults The number of rows to skip
   * @param maxResults The number of rows to return
   * @throws SQLException If an exception occurs in the database
   * @return A List of beans containing the rows
   */
  public List executeQueryForList(Connection conn, Object parameterObject,
                                  int skipResults, int maxResults) throws
      SQLException {

    assertParameterClass(parameterObject);
    SqlStatement localSql = getSqlStatement(parameterObject);

    List list = null;

    if (cache == null) {
      list = runQueryForList(localSql, conn, parameterObject, skipResults,
                             maxResults, null);
    }
    else {
      ParameterMap parameterMap = localSql.getParameterMap();

      CacheKey key;
      if (parameterMap != null) {
        key = new CacheKey(name, localSql.getSql(), parameterObject,
                           parameterMap.getPropertyNameArray(), skipResults,
                           maxResults, CacheKey.LIST_TYPE);
      }
      else {
        key = new CacheKey(name, localSql.getSql(), parameterObject,
                           new String[0], skipResults, maxResults,
                           CacheKey.LIST_TYPE);
      }

      list = (List) cache.getObject(key);
      if (list == null) {
        list = runQueryForList(localSql, conn, parameterObject, skipResults,
                               maxResults, null);
        cache.putObject(key, list);
      }

    }

    return list;
  }

  private List runQueryForList(SqlStatement localSql, Connection conn,
                               Object parameterObject, int skipResults,
                               int maxResults, RowHandler rowHandler) throws
      SQLException {

    if (log.isDebugEnabled()) {
      log.debug("executeQueryForList: " + name);
      conn = ConnectionLogProxy.newInstance(conn);
    }

    ErrorField errorField = new ErrorField();

    List list;
    if (rowHandler == null) {
      list = new ArrayList();
    }
    else {
      list = null;
    }

    ResultSet rs = null;

    PreparedStatement ps = null;

    String errorMessage = CHECK_SQL_STATEMENT;
    try {
      sqlMap.incrementExecutionThrottle(conn);
      ps = createStatement(conn, localSql, parameterObject,
                           ResultSet.TYPE_SCROLL_INSENSITIVE,
                           ResultSet.CONCUR_READ_ONLY);

      if (sqlMap.isDriverHintsEnabled() && maxResults != NO_MAXIMUM_RESULTS &&
          skipResults != NO_SKIPPED_RESULTS) {
        ps.setFetchSize(maxResults + skipResults);
        ps.setMaxRows(maxResults + skipResults);
      }

      errorMessage = CHECK_PARAMETER_MAP;
      applyParameterMap(localSql, ps, parameterObject, errorField);
      errorField.errorField = null;

      errorMessage = CHECK_SQL_STATEMENT;
      rs = ps.executeQuery();

      // skip results
//      for (int i = 0; i < skipResults; i++) {
//        if (!rs.next()) {
//          break;
//        }
//      }
      if (skipResults > 0) {
        rs.absolute(skipResults);
      }

      errorMessage = CHECK_RESULT_MAP;
      int n = 0;

      if (rowHandler == null) {
        while ( (maxResults == NO_MAXIMUM_RESULTS || n < maxResults) && rs.next()) {
          Object object = applyResultMap(conn, rs, null, errorField);
          list.add(object);
          n++;
        }

        rs.last();
        rowAmount = rs.getRow();

        errorField.errorField = null;
      }
      else {
        while ( (maxResults == NO_MAXIMUM_RESULTS || n < maxResults) && rs.next()) {
          Object object = applyResultMap(conn, rs, null, errorField);
          rowHandler.handleRow(object);
          n++;
        }

        rs.last();
        rowAmount = rs.getRow();

        errorField.errorField = null;
      }

    }
    catch (Throwable t) {
      t = unwrapProxyException(t);
      String msg = "";
      if (errorField.errorField != null) {
        msg = "Error executing '" + name + "' in '" + resourceName + "'. " +
            errorMessage + "  Check the '" + errorField + "' property. Cause: " +
            t;
      }
      else {
        msg = "Error executing '" + name + "' in '" + resourceName + "'. " +
            errorMessage + " Cause: " + t;
      }
      if (log.isErrorEnabled()) {
        log.error(msg, t.fillInStackTrace());
      }
      if (t instanceof SQLException) {
        throw (SQLException) t;
      }
      else {
        throw new SQLException(msg);
      }
    }
    finally {
      closeResultSet(rs);
      closeStatement(ps);
      sqlMap.decrementExecutionThrottle(conn);
    }

    notifyListeners();

    return list;
  }

  /** Executes an SQL statement that returns a single row as an Object.
   * @param conn The connection used to execute the statement
   * @param parameterObject The object used to set the parameters in the SQL
   * @throws SQLException If an exception occurs in the database
   * @return The object
   */
  public Object executeQueryForObject(Connection conn, Object parameterObject) throws
      SQLException {
    return executeQueryForObject(conn, parameterObject, null);
  }

  /** Executes an SQL statement that returns a single row as an Object of the type of
   * the resultObject passed in as a parameter. NOTE: The object returned may or may
   * not be the same instance of the object passed in.
   * @param conn The connection used to execute the statement
   * @param parameterObject The object used to set the parameters in the SQL
   * @param resultObject The
   * @throws SQLException If an exception occurs in the database
   * @return The object
   */
  public Object executeQueryForObject(Connection conn, Object parameterObject,
                                      Object resultObject) throws SQLException {
    assertParameterClass(parameterObject);
    SqlStatement localSql = getSqlStatement(parameterObject);

    Object object = null;

    if (cache == null) {
      object = runQueryForObject(localSql, conn, parameterObject, resultObject);
    }
    else {
      ParameterMap parameterMap = localSql.getParameterMap();

      CacheKey key;
      if (parameterMap != null) {
        key = new CacheKey(name, localSql.getSql(), parameterObject,
                           parameterMap.getPropertyNameArray(),
                           NO_SKIPPED_RESULTS, NO_MAXIMUM_RESULTS,
                           CacheKey.OBJECT_TYPE);
      }
      else {
        key = new CacheKey(name, localSql.getSql(), parameterObject,
                           new String[0], NO_SKIPPED_RESULTS,
                           NO_MAXIMUM_RESULTS, CacheKey.OBJECT_TYPE);
      }

      object = cache.getObject(key);
      if (object == null) {
        object = runQueryForObject(localSql, conn, parameterObject,
                                   resultObject);
        cache.putObject(key, object);
      }

    }

    return object;

  }

  private Object runQueryForObject(SqlStatement localSql, Connection conn,
                                   Object parameterObject, Object resultObject) throws
      SQLException {

    if (log.isDebugEnabled()) {
      log.debug("executeQueryForObject: " + name);
      conn = ConnectionLogProxy.newInstance(conn);
    }

    ErrorField errorField = new ErrorField();

    Object object = null;

    PreparedStatement ps = null;
    ResultSet rs = null;

    String errorMessage = CHECK_SQL_STATEMENT;
    try {

      sqlMap.incrementExecutionThrottle(conn);
      ps = createStatement(conn, localSql, parameterObject);

      errorMessage = CHECK_PARAMETER_MAP;
      applyParameterMap(localSql, ps, parameterObject, errorField);
      errorField.errorField = null;

      errorMessage = CHECK_SQL_STATEMENT;

      rs = ps.executeQuery();

      errorMessage = CHECK_RESULT_MAP;
      while (rs.next()) {
        object = applyResultMap(conn, rs, resultObject, errorField);
      }
      errorField.errorField = null;
    }
    catch (Throwable t) {
      t = unwrapProxyException(t);
      String msg = "";
      if (errorField.errorField != null) {
        msg = "Error executing '" + name + "' in '" + resourceName + "'. " +
            errorMessage + "  Check the '" + errorField + "' property. Cause: " +
            t;
      }
      else {
        msg = "Error executing '" + name + "' in '" + resourceName + "'. " +
            errorMessage + " Cause: " + t;
      }
      if (log.isErrorEnabled()) {
        log.error(msg, t.fillInStackTrace());
      }
      if (t instanceof SQLException) {
        throw (SQLException) t;
      }
      else {
        throw new SQLException(msg);
      }
    }
    finally {
      closeResultSet(rs);
      closeStatement(ps);
      sqlMap.decrementExecutionThrottle(conn);
    }

    notifyListeners();

    return object;
  }

  private Throwable unwrapProxyException(Throwable t) {
    while (t instanceof UndeclaredThrowableException) {
      t = ( (UndeclaredThrowableException) t).getCause();
      while (t instanceof InvocationTargetException) {
        t = ( (InvocationTargetException) t).getTargetException();
      }
    }
    return t;
  }

  private void applyParameterMap(SqlStatement localSql, PreparedStatement ps,
                                 Object parameterObject, ErrorField errorField) throws
      SQLException {
    Object localParameterObject = parameterObject;

    if (getParameterMapName() != null) {
      ParameterMap map = localSql.getParameterMap();

      if (isStoredProcedure() && ps instanceof CallableStatement) {
        CallableStatement cs = (CallableStatement) ps;
        int n = map.getCountOfPropertyMappings();
        for (int i = 0; i < n; i++) {
          ParameterMapping mapping = map.getParameterMapping(i);
          if (mapping.isOutputParameter()) {
            cs.registerOutParameter(i + 1, mapping.getJdbcType());
          }
        }
      }

      if (localParameterObject != null
          && isSimpleType(localParameterObject.getClass())) {
        localParameterObject = new ObjectValue(localParameterObject);
      }

      int count = map.getCountOfPropertyMappings();
      for (int i = 0; i < count; i++) {
        setParameter(ps, i + 1, localParameterObject, map, errorField);
      }
      errorField.errorField = null;
    }
  }

  protected SqlStatement getSqlStatement(Object parameterObject) throws
      SQLException {
    String sql = getSql(parameterObject);
    SqlStatement sqlStatement = new SqlStatement();
    sqlStatement.setSql(sql);
    if (getParameterMapName() != null) {
      sqlStatement.setParameterMap(getSqlMap().getParameterMap(
          getParameterMapName()));
    }
    return sqlStatement;
  }

  private boolean isEqualToNullValue(String nullValue, Object realValue) {
    boolean result = false;
    Class propertyType = realValue.getClass();
    if (nullValue != null) {
      TypeHandler handler = TypeHandlerFactory.getTypeHandler(propertyType);
      if (handler != null) {
        result = handler.isEqualToNullValue(nullValue, realValue);
      }
    }
    return result;
  }

  private static boolean isSimpleType(Class type) {
    boolean result = false;
    if (type != null) {
      TypeHandler handler = TypeHandlerFactory.getTypeHandler(type);
      if (handler != null) {
        result = handler.isSimpleType();
      }
    }
    return result;
  }

  private void setParameter(PreparedStatement ps, int index, Object object,
                            ParameterMap map, ErrorField errorField) throws
      SQLException {

    ParameterMapping mapping = map.getParameterMapping(index - 1);

    String prop = mapping.getPropertyName();

    errorField.errorField = prop;

    Object value = null;

    value = StaticBeanProbe.getObject(object, prop);

    String nullValue = mapping.getNullValue();

    if (value == null || isEqualToNullValue(nullValue, value)) {
      setNullParameter(mapping, index, ps);
    }
    else {
      TypeHandler typeHandler = null;
      Class propertyType = null;
      synchronized (mapping) {
        typeHandler = mapping.getTypeHandler();
        propertyType = mapping.getPropertyType();
        if (propertyType == null) {
          propertyType = value.getClass();
          typeHandler = TypeHandlerFactory.getTypeHandler(propertyType);
          mapping.setTypeHandler(typeHandler);
          mapping.setPropertyType(propertyType);
        }
      }

      if (typeHandler != null) {
        typeHandler.setParameter(mapping, ps, index, value);
      }
      else {
        typeHandler = TypeHandlerFactory.getTypeHandler(Object.class);
        typeHandler.setParameter(mapping, ps, index, value);
      }
    }

  }

  private void setNullParameter(ParameterMapping mapping, int index,
                                PreparedStatement ps) throws SQLException {
    int type = mapping.getJdbcType();
    if (type != TypeRegistry.UNKNOWN_TYPE) {
      ps.setNull(index, type);
    }
    else {
      ps.setNull(index, Types.OTHER);
    }
  }

  private Object applyResultMap(Connection conn, ResultSet rs,
                                Object resultObject, ErrorField errorField) throws
      SQLException {
    Object object = resultObject;
    String typeName = null;

    if (getResultMapName() != null) {
      ResultMap map = getSqlMap().getResultMap(getResultMapName());
      typeName = map.getClassName();
      if (object == null) {
        object = instantiate(map.getClassName());
      }

      Iterator names = map.getMappedPropertyNames();

      while (names.hasNext()) {
        String propertyName = (String) names.next();
        ResultMapping mapping = map.getResultMapping(propertyName);
        setBeanProperty(mapping, object, conn, rs, errorField);
      }
    }
    else {
      if (resultClass != null) {
        typeName = resultClass;
        if (object == null) {
          object = instantiate(resultClass);
        }

        if (object instanceof BaseValue) {
          ResultMapping mapping = new ResultMapping();
          mapping.setPropertyName("value");
          mapping.setColumnName("VALUE");
          mapping.setColumnIndex(new Integer(1));
          setBeanProperty(mapping, object, conn, rs, errorField);
        }
        else if (object instanceof Map) {
          ResultSetMetaData rsmd = rs.getMetaData();
          for (int i = 0, n = rsmd.getColumnCount(); i < n; i++) {
            String columnName = rsmd.getColumnLabel(i + 1);
            ( (Map) object).put(columnName, rs.getObject(i + 1));
          }
        }
        else {
          autoMapResultSet(conn, rs, object, errorField);
        }
      }
    }

    if (typeName != null
        && object != null
        && object instanceof BaseValue
        && !object.getClass().getName().equals(typeName)) {
      object = StaticBeanProbe.getObject(object, "value");
    }

    return object;
  }

  private ResultSetAutoMapper resultSetAutoMapper = null;
  private void autoMapResultSet(Connection conn, ResultSet rs, Object object,
                                ErrorField errorField) throws SQLException {
    synchronized (this) {
      if (resultSetAutoMapper == null) {
        resultSetAutoMapper = new ResultSetAutoMapper(rs, object);
      }
    }
    resultSetAutoMapper.autoMapResultSet(this, conn, rs, object, errorField);
  }

  private void setBeanProperty(ResultMapping mapping, Object object,
                               Connection conn, ResultSet rs,
                               ErrorField errorField) throws SQLException {

    errorField.errorField = mapping.getPropertyName();

    TypeHandler typeHandler = null;
    Class propertyType = null;
    synchronized (mapping) {
      typeHandler = mapping.getTypeHandler();
      propertyType = mapping.getPropertyType();
      if (propertyType == null) {
        propertyType = StaticBeanProbe.getPropertyTypeForSetter(object,
            mapping.getPropertyName());
        typeHandler = TypeHandlerFactory.getTypeHandler(propertyType);
        mapping.setTypeHandler(typeHandler);
        mapping.setPropertyType(propertyType);
      }
    }

    String mappedStatementName = mapping.getStatementName();
    if (mappedStatementName == null && typeHandler != null) {
      typeHandler.setBeanProperty(mapping, rs, object);
    }
    else {
      if (mappedStatementName == null) {
        throw new SQLException("Could not apply result map to property named '" +
                               mapping.getPropertyName() +
                               "'.  Unknown type encountered (" + propertyType + ").  Please use a supported type or associate a mapped-statement with this type.");
      }
      else {
        MappedStatement statement = getSqlMap().getMappedStatement(
            mappedStatementName);
        String paramString = mapping.getColumnName();
        Object key = null;
        boolean wasNull = false;

        if (paramString.startsWith("{")) {
          Map keyMap = new HashMap();
          key = keyMap;
          StringTokenizer parser = new StringTokenizer(paramString, "{=,}", false);
          if (parser.countTokens() % 2 != 0) {
            throw new SQLException("Invalid composite key string format.  It must be: {property1=column1,property2=column2,...}");
          }
          while (!wasNull && parser.hasMoreTokens()) {
            keyMap.put(parser.nextToken(), rs.getObject(parser.nextToken()));
            wasNull = rs.wasNull();
          }
        }
        else {
          key = new ObjectValue(rs.getObject(paramString));
          wasNull = rs.wasNull();
        }

        if (wasNull) {
          StaticBeanProbe.setObject(object, mapping.getPropertyName(), null);
        }
        else {
          if (java.util.List.class == propertyType ||
              java.util.Collection.class == propertyType) {
            statement.assertParameterClass(object);
            List values = null;
            DataSource ds = sqlMap.getCurrentDataSource();
            if (mapping.isLazyLoad() && ds != null) {
              values = LazyLoadList.newInstance(ds, statement, key);
            }
            else {
              values = statement.runQueryForList(statement.getSqlStatement(key),
                                                 conn, key, NO_SKIPPED_RESULTS,
                                                 NO_MAXIMUM_RESULTS, null);
            }
            StaticBeanProbe.setObject(object, mapping.getPropertyName(), values);
          }
          else {
            statement.assertParameterClass(object);
            Object value = statement.runQueryForObject(statement.
                getSqlStatement(key), conn, key, null);
            StaticBeanProbe.setObject(object, mapping.getPropertyName(), value);
          }
        }
      }
    }
  }

  private void closeStatement(PreparedStatement ps) {
    if (ps != null) {
      statementFactory.releaseStatement(ps);
    }
  }

  private void closeResultSet(ResultSet rs) {
    if (rs != null) {
      try {
        rs.close();
      }
      catch (SQLException e) {
        // ignore
      }
    }
  }

  private Object instantiate(String className) {
    Object object = null;

    try {
      TypeHandler handler = TypeHandlerFactory.getTypeHandler(Class.forName(
          className));
      if (handler != null) {
        object = handler.instantiateValue();
      }
      else {
        Class clazz = Class.forName(className);
        object = clazz.newInstance();
      }
    }
    catch (Exception e) {
      throw new SqlMapException("Could not create instance for class named '" +
                                className + "'. Cause:  " + e.toString(), e);
    }

    return object;
  }

  /**
   * A key for results in the cache.
   */
  private static class CacheKey
      implements Serializable {

    public static final int OBJECT_TYPE = 1;
    public static final int LIST_TYPE = 2;
    public static final int MAP_TYPE = 3;

    private String[] properties;
    private Object parameter;
    private String sql;
    private String statementName;
    private int maxResults;
    private int skipRecords;
    private int type;

    private String hashCodeString;
    private int hashCode;

    public CacheKey(String statementName, String sql, Object parameter,
                    String[] properties, int skipRecords, int maxResults,
                    int type) {

      this.statementName = statementName;
      this.sql = sql;
      this.parameter = parameter;
      this.properties = properties;
      this.skipRecords = skipRecords;
      this.maxResults = maxResults;
      this.type = type;
      this.hashCode = generateHashCode();
      this.hashCodeString = String.valueOf(hashCode);
    }

    public boolean equals(Object o) {
      if (this == o)
        return true;
      if (! (o instanceof CacheKey))
        return false;

      final CacheKey cacheKey = (CacheKey) o;

      if (maxResults != cacheKey.maxResults)
        return false;
      if (skipRecords != cacheKey.skipRecords)
        return false;
      if (type != cacheKey.type)
        return false;
      if (parameter instanceof BaseValue) {
        if (parameter != null ? !parameter.equals(cacheKey.parameter) :
            cacheKey.parameter != null)
          return false;
      }
      else if (parameter instanceof Map) {
//        if (parameter != null ? !parameter.equals(cacheKey.parameter) : cacheKey.parameter != null) return false;
        if (hashCode != cacheKey.hashCode)
          return false;
      }
      else if (parameter != null && isSimpleType(parameter.getClass())) {
        if (parameter != null ? !parameter.equals(cacheKey.parameter) :
            cacheKey.parameter != null)
          return false;
      }
      else {
//        if (parameter != null ? !StaticBeanProbe.beanEquals(parameter, cacheKey.parameter, properties) : cacheKey.parameter != null) return false;
        if (hashCode != cacheKey.hashCode)
          return false;
      }
      if (sql != null ? !sql.equals(cacheKey.sql) : cacheKey.sql != null)
        return false;

      return true;
    }

    public int hashCode() {
      if (sql.indexOf('$') > -1) {
        synchronized (sql) {
          generateHashCode();
          return hashCode;
        }
      }
      else {
        return hashCode;
      }
    }

    public String toString() {
      return hashCodeString;
    }

    private int generateHashCode() {
      int result;

      if (parameter instanceof BaseValue) {
        result = (parameter != null ? parameter.hashCode() : 0);
      }
      else if (parameter instanceof Map) {
        result = (parameter != null ? parameter.hashCode() : 0);
      }
      else if (parameter != null && isSimpleType(parameter.getClass())) {
        result = (parameter != null ? parameter.hashCode() : 0);
      }
      else {
        result = (parameter != null ?
                  StaticBeanProbe.beanHashCode(parameter, properties) : 0);
      }
      result = 29 * result +
          (statementName != null ? statementName.hashCode() : 0);
      result = 29 * result + (sql != null ? sql.hashCode() : 0);
      result = 29 * result + maxResults;
      result = 29 * result + skipRecords;
      result = 29 * result + type;
      return result;
    }
  }

  /**
   * This is a value holder class for the very limited use of passing
   * error information around.
   *
   * It is not fully encapsulated to increase performance, however
   * being a private inner class, it should be relatively safe.
   */
  private static class ErrorField {
    public String errorField;

    public String toString() {
      return errorField;
    }
  }

  /**
   * Class for automatically mapping resultsets to columns,
   * and caching the relevant mappings.
   */
  private static class ResultSetAutoMapper {

    private List mappings = new ArrayList();

    public ResultSetAutoMapper(ResultSet rs, Object object) {

      try {
        String[] propertyNames = StaticBeanProbe.getWriteablePropertyNames(
            object);

        Map propertyMap = new HashMap();
        for (int i = 0; i < propertyNames.length; i++) {
          propertyMap.put(propertyNames[i].toUpperCase(), propertyNames[i]);
        }

        ResultSetMetaData rsmd = rs.getMetaData();
        for (int i = 0, n = rsmd.getColumnCount(); i < n; i++) {
          String columnName = rsmd.getColumnLabel(i + 1);
          String upperColumnName = columnName.toUpperCase();
          String matchedProp = (String) propertyMap.get(upperColumnName);
          if (matchedProp != null) {
            ResultMapping resultMapping = new ResultMapping();
            resultMapping.setPropertyName(matchedProp);
            resultMapping.setColumnName(columnName);
            mappings.add(resultMapping);
          }
        }
      }
      catch (SQLException e) {
        throw new NestedRuntimeException("Error automapping columns. Cause: " +
                                         e);
      }

    }

    public void autoMapResultSet(MappedStatement ms, Connection conn,
                                 ResultSet rs, Object object,
                                 ErrorField errorField) throws SQLException {
      for (int i = 0, n = mappings.size(); i < n; i++) {
        ms.setBeanProperty( (ResultMapping) mappings.get(i), object, conn, rs,
                           errorField);
      }
    }
  }

}