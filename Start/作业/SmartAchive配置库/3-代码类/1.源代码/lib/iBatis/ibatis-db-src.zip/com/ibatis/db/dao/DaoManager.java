/*
 * DaoManager.java
 *
 * Created on December 19, 2001, 5:38 PM
 */

package com.ibatis.db.dao;

import java.util.*;
import java.io.*;

/**
 * DaoManager is a facade class that provides convenient access to the rest
 * of the DAO framework.  It's primary responsibilities include:
 * <p>
 *   - Reading configuration information and initializing the framework <br>
 *   - Managing different contexts for different configurations <br>
 *   - Providing access to Dao implementation <br>
 *   - Providing access to the DaoTransaction pool for transactions <br>
 * <p>
 * Example DaoManager Usage:
 * <p>
 * DaoManager.configure (Resources.getResourceAsReader("com/ibatis/example/dao.xml")); <br>
 * DaoManager daoManager = DaoManager.getInstance ("PetStore"); <br>
 * CategoryDao catDao = (CategoryDao) daoManager.getDao("Category"); <br>
 * DaoTransaction trans = daoManager.getTransaction(); <br>
 * ArrayList categoryList = catDao.getCategoryList (trans); <br>
 * daoManager.releaseTransaction (trans); <br>
 *
 * <!-- (See the end of the source file for an examples configuration XML file.) -->
 *
 * @author  clinton_begin
 */
public class DaoManager {

  protected static final String DEFAULT_CONTEXT_NAME = "__DEFAULT__CONTEXT__NAME";
  protected static final Map daoManagerReverseLookup = new HashMap();
  protected static final Map daoContextMap = new HashMap();

  protected String name = null;
  protected boolean isDefaultContext = false;
  protected DaoTransactionPool transactionPool = null;
  protected Properties extraProperties = new Properties();
  protected ThreadLocal localTransaction = new ThreadLocal();
  protected Map daoClassMap = new HashMap();
  protected Map daoMap = new HashMap();

  protected DaoManager() {
  }

  // STATICS

  public static void configure(InputStream in) throws DaoException {
    configure(new InputStreamReader(in));
  }

  public static void configure(Reader reader) throws DaoException {
    daoContextMap.clear();
    daoManagerReverseLookup.clear();

    DaoManager[] daoManagers = XmlDaoManagerBuilder.buildDaoManagers(reader);

    for (int i = 0; i < daoManagers.length; i++) {
      DaoManager daoManager = daoManagers[i];
      registerDaoManager(daoManager.getName(), daoManager);
      if (daoManager.isDefault()) {
        if (DaoManager.getInstance() == null) {
          DaoManager.registerDaoManager(DEFAULT_CONTEXT_NAME, daoManager);
        } else {
          throw new DaoException("Error while configuring DaoManager.  There can be only one default DAO context.");
        }
      }
      daoManager.initializeDaoObjects();
    }
  }

  public static DaoManager newInstance() {
    return new DaoManager();
  }

  public static Iterator getInstanceNames() {
    Set set = new TreeSet();
    Iterator i = daoContextMap.keySet().iterator();
    while (i.hasNext()) {
      String name = (String) i.next();
      if (!name.equals(DaoManager.DEFAULT_CONTEXT_NAME)) {
        set.add(name);
      }
    }
    return set.iterator();
  }

  public static DaoManager getInstance() {
    return (DaoManager) daoContextMap.get(DEFAULT_CONTEXT_NAME);
  }

  public static DaoManager getInstance(String contextName) {
    return (DaoManager) daoContextMap.get(contextName);
  }

  public static DaoManager getInstance(Dao dao) {
    return (DaoManager) daoManagerReverseLookup.get(dao);
  }

  public Dao getDao(String name) {
    return (Dao) daoMap.get(name);
  }

  public void addDaoClass(String name, String daoClass) {
    daoClassMap.put(name, daoClass);
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public boolean isDefault() {
    return isDefaultContext;
  }

  public void setDefault(boolean defaultContext) {
    isDefaultContext = defaultContext;
  }

  public String getExtraProperty(String name) {
    return extraProperties.getProperty(name);
  }

  public void setExtraProperty(String name, String value) {
    extraProperties.setProperty(name, value);
  }

  public DaoTransactionPool getTransactionPool() {
    return transactionPool;
  }

  public void setTransactionPool(DaoTransactionPool transactionPool) {
    this.transactionPool = transactionPool;
  }

  public DaoTransaction getTransaction() throws DaoException {
    if (transactionPool == null) {
      throw new DaoException("DaoManager could not get DaoTransaction.  DaoTransactionPool was null (possibly not configured).");
    }
    return transactionPool.getTransaction();
  }

  public void releaseTransaction(DaoTransaction trans) throws DaoException {
    if (transactionPool == null) {
      throw new DaoException("DaoManager could not release DaoTransaction.  DaoTransactionPool was null (possibly not configured).");
    }
    transactionPool.releaseTransaction(trans);
  }

  public boolean isTransactionStarted() throws DaoException {
    return localTransaction.get() != null;
  }

  public void startTransaction() throws DaoException {
    if (transactionPool == null) {
      throw new DaoException("DaoManager could not start DaoTransaction.  DaoTransactionPool was null (possibly not configured).");
    }
    if (localTransaction.get() != null) {
      throw new DaoException("DaoManager could not invoke startTransaction(). A transaction is already started. Call commitTransaction() or rollbackTransaction first.");
    }
    localTransaction.set(transactionPool.getTransaction());
  }

  public DaoTransaction getLocalTransaction() throws DaoException {
    if (localTransaction.get() == null) {
      throw new DaoException("DaoManager could not invoke getLocalTransaction(). No transaction was started. Call startTransaction() first.");
    }
    return (DaoTransaction) localTransaction.get();
  }

  public void commitTransaction() throws DaoException {
    if (localTransaction.get() == null) {
      throw new DaoException("DaoManager could not invoke commitTransaction(). No transaction was started. Call startTransaction() first.");
    }
    try {
      DaoTransaction trans = null;
      try {
        trans = (DaoTransaction) localTransaction.get();
        trans.commit();
      } finally {
        if (trans != null) trans.release();
      }
    } finally {
      localTransaction.set(null);
    }
  }

  public void rollbackTransaction() throws DaoException {
    try {
      DaoTransaction trans = null;
      try {
        trans = (DaoTransaction) localTransaction.get();
        if (trans != null) {
          trans.rollback();
        }
      } finally {
        if (trans != null) trans.release();
      }
    } finally {
      localTransaction.set(null);
    }
  }


  protected void initializeDaoObjects()
      throws DaoException {
    Iterator i = daoClassMap.keySet().iterator();
    while (i.hasNext()) {
      String name = (String) i.next();
      String implementation = (String) daoClassMap.get(name);
      try {
        Class c = Class.forName(implementation);
        Object dao = c.newInstance();
        registerDao(name, (Dao) dao);
      } catch (ClassNotFoundException e) {
        throw new DaoException("DaoManager could not configure DaoFactory.  The DAO named '" + name + "' failed. Cause: " + e, e);
      } catch (InstantiationException e) {
        throw new DaoException("DaoManager could not configure DaoFactory.  The DAO named '" + name + "' failed. Cause: " + e, e);
      } catch (IllegalAccessException e) {
        throw new DaoException("DaoManager could not configure DaoFactory.  The DAO named '" + name + "' failed. Cause: " + e, e);
      } catch (Throwable t) {
        throw new DaoException("DaoManager could not configure DaoFactory.  The DAO named '" + name + "' failed. Cause: " + t, t);
      }
    }
  }

  protected void registerDao(String name, Dao dao) {
    daoMap.put(name, dao);
    daoManagerReverseLookup.put(dao, this);
  }

  protected static void registerDaoManager(Object contextName, DaoManager daoManager) {
    daoContextMap.put(contextName, daoManager);
  }


}
