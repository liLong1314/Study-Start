/**
 * User: Clinton Begin
 * Date: Apr 20, 2003
 * Time: 5:14:32 PM
 */
package com.ibatis.db.sqlmap;

import java.sql.*;
import java.util.*;

public class StatementFactory {

  private Object CACHE_LOCK = new Object();

  private List allAvailableStatements = new ArrayList();
  private int maxTotalCachedStatements = 0;

  private Map availableStatementMap = new HashMap();
  private Map busyStatementMap = new HashMap();

  private int cacheRequests = 0;
  private int cacheHits = 0;


  public int getMaxTotalCachedStatements() {
    return maxTotalCachedStatements;
  }

  public void setMaxTotalCachedStatements(int maxTotalCachedStatements) {
    this.maxTotalCachedStatements = maxTotalCachedStatements;
  }

  public Double getCacheHitRatio() {
    synchronized (CACHE_LOCK) {
      if (cacheRequests != 0) {
        return new Double((double) cacheHits / (double) cacheRequests);
      } else {
        return null;
      }
    }
  }

  public PreparedStatement newStatement(Connection conn, String sql, boolean cache)
      throws SQLException {
    PreparedStatement ps = conn.prepareStatement(sql);
    if (cache) {
      StatementWrapper wrapper = new StatementWrapper(conn, sql, ps);
      busyStatementMap.put(ps, wrapper);
    }
    return ps;
  }

  public PreparedStatement newStatement(Connection conn, String sql, boolean cache,
                          int resultSetType, int resultSetConcurrency)
      throws SQLException {
    PreparedStatement ps = conn.prepareStatement(sql,resultSetType,resultSetConcurrency);
    if (cache) {
      StatementWrapper wrapper = new StatementWrapper(conn, sql, ps);
      busyStatementMap.put(ps, wrapper);
    }
    return ps;
  }

  public CallableStatement newCallable(Connection conn, String sql, boolean cache)
      throws SQLException {
    CallableStatement cs = conn.prepareCall(sql);
    if (cache) {
      StatementWrapper wrapper = new StatementWrapper(conn, sql, cs);
      busyStatementMap.put(cs, wrapper);
    }
    return cs;
  }

  public PreparedStatement getStatement(Connection conn, String sql)
      throws SQLException {
    PreparedStatement ps = null;
    StatementWrapper wrapper = null;
    synchronized (CACHE_LOCK) {
      cacheRequests++;
      Map statementMap = (Map) availableStatementMap.get(conn);
      if (statementMap != null) {
        List list = (List) statementMap.get(sql);
        if (list != null && list.size() > 1) {
          wrapper = null;
          while (wrapper == null && list.size() > 0) {
            wrapper = (StatementWrapper) list.remove(0);
            allAvailableStatements.remove(wrapper);
            try {
              wrapper.ps.clearParameters();
            } catch (Exception e) {
              wrapper = null;
            }
          }
        }
      }
      if (wrapper != null) {
        cacheHits++;
        busyStatementMap.put(wrapper.ps, wrapper);
        ps = wrapper.ps;
      } else {
        ps = null;
      }
    }
    return ps;
  }

  public void releaseStatement(PreparedStatement ps) {
    synchronized (CACHE_LOCK) {
      StatementWrapper wrapper = (StatementWrapper) busyStatementMap.remove(ps);
      if (wrapper != null) {
        if (maxTotalCachedStatements > 0) {
          Map map = (Map) availableStatementMap.get(wrapper.connection);
          if (map == null) {
            map = new HashMap();
            availableStatementMap.put(wrapper.connection, map);
          }
          List list = (List) map.get(wrapper.sql);
          if (list == null) {
            list = new ArrayList();
            map.put(wrapper.sql, list);
          }
          if (allAvailableStatements.size() > 0
              && allAvailableStatements.size() >= maxTotalCachedStatements) {
            StatementWrapper oldWrapper = (StatementWrapper) allAvailableStatements.remove(0);
            forceCloseStatement(oldWrapper.ps);
          }
          list.add(wrapper);
          allAvailableStatements.add(wrapper);
        } else {
          forceCloseStatement(ps);
        }
      } else {
        forceCloseStatement(ps);
      }
    }
  }

  private static void forceCloseStatement(Statement statement) {
    if (statement != null) {
      try {
        statement.close();
      } catch (SQLException e) {
        // ignore
      }
    }
  }

  /**
   * This class is used for managing pooled PreparedStatements while
   * they are in use.
   *
   * It is not fully encapsulated to increase performance, however
   * being a private inner class, it should be relatively safe.
   */
  private static class StatementWrapper {
    public Connection connection;
    public String sql;
    public PreparedStatement ps;

    public StatementWrapper(Connection conn, String sql, PreparedStatement ps)
        throws SQLException {
      this.connection = conn;
      this.sql = sql;
      this.ps = ps;
    }

    public boolean equals(Object o) {
      if (this == o) return true;
      if (!(o instanceof StatementWrapper)) return false;

      final StatementWrapper statementWrapper = (StatementWrapper) o;

      if (!connection.equals(statementWrapper.connection)) return false;
      if (!ps.equals(statementWrapper.ps)) return false;
      if (!sql.equals(statementWrapper.sql)) return false;

      return true;
    }

    public int hashCode() {
      int result;
      result = connection.hashCode();
      result = 29 * result + sql.hashCode();
      result = 29 * result + ps.hashCode();
      return result;
    }

    public String toString() {
      return sql;
    }
  }

}
