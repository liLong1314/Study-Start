package com.ibatis.db.dao;

import com.ibatis.common.exception.*;

/**
 * DaoException for use for by DAO framework.
 *
 * @author  clinton_begin
 */
public class DaoException extends NestedException {

  public DaoException() {
  }

  public DaoException(String msg) {
    super(msg);
  }

  public DaoException(Throwable cause) {
    super(cause);
  }

  public DaoException(String msg, Throwable cause) {
    super(msg, cause);
  }

}


