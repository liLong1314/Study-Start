/**
 * User: Clinton Begin
 * Date: Mar 5, 2003
 * Time: 8:49:58 PM
 */
package com.ibatis.db.sqlmap.dynamic;

public class PrependedFragment extends BaseFragment {

  private String prepend;

  public String getPrepend() {
    return prepend;
  }

  public void setPrepend(String prepend) {
    this.prepend = prepend;
  }

}
