package com.ibatis.db.dao;

import java.util.*;

/**
 * Manages a pool of DaoTransactions.
 *
 * @author  clinton_begin
 */
public interface DaoTransactionPool {

  public DaoTransaction getTransaction()
      throws DaoException;

  public void releaseTransaction(DaoTransaction trans)
      throws DaoException;

  public void configure(Map properties)
      throws DaoException;

}

