/**
 * User: Clinton Begin
 * Date: Apr 11, 2003
 * Time: 10:56:24 PM
 */
package com.ibatis.db.sqlmap.typehandler;

import com.ibatis.db.sqlmap.value.*;
import com.ibatis.db.sqlmap.*;
import com.ibatis.common.exception.*;

import java.sql.*;
import java.text.*;
import java.util.*;
import java.util.Date;

public class DateTypeHandler extends BaseTypeHandler {

  private static final String DATE_FORMAT = "yyyy/MM/dd hh:mm:ss";
  private static final DateFormat format = new SimpleDateFormat(DATE_FORMAT);

  protected Object getValueByName(ResultMapping mapping, ResultSet rs) throws SQLException {
    java.util.Date value = null;

    int type = mapping.getJdbcType();

    if (Types.DATE == type) {
      java.sql.Date date = rs.getDate(mapping.getColumnName());
      if (date != null) {
        value = new java.util.Date(date.getTime());
      }
    } else if (Types.TIME == type) {
      java.sql.Time time = rs.getTime(mapping.getColumnName());
      if (time != null) {
        value = new java.util.Date(time.getTime());
      }
    } else {
      java.sql.Timestamp timestamp = rs.getTimestamp(mapping.getColumnName());
      if (timestamp != null) {
        value = new java.util.Date(timestamp.getTime());
      }
    }

    return value;
  }

  protected Object getValueByIndex(ResultMapping mapping, ResultSet rs) throws SQLException {
    java.util.Date value = null;

    int type = mapping.getJdbcType();

    if (Types.DATE == type) {
      java.sql.Date date = rs.getDate(mapping.getColumnIndex().intValue());
      if (date != null) {
        value = new java.util.Date(date.getTime());
      }
    } else if (Types.TIME == type) {
      java.sql.Time time = rs.getTime(mapping.getColumnIndex().intValue());
      if (time != null) {
        value = new java.util.Date(time.getTime());
      }
    } else {
      java.sql.Timestamp timestamp = rs.getTimestamp(mapping.getColumnIndex().intValue());
      if (timestamp != null) {
        value = new java.util.Date(timestamp.getTime());
      }
    }

    return value;
  }

  protected Object getNullValue(String nullValue) throws SQLException {
    try {
      return format.parse(nullValue);
    } catch (ParseException e) {
      throw new SQLException("Error parsing default null value date.  Format must be '" + DATE_FORMAT + "'. Cause: " + e);
    }
  }

  public Object instantiateValue() {
    return new DateValue();
  }

  public boolean isEqualToNullValue(String nullValue, Object realValue) {
    try {
      return format.parse(nullValue).equals(realValue);
    } catch (ParseException e) {
      throw new NestedRuntimeException("Error parsing default null value date.  Format must be '" + DATE_FORMAT + "'. Cause: " + e, e);
    }
  }

  public boolean isSimpleType() {
    return true;
  }

  public void setParameter(ParameterMapping mapping, PreparedStatement ps, int index, Object value) throws SQLException {
    long datetime = ((Date) value).getTime();
    int type = mapping.getJdbcType();
    if (Types.DATE == type) {
      java.sql.Date date = new java.sql.Date(datetime);
      ps.setDate(index, date);
    } else if (Types.TIME == type) {
      java.sql.Time time = new java.sql.Time(datetime);
      ps.setTime(index, time);
    } else {
      Timestamp timestamp = new Timestamp(datetime);
      ps.setTimestamp(index, timestamp);
    }
  }

}