/**
 * @deprecated
 */
package com.ibatis.db.sqlmap;

public class StringResult {

  private String result;

  public String getResult() {
    return result;
  }

  public void setResult(String result) {
    this.result = result;
  }

}
