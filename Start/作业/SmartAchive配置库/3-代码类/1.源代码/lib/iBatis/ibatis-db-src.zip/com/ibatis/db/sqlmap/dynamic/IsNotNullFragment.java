/**
 * User: Clinton Begin
 * Date: Mar 3, 2003
 * Time: 7:28:55 PM
 */
package com.ibatis.db.sqlmap.dynamic;

public class IsNotNullFragment extends IsNullFragment {

  public boolean isCondition(Object parameterObject) {
    return !super.isCondition(parameterObject);
  }

}
