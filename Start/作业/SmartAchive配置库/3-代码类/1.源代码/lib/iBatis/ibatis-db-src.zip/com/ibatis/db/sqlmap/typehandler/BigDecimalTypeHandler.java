/**
 * User: Clinton Begin
 * Date: Apr 11, 2003
 * Time: 10:56:14 PM
 */
package com.ibatis.db.sqlmap.typehandler;

import com.ibatis.db.sqlmap.value.*;
import com.ibatis.db.sqlmap.*;

import java.sql.*;

public class BigDecimalTypeHandler extends BaseTypeHandler {

  protected Object getValueByName(ResultMapping mapping, ResultSet rs) throws SQLException {
    return rs.getBigDecimal(mapping.getColumnName());
  }

  protected Object getValueByIndex(ResultMapping mapping, ResultSet rs) throws SQLException {
    return rs.getBigDecimal(mapping.getColumnIndex().intValue());
  }

  protected Object getNullValue(String nullValue) throws SQLException {
    return java.math.BigDecimal.valueOf(Long.valueOf(nullValue).longValue());
  }

  public Object instantiateValue() {
    return new BigDecimalValue();
  }

  public boolean isEqualToNullValue(String nullValue, Object realValue) {
    return java.math.BigDecimal.valueOf(Long.valueOf(nullValue).longValue()).equals(realValue);
  }

  public boolean isSimpleType() {
    return true;
  }

  public void setParameter(ParameterMapping mapping, PreparedStatement ps, int index, Object value) throws SQLException {
    ps.setBigDecimal(index, ((java.math.BigDecimal) value));
  }

}
