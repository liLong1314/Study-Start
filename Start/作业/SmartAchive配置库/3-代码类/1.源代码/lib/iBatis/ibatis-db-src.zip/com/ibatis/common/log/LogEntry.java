package com.ibatis.common.log;

import java.util.*;

/**
 *
 *
 * @author  clinton_begin
 * @deprecated Use Jakarta commons logging
 */
public class LogEntry {

  public static final String DEFAULT_CHANNEL = "DEFAULT_CHANNEL";

  private Object channel;
  private Object object;
  private LogLevel logLevel;
  private Date date;

  public LogEntry(LogLevel level, Object o) {
    this.logLevel = level;
    this.object = o;
    this.date = new Date();
    this.channel = DEFAULT_CHANNEL;
  }

  public LogEntry(LogLevel level, Object channel, Object o) {
    this.logLevel = level;
    this.object = o;
    this.date = new Date();
    this.channel = channel;
  }

  public Object getObject() {
    return object;
  }

  public LogLevel getLogLevel() {
    return logLevel;
  }

  public Date getDate() {
    return date;
  }

  public Object getChannel() {
    return channel;
  }

  public String toString() {
    return String.valueOf(getChannel()) + " @ " + String.valueOf(getDate()) + ": " + String.valueOf(getObject()).trim();
  }
}
