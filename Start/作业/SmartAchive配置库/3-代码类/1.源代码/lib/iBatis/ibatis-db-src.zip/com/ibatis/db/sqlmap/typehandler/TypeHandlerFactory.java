/**
 * User: Clinton Begin
 * Date: Apr 11, 2003
 * Time: 11:05:53 PM
 */
package com.ibatis.db.sqlmap.typehandler;

import java.util.*;
import java.math.*;

public class TypeHandlerFactory {

  private static final Map typeHandlerMap = new HashMap();

  /* Constructor */

  private TypeHandlerFactory() {
  }

  /* Static Initializer */

  static {
    TypeHandler handler;

    handler = new BooleanTypeHandler();
    typeHandlerMap.put(Boolean.class, handler);
    typeHandlerMap.put(boolean.class, handler);

    handler = new ByteTypeHandler();
    typeHandlerMap.put(Byte.class, handler);
    typeHandlerMap.put(byte.class, handler);

    handler = new ShortTypeHandler();
    typeHandlerMap.put(Short.class, handler);
    typeHandlerMap.put(short.class, handler);

    handler = new IntegerTypeHandler();
    typeHandlerMap.put(Integer.class, handler);
    typeHandlerMap.put(int.class, handler);

    handler = new LongTypeHandler();
    typeHandlerMap.put(Long.class, handler);
    typeHandlerMap.put(long.class, handler);

    handler = new FloatTypeHandler();
    typeHandlerMap.put(Float.class, handler);
    typeHandlerMap.put(float.class, handler);

    handler = new DoubleTypeHandler();
    typeHandlerMap.put(Double.class, handler);
    typeHandlerMap.put(double.class, handler);

    typeHandlerMap.put(String.class, new StringTypeHandler());
    typeHandlerMap.put(Date.class, new DateTypeHandler());
    typeHandlerMap.put(BigDecimal.class, new BigDecimalTypeHandler());
    typeHandlerMap.put(byte[].class, new ByteArrayTypeHandler());
    typeHandlerMap.put(Object.class, new ObjectTypeHandler());

    typeHandlerMap.put(java.sql.Date.class, new SqlDateTypeHandler());
    typeHandlerMap.put(java.sql.Time.class, new SqlTimeTypeHandler());
    typeHandlerMap.put(java.sql.Timestamp.class, new SqlTimestampTypeHandler());
  }

  /* Public Methods */

  public static TypeHandler getTypeHandler(Class type) {
    return (TypeHandler) typeHandlerMap.get(type);
  }

}
