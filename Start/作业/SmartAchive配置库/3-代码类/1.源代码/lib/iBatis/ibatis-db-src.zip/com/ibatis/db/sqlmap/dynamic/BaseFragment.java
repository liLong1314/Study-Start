/**
 * User: Clinton Begin
 * Date: Mar 3, 2003
 * Time: 7:39:41 PM
 */
package com.ibatis.db.sqlmap.dynamic;

import java.util.*;
import java.sql.*;

public abstract class BaseFragment {

  private String sqlFragment;

  public String getSqlFragment(Object parameterObject) {
    return sqlFragment;
  }

  public String getSqlFragment() {
    return sqlFragment;
  }

  public void setSqlFragment(String sqlFragment) {
    this.sqlFragment = sqlFragment;
  }

  public static void handleFragment(BaseFragment fragment, Object parameterObject, StringBuffer childBuffer) {
    childBuffer.append(" ");
    childBuffer.append(fragment.getSqlFragment(parameterObject));
    childBuffer.append(" ");
  }

}
