/**
 * User: Clinton Begin
 * Date: Feb 11, 2003
 * Time: 9:29:15 PM
 */
package com.ibatis.common.xml;

import com.ibatis.common.beans.*;

import java.util.*;
import java.math.*;


public class XmlBeanEncoder {

  private String tab = "  ";
  private boolean typeIncluded = true;

  public String getTab() {
    return tab;
  }

  public void setTab(String tab) {
    this.tab = tab;
  }

  public boolean isTypeIncluded() {
    return typeIncluded;
  }

  public void setTypeIncluded(boolean typeIncluded) {
    this.typeIncluded = typeIncluded;
  }

  public String encodeBeanToXml(String rootName, Object object, int tabs) {
    StringBuffer xml = new StringBuffer();
    String[] properties = StaticBeanProbe.getReadablePropertyNames(object);

    if (typeIncluded) {
      xml.append("\n" + tabs(tabs) + "<" + rootName + " type=\"" + object.getClass().getName() + "\">");
    } else {
      xml.append("\n" + tabs(tabs) + "<" + rootName + ">");
    }
    for (int i = 0; i < properties.length; i++) {
      String name = properties[i];
      Object value = StaticBeanProbe.getObject(object, name);
      if (value == null) {
        if (typeIncluded) {
          xml.append("\n" + tabs(tabs + 1) + "<" + name + " type=\"" + StaticBeanProbe.getPropertyTypeForGetter(object, name).getName() + "\"></" + name + ">");
        } else {
          xml.append("\n" + tabs(tabs + 1) + "<" + name + "></" + name + ">");
        }
      } else if (isBasicType(value)) {
        xml.append(tagValue(object, name, value, tabs + 1));
      } else if (value instanceof Collection) {
        handleCollection(xml, tabs, name, value);
      } else {
        encodeBeanToXml(name, value, tabs + 1);
      }
    }
    xml.append("\n" + tabs(tabs) + "</" + rootName + ">");

    return xml.toString();
  }

  private void handleCollection(StringBuffer xml, int tabs, String name, Object value) {
    if (typeIncluded) {
      xml.append("\n" + tabs(tabs + 1) + "<" + name + " type=\"" + value.getClass().getName() + "\">");
    } else {
      xml.append("\n" + tabs(tabs + 1) + "<" + name + ">");
    }
    Iterator it = ((Collection) value).iterator();
    while (it.hasNext()) {
      Object item = it.next();
      if (isBasicType(item)) {
        xml.append(tagValue(item, name, value, tabs + 2));
      } else if (item instanceof Collection) {
        handleCollection(xml, tabs + 1, resolveClassName(item.getClass().getName()), item);
      } else {
        xml.append(encodeBeanToXml(resolveClassName(item.getClass().getName()), item, tabs + 2));
      }
    }
    xml.append("\n" + tabs(tabs + 1) + "</" + name + ">");
  }

  private String tagValue(Object object, String property, Object value, int tabs) {
    StringBuffer tag = new StringBuffer();
    tag.append("\n");
    tag.append(tabs(tabs));
    tag.append("<");
    tag.append(property);
    if (typeIncluded) {
      tag.append(" ");
      tag.append("type=\"");
      tag.append(StaticBeanProbe.getPropertyTypeForGetter(object, property).getName());
      tag.append("\"");
    }
    tag.append(">");

    if (value != null) {
      String s = value.toString();
      boolean hasReserved = s.indexOf("<") > -1 || s.indexOf(">") > -1;
      if (hasReserved) {
        tag.append("\n<![CDATA[\n");
      }
      tag.append(s);
      if (hasReserved) {
        tag.append("\n]]>\n");
      }
    }

    tag.append("</");
    tag.append(property);
    tag.append(">");
    return tag.toString();
  }

  private String tabs(int n) {
    StringBuffer tabs = new StringBuffer(n);
    for (int i = 0; i < n; i++) {
      tabs.append(tab);
    }
    return tabs.toString();
  }

  private static boolean isBasicType(Object value) {
    if (value instanceof String) {
      return true;
    } else if (value instanceof Byte) {
      return true;
    } else if (value instanceof Short) {
      return true;
    } else if (value instanceof Character) {
      return true;
    } else if (value instanceof Integer) {
      return true;
    } else if (value instanceof Long) {
      return true;
    } else if (value instanceof Float) {
      return true;
    } else if (value instanceof Double) {
      return true;
    } else if (value instanceof Boolean) {
      return true;
    } else if (value instanceof Date) {
      return true;
    } else if (value instanceof String) {
      return true;
    } else if (value instanceof Class) {
      return true;
    } else if (value instanceof BigInteger) {
      return true;
    } else if (value instanceof BigDecimal) {
      return true;
    } else {
      return false;
    }
  }

  private String resolveClassName(String fullName) {
    if (fullName.indexOf(".") < 0) {
      return fullName.toLowerCase();
    } else {
      return fullName.substring(fullName.lastIndexOf(".") + 1).toLowerCase();
    }
  }

}
