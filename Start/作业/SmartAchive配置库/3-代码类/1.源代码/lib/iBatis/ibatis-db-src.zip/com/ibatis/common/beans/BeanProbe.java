package com.ibatis.common.beans;

import java.util.*;

/**
 * BeanProbe is an instantiatable wrapper for any JavaBeans compliant
 * object that allows simple reflective access to bean properties.  All
 * methods forward to equivalent methods in StaticBeanProbe.  In some cases
 * it may be easier to use this wrapper class instead of having to constantly
 * pass the object references to the property accessor methods of StaticBeanProbe.
 * <p>
 * Examples:
 * <p>
 * BeanProbe probe = new BeanProbe(object);
 * <p>
 * probe.setObject(propertyName, value);
 * <P>
 * Object value = probe.getObject(propertyName);
 *
 * @author  clinton_begin
 *
 */
public class BeanProbe extends Object {

  private Object object = null;

  /** Creates new BeanProbe to wrap a bean
   * @param obj The bean to wrap
   */
  public BeanProbe(Object obj) {
    object = obj;
  }

  /** Set a field (property) to an Object value
   * @param name Property name
   * @param value New value
   */
  public void setField(String name, Object value) {
    StaticBeanProbe.setField(object, name, value);
  }

  /** Get an Object value from a field (property)
   * @param name Property name
   * @return The value of the property
   */
  public Object getField(String name) {
    return StaticBeanProbe.getField(object, name);
  }

  /** Returns an array of the names of the readable properties for the bean
   * @return The names
   */
  public String[] getReadablePropertyNames() {
    return StaticBeanProbe.getReadablePropertyNames(object);
  }

  /** Returns an array of the names of the writeable properties for the bean
   * @return The names
   */
  public String[] getWriteablePropertyNames() {
    return StaticBeanProbe.getWriteablePropertyNames(object);
  }

  /** Compares a bean to the wrapped bean to see if it is equal - all properties are
   * equal.
   * @param object2 The bean to compare
   * @return True if the beans are the same
   */
  public boolean beanEquals(Object object2) {
    return StaticBeanProbe.beanEquals(object, object2);
  }

  /** Compares a bean to the wrapped bean to see if it is equal enough - the list of
   * named properties are equal.
   * @param object2 The bean to compare
   * @param properties The properties to test
   * @return True if the properties listed are all equal
   */
  public boolean beanEquals(Object object2, String[] properties) {
    return StaticBeanProbe.beanEquals(object, object2, properties);
  }

  /** Calculates a hash code for all readable properties of the bean
   * @return The hashcode
   */
  public int beanHashCode() {
    return StaticBeanProbe.beanHashCode(object);
  }

  /** Calculates a hash code for a subset of the readable properties of a bean
   * @param properties A list of the properties to hash
   * @return The hashcode
   */
  public int beanHashCode(String[] properties) {
    return StaticBeanProbe.beanHashCode(object, properties);
  }

  /** Gets the type of a property based on the setter
   * @param name Property name
   * @return The property type
   */
  public Class getPropertyTypeForSetter(String name) {
    return StaticBeanProbe.getPropertyTypeForSetter(object, name);
  }

  /** Gets the type of a property based on the getter
   * @param name Property name
   * @return The property type
   */
  public Class getPropertyTypeForGetter(String name) {
    return StaticBeanProbe.getPropertyTypeForGetter(object, name);
  }

  /** Gets an Object property
   * @param name Property name
   * @return The value of the property
   */
  public Object getObject(String name) {
    return StaticBeanProbe.getObject(object, name);
  }

  /** Sets an Object property
   * @param name Property name
   * @param value New value
   */
  public void setObject(String name, Object value) {
    StaticBeanProbe.setObject(object, name, value);
  }

  //---String---
  /** Gets a String property
   * @param name Property name
   * @return The value of the property
   */
  public String getString(String name) {
    return (String) getObject(name);
  }

  /** Sets a String property
   * @param name Property name
   * @param value New value
   */
  public void setString(String name, String value) {
    setObject(name, value);
  }

  //---Integer---
  /** Gets an Integer property
   * @param name Property name
   * @return The value of the property
   */
  public int getInteger(String name) {
    return ((Integer) getObject(name)).intValue();
  }

  /** Sets an Integer property
   * @param name Property name
   * @param value New value
   */
  public void setInteger(String name, int value) {
    setObject(name, new Integer(value));
  }

  //---Long---
  /** Gets a long property
   * @param name Property name
   * @return The value of the property
   */
  public long getLong(String name) {
    return ((Long) getObject(name)).longValue();
  }

  /** Sets a long property
   * @param name Property name
   * @param value New value
   */
  public void setLong(String name, long value) {
    setObject(name, new Long(value));
  }

  //---Short---
  /** Gets a short property
   * @param name Property name
   * @return The value of the property
   */
  public short getShort(String name) {
    return ((Short) getObject(name)).shortValue();
  }

  /** Sets a short property
   * @param name Property name
   * @param value New value
   */
  public void setShort(String name, short value) {
    setObject(name, new Short(value));
  }

  //---Byte---
  /** Gets a byte property
   * @param name Property name
   * @return The value of the property
   */
  public byte getByte(String name) {
    return ((Byte) getObject(name)).byteValue();
  }

  /** Sets a byte property
   * @param name Property name
   * @param value New value
   */
  public void setByte(String name, byte value) {
    setObject(name, new Byte(value));
  }

  //---Character---
  /** Gets a char property
   * @param name Property name
   * @return The value of the property
   */
  public char getCharacter(String name) {
    return ((Character) getObject(name)).charValue();
  }

  /** Sets a char property
   * @param name Property name
   * @param value New value
   */
  public void setCharacter(String name, char value) {
    setObject(name, new Character(value));
  }

  //---Double---
  /** Gets a double property
   * @param name Property name
   * @return The value of the property
   */
  public double getDouble(String name) {
    return ((Double) getObject(name)).doubleValue();
  }

  /** Sets a double property
   * @param name Property name
   * @param value New value
   */
  public void setDouble(String name, double value) {
    setObject(name, new Double(value));
  }

  //---Float---
  /** Gets a float property
   * @param name Property name
   * @return The value of the property
   */
  public float getFloat(String name) {
    return ((Float) getObject(name)).floatValue();
  }

  /** Sets a float property
   * @param name Property name
   * @param value New value
   */
  public void setFloat(String name, float value) {
    setObject(name, new Float(value));
  }


  //---Boolean---
  /** Gets a boolean property
   * @param name Property name
   * @return The value of the property
   */
  public boolean getBoolean(String name) {
    return ((Boolean) getObject(name)).booleanValue();
  }

  /** Sets a boolean property
   * @param name Property name
   * @param value New value
   */
  public void setBoolean(String name, boolean value) {
    setObject(name, new Boolean(value));
  }

  //---Date---
  /** Gets a Date property
   * @param name Property name
   * @return The value of the property
   */
  public Date getDate(String name) {
    return ((Date) getObject(name));
  }

  /** Sets a Date property
   * @param name Property name
   * @param value New value
   */
  public void setDate(String name, Date value) {
    setObject(name, value);
  }

  /** Checks to see if a bean has a writeable property by name
   * @param propertyName The property to look for
   * @return True if the bean has a writeable property with the name in propertyName
   */
  public boolean hasWritableProperty(String propertyName) {
    return StaticBeanProbe.hasWritableProperty(object, propertyName);
  }

  /** Checks to see if a bean has a readable property by name
   * @param propertyName The property to look for
   * @return True if the bean has a readable property with the name in propertyName
   */
  public boolean hasReadableProperty(String propertyName) {
    return StaticBeanProbe.hasReadableProperty(object, propertyName);
  }


  /** Generates a hashcode for the bean
   * @return The hash code
   */
  public int hashCode() {
    return StaticBeanProbe.beanHashCode(object);
  }

  /** Compares the beans to another
   * @param obj The bean to compare
   * @return True if the beans are the same
   */
  public boolean equals(Object obj) {
    return StaticBeanProbe.beanEquals(object, obj);
  }

}
