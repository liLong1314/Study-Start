/**
 * User: Clinton Begin
 * Date: Feb 20, 2003
 * Time: 7:42:04 PM
 */
package com.ibatis.db.sqlmap.value;

public class ByteValue extends BaseValue {

  public ByteValue() {
  }

  public ByteValue(Byte value) {
    super(value);
  }

  public ByteValue(byte value) {
    super(new Byte(value));
  }

  public Byte getValue() {
    return (Byte) value;
  }

  public void setValue(Byte value) {
    this.value = value;
  }


}
