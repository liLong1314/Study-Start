package com.ibatis.common.log;

/**
 *
 *
 * @author  clinton_begin
 * @deprecated Use Jakarta commons logging
 */
public class SystemOutLog extends Object implements Log {

  /** Creates new SystemOutLog */
  public SystemOutLog() {
  }

  public void log(LogEntry logEntry) {
    if (logEntry.getLogLevel() == LogLevel.LOG_DEBUG) {
      Logger.getStdOut().println(logEntry.toString());
    } else if (logEntry.getLogLevel() == LogLevel.LOG_STDOUT) {
      Logger.getStdOut().println(String.valueOf(logEntry.getObject()).trim());
    } else if (logEntry.getLogLevel() == LogLevel.LOG_INFO) {
      Logger.getStdOut().println(logEntry.toString());
    } else if (logEntry.getLogLevel() == LogLevel.LOG_WARN) {
      Logger.getStdOut().println("*************** WARNING ***************\n"
          + logEntry.toString()
          + "\n***************************************");
    } else if (logEntry.getLogLevel() == LogLevel.LOG_ERROR) {
      Logger.getStdOut().println("**************** ERROR ****************\n"
          + logEntry.toString()
          + "\n***************************************");
    } else if (logEntry.getLogLevel() == LogLevel.LOG_CRITICAL) {
      Logger.getStdOut().println("*************** CRITICAL! *************\n"
          + logEntry.toString()
          + "\n***************************************");
    }
  }

  public void flush() {
    Logger.getStdOut().flush();
  }

}
