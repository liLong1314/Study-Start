package com.ibatis.db.dao;

/**
 * DaoTransaction wraps specific connection or transaction implementation
 * such that they can be effectively hidden from applications.  This
 * is a critical part of insulating the persistence mechanism from
 * the application code.
 *
 * @author  clinton_begin
 */
public interface DaoTransaction {

  public void commit() throws DaoException;

  public void rollback() throws DaoException;

  public void release() throws DaoException;

}
