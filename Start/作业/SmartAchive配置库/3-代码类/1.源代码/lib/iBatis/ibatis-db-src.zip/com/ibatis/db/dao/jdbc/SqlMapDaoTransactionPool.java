/**
 * User: Clinton Begin
 * Date: Mar 9, 2003
 * Time: 10:03:52 PM
 */
package com.ibatis.db.dao.jdbc;

import com.ibatis.db.dao.DaoTransactionPool;
import com.ibatis.db.dao.DaoTransaction;
import com.ibatis.db.dao.DaoException;
import com.ibatis.db.sqlmap.SqlMap;
import com.ibatis.db.sqlmap.XmlSqlMapBuilder;
import com.ibatis.common.resources.Resources;
import com.ibatis.common.exception.*;

import java.util.*;
import java.io.*;
import java.sql.*;

public class SqlMapDaoTransactionPool implements DaoTransactionPool {

  private SqlMap sqlMap;

  public void configure(Map properties)
      throws DaoException {

    try {
      String xmlConfig = (String) properties.get("sql-map-config-file");

      Reader reader = Resources.getResourceAsReader(xmlConfig);
      sqlMap = XmlSqlMapBuilder.buildSqlMap(reader);
    } catch (Exception e) {
      throw new NestedRuntimeException("Error configuring SqlMapDaoTransactionPool.  Cause: " + e, e);
    }

  }

  public DaoTransaction getTransaction()
      throws DaoException {
    try {
      sqlMap.startTransaction();
      return new SqlMapDaoTransaction(sqlMap);
    } catch (SQLException e) {
      throw new DaoException("Error getting transaction. Cause: " + e, e);
    }
  }

  public void releaseTransaction(DaoTransaction trans)
      throws DaoException {
    // No implementation required.
  }

  public SqlMap getSqlMap() {
    return sqlMap;
  }

}
