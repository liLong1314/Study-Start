package com.ibatis.db.dao.jdbc;

import com.ibatis.db.dao.*;

import java.sql.*;

/**
 *
 * A DaoTransaction implementation that wraps a JDBC Connection object.
 *
 * @author  clinton_begin
 */
public class JdbcDaoTransaction implements DaoTransaction {

  private DaoTransactionPool pool;

  /** Holds value of property connection. */
  private Connection connection;

  /** Creates new JdbcDaoTransaction */
  public JdbcDaoTransaction(DaoTransactionPool pool, Connection conn) {
    this.pool = pool;
    this.connection = conn;
  }

  /** Getter for property connection.
   * @return Value of property connection.
   */
  public Connection getConnection() throws DaoException {
    if (connection == null) {
      throw new DaoException("Connection was null in JdbcDaoTransaction.");
    }
    return connection;
  }

  public void commit() throws DaoException {
    try {
      if (connection == null) {
        throw new DaoException("Connection was null in JdbcDaoTransaction.");
      }
      connection.commit();
    } catch (SQLException e) {
      throw new DaoException(e);
    }
  }

  public void rollback() throws DaoException {
    try {
      if (connection == null) {
        throw new DaoException("Connection was null in JdbcDaoTransaction.");
      }
      connection.rollback();
    } catch (SQLException e) {
      throw new DaoException(e);
    }
  }

  public void release() throws DaoException {
    pool.releaseTransaction(this);
  }

}
