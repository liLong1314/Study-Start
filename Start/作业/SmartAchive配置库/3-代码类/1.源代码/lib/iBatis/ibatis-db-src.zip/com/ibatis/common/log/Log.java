package com.ibatis.common.log;

/**
 *
 *
 * @author  clinton_begin
 * @deprecated Use Jakarta commons logging
 */
public interface Log {

  public void log(LogEntry logEntry);

  public void flush();

}

