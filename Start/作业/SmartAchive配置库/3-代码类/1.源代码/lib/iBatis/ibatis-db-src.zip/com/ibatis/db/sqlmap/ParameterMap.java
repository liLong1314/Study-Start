package com.ibatis.db.sqlmap;

import java.util.*;

/** The ParameterMap object is used to define the mapping between a MappedStatement
 * and a bean. The properties are mapped by the order that they appear in this
 * object (which is the order that they appear in the xml file that defines it).
 */
public class ParameterMap {

  private String name;

  private List propertyNames = new ArrayList();
  private Map mappings = new HashMap();

  /** Default constructor */
  public ParameterMap() {
  }

  /** Getter for the name property
   * @return The name of the ParameterMap object
   */
  public String getName() {
    return name;
  }

  /** Setter for the name property
   * @param name The new name of the object
   */
  public void setName(String name) {
    this.name = name;
  }

  /** Getter for propertyNames property
   * @return An array of Strings containing the names of the properties
   */
  public String[] getPropertyNameArray() {
    return (String[]) propertyNames.toArray(new String[propertyNames.size()]);
  }

  public void addParameterMapping(ParameterMapping parameterMapping) {
    propertyNames.add(parameterMapping.getPropertyName());
    mappings.put(parameterMapping.getPropertyName(), parameterMapping);
  }

  public ParameterMapping getParameterMapping(int i) {
    return (ParameterMapping) mappings.get(propertyNames.get(i));
  }

  /** Getter for the number of property mappings defined by this ParameterMap
   * @return The number of mappings
   */
  public int getCountOfPropertyMappings() {
    return propertyNames.size();
  }


}
