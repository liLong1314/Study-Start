package com.ibatis.db.dao;

/**
 * Dao is an interface that is used by DaoFactory for representing
 * classes that are Data Access Objects.  Dao does not have any methods
 * of its own, allowing for ultimate flexibility in Dao implementation.
 *
 * @author  clinton_begin
 *
 */
public interface Dao {

}
