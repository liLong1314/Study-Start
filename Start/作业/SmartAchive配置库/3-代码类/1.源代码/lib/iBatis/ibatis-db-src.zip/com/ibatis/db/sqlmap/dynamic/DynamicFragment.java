/**
 * User: Clinton Begin
 * Date: Mar 5, 2003
 * Time: 8:49:16 PM
 */
package com.ibatis.db.sqlmap.dynamic;

import java.util.*;
import java.sql.*;

public class DynamicFragment extends PrependedFragment {

  private List childFragmentList = new ArrayList();

  public String getSqlFragment(Object parameterObject) {
    StringBuffer buffer = new StringBuffer();

    boolean prepended = false;
    Iterator i = getChildFragments();
    while (i.hasNext()) {
      BaseFragment fragment = (BaseFragment) i.next();
      String s = fragment.getSqlFragment(parameterObject);
      if (s.trim().length() > 0) {
        if (!prepended && getPrepend() != null) {
          buffer.append(" ");
          buffer.append(getPrepend());
          buffer.append(" ");
          prepended = true;
        } else {
          if (fragment instanceof PrependedFragment) {
            String prepend = ((PrependedFragment) fragment).getPrepend();
            if (prepend != null) {
              buffer.append(" ");
              buffer.append(prepend);
              buffer.append(" ");
            }
          }
        }
        buffer.append(" ");
        buffer.append(s);
        buffer.append(" ");
      }
    }

    return buffer.toString();
  }

  public BaseFragment getChildFragment(int i) {
    return (BaseFragment) childFragmentList.get(i);
  }

  public int getChildFragmentCount() {
    return childFragmentList.size();
  }

  public void addChildFragment(BaseFragment fragment) {
    childFragmentList.add(fragment);
  }

  public void addAllChildFragment(Collection c) {
    childFragmentList.addAll(c);
  }

  public Iterator getChildFragments() {
    return childFragmentList.iterator();
  }

}
