/**
 * User: Clinton Begin
 * Date: Mar 3, 2003
 * Time: 7:41:24 PM
 */
package com.ibatis.db.sqlmap.dynamic;

import com.ibatis.common.beans.StaticBeanProbe;
import com.ibatis.common.exception.*;

import java.util.*;
import java.util.Date;
import java.math.*;
import java.text.*;

public abstract class ConditionalFragment extends DynamicFragment {

  public static final int COMPARE_TO_VALUE = 1;
  public static final int COMPARE_TO_PROPERTY = 2;

  protected static final long NOT_COMPARABLE = Long.MIN_VALUE;
  private static final String DATE_FORMAT = "yyyy/MM/dd hh:mm:ss";
  private static final DateFormat format = new SimpleDateFormat(DATE_FORMAT);

  private String propertyName;
  private String comparePropertyName;
  private String compareValue;
  private int compareTo;

  public abstract boolean isCondition(Object parameterObject);

  private String getSqlFragment(Object parameterObject, boolean isCondition) {
    if (isCondition) {
      StringBuffer buffer = new StringBuffer();
      Iterator i = getChildFragments();
      while (i.hasNext()) {
        BaseFragment fragment = (BaseFragment) i.next();
        if (fragment instanceof ConditionalFragment) {
          handleConditionalFragment((ConditionalFragment) fragment, parameterObject, buffer);
        } else if (fragment instanceof IterateFragment) {
          IterateFragment.handleIterateFragment((IterateFragment) fragment, parameterObject, buffer);
        } else {
          BaseFragment.handleFragment(fragment, parameterObject, buffer);
        }
      }
      return buffer.toString();
    } else {
      return "";
    }
  }

  public static void handleConditionalFragment(ConditionalFragment conditionalFragment, Object parameterObject, StringBuffer buffer) {
    boolean subCondition = conditionalFragment.isCondition(parameterObject);
    String sqlFragment = conditionalFragment.getSqlFragment(parameterObject, subCondition);
    if (subCondition) {
      String prepend = conditionalFragment.getPrepend();
      if (prepend != null) {
        buffer.append(" ");
        buffer.append(prepend);
      }
      buffer.append(" ");
      buffer.append(sqlFragment);
      buffer.append(" ");
    }
  }

  public String getSqlFragment(Object parameterObject) {
    return getSqlFragment(parameterObject, isCondition(parameterObject));
  }

  public String getComparePropertyName() {
    return comparePropertyName;
  }

  public void setComparePropertyName(String comparePropertyName) {
    if (comparePropertyName != null) {
      this.comparePropertyName = comparePropertyName;
      compareTo = COMPARE_TO_PROPERTY;
    }
  }

  public String getCompareValue() {
    return compareValue;
  }

  public void setCompareValue(String compareValue) {
    if (compareValue != null) {
      this.compareValue = compareValue;
      compareTo = COMPARE_TO_VALUE;
    }
  }


  public String getPropertyName() {
    return propertyName;
  }

  public void setPropertyName(String propertyName) {
    this.propertyName = propertyName;
  }

  protected long compare(Object parameterObject) {
    Class type = StaticBeanProbe.getPropertyTypeForGetter(parameterObject, getPropertyName());
    Object value1 = StaticBeanProbe.getObject(parameterObject, getPropertyName());
    if (compareTo == COMPARE_TO_PROPERTY) {
      Object value2 = StaticBeanProbe.getObject(parameterObject, getComparePropertyName());
      return compareValues(type, value1, value2);
    } else if (compareTo == COMPARE_TO_VALUE) {
      return compareValues(type, value1, compareValue);
    } else {
      throw new NestedRuntimeException("Error comparing in conditional fragment.  Uknown 'compare to' values.");
    }
  }

  protected long compareValues(Class type, Object value1, Object value2) {
    long result = NOT_COMPARABLE;

    if (value1 == null || value2 == null) {
      result = value1 == value2 ? 0 : NOT_COMPARABLE;
    } else {
      if (value2.getClass() != type) {
        value2 = convertValue(type, value2.toString());
      }
      if (value2 instanceof String && type != String.class) {
        value1 = value1.toString();
      }
      if (!(value1 instanceof Comparable && value2 instanceof Comparable)) {
        value1 = value1.toString();
        value2 = value2.toString();
      }
      result = ((Comparable) value1).compareTo(value2);
    }

    return result;
  }

  protected Object convertValue(Class type, String value) {
    if (type == String.class) {
      return value;
    } else if (type == Byte.class) {
      return Byte.valueOf(value);
    } else if (type == Short.class) {
      return Short.valueOf(value);
    } else if (type == Character.class) {
      return new Character(value.charAt(0));
    } else if (type == Integer.class) {
      return Integer.valueOf(value);
    } else if (type == Long.class) {
      return Long.valueOf(value);
    } else if (type == Float.class) {
      return Float.valueOf(value);
    } else if (type == Double.class) {
      return Double.valueOf(value);
    } else if (type == Boolean.class) {
      return Boolean.valueOf(value);
    } else if (type == Date.class) {
      try {
        return format.parse(value);
      } catch (ParseException e) {
        throw new NestedRuntimeException("Error parsing date.  Cause: " + e, e);
      }
    } else if (type == BigInteger.class) {
      return new BigInteger(value);
    } else if (type == BigDecimal.class) {
      return new BigDecimal(value);
    } else {
      return value;
    }

  }

}
