/**
 * User: Clinton Begin
 * Date: Apr 11, 2003
 * Time: 8:03:08 PM
 */
package com.ibatis.db.sqlmap.typehandler;

import com.ibatis.common.beans.*;
import com.ibatis.db.sqlmap.*;

import java.sql.*;

public abstract class BaseTypeHandler implements TypeHandler {

  public void setBeanProperty(ResultMapping mapping, ResultSet rs, Object object) throws SQLException {

    Object value;
    if (mapping.getColumnIndex() == null) {
      value = getValueByName(mapping, rs);
    } else {
      value = getValueByIndex(mapping, rs);
    }

    String nullValue = mapping.getNullValue();
    boolean wasNull = rs.wasNull();
    if (wasNull && nullValue != null) {
      value = getNullValue(nullValue);
    }

    String propertyName = mapping.getPropertyName();
    if (wasNull && nullValue == null) {
      StaticBeanProbe.setObject(object, propertyName, null);
    } else {
      StaticBeanProbe.setObject(object, propertyName, value);
    }
  }

  protected abstract Object getValueByName(ResultMapping mapping, ResultSet rs) throws SQLException;

  protected abstract Object getValueByIndex(ResultMapping mapping, ResultSet rs) throws SQLException;

  protected abstract Object getNullValue(String nullValue) throws SQLException;

}
