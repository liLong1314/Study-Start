/*
 * User: Clinton Begin
 * Date: Sep 21, 2002
 * Time: 1:00:10 PM
 */
package com.ibatis.db.sqlmap.datasource;

import javax.sql.DataSource;
import java.util.*;

public interface DataSourceFactory {

  public void initialize(Map map);

  public DataSource getDataSource();

  public String[] getExpectedProperties();

}
