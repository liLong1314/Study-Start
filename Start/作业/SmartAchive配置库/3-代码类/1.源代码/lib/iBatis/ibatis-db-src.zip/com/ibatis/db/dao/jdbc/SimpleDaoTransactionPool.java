/**
 * User: Clinton Begin
 * Date: Mar 15, 2003
 * Time: 2:12:24 PM
 */
package com.ibatis.db.dao.jdbc;

import com.ibatis.db.dao.DaoException;
import com.ibatis.db.dao.DaoTransaction;
import com.ibatis.db.dao.DaoTransactionPool;
import com.ibatis.db.jdbc.*;

import javax.sql.*;
import java.util.*;
import java.sql.*;

/**
 * A DaoTransactionPool implementation that uses SimpleDataSource to manage
 * a pool of JDBC Connection objects.
 *
 * @author  clinton_begin
 */
public class SimpleDaoTransactionPool implements DaoTransactionPool {

  private DataSource dataSource = null;

  /** Creates new JdbcDaoTransactionPool */
  public SimpleDaoTransactionPool() {
  }

  public void configure(Map props)
      throws DaoException {
    dataSource = new SimpleDataSource(props);
  }

  public void releaseTransaction(DaoTransaction trans)
      throws DaoException {
    if (dataSource == null) {
      throw new DaoException("DataSource is null in JdbcDaoTransactionPool (check the data source configuration).");
    }
    try {
      ((JdbcDaoTransaction) trans).getConnection().close();
    } catch (SQLException e) {
      throw new DaoException("Error releasing transaction.  Cause: " + e, e);
    }
  }

  public DaoTransaction getTransaction()
      throws DaoException {
    if (dataSource == null) {
      throw new DaoException("DataSource is null in JdbcDaoTransactionPool (check the data source configuration).");
    }
    try {
      Connection conn = dataSource.getConnection();
      if (conn.getAutoCommit()) {
        conn.setAutoCommit(false);
      }
      return new JdbcDaoTransaction(this, conn);
    } catch (SQLException e) {
      throw new DaoException("Error getting transaction.  Cause: " + e, e);
    }
  }

  public DataSource getDataSource() {
    return dataSource;
  }

}
