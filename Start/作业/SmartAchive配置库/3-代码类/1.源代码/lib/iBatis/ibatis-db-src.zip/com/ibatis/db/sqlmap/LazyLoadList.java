/**
 * User: Clinton Begin
 * Date: May 21, 2003
 * Time: 7:28:08 PM
 */
package com.ibatis.db.sqlmap;

import net.sf.cglib.*;
import net.sf.cglib.InvocationHandler;
import net.sf.cglib.Proxy;

import javax.sql.*;
import java.util.*;
import java.sql.*;
import java.lang.reflect.Method;

public class LazyLoadList implements InvocationHandler {

  private final Object LOAD_LOCK = new Object();
  private boolean loaded = false;

  private List list;

  private DataSource dataSource;
  private MappedStatement mappedStatement;
  private Object parameterObject;

  private static final Set passthroughMethods = new HashSet();

  static {
    passthroughMethods.add("finalize");
    passthroughMethods.add("getClass");
    passthroughMethods.add("notify");
    passthroughMethods.add("notifyAll");
    passthroughMethods.add("wait");
  }

  private LazyLoadList(DataSource ds, MappedStatement stmt, Object param) {
    this.dataSource = ds;
    this.mappedStatement = stmt;
    this.parameterObject = param;
  }


  public Object invoke(Object proxy, Method method, Object[] args)
      throws Throwable {
    synchronized (LOAD_LOCK) {
      if (!loaded && !passthroughMethods.contains(method.getName())) {
        Connection conn = dataSource.getConnection();
        list = mappedStatement.executeQueryForList(conn, parameterObject);
        conn.close();
        loaded = true;
      }
    }
    return method.invoke(list, args);
  }

  public static List newInstance(DataSource ds, MappedStatement stmt, Object param) {
    InvocationHandler handler = new LazyLoadList(ds, stmt, param);
    ClassLoader cl = List.class.getClassLoader();
    return (List) Proxy.newProxyInstance(cl, new Class[]{List.class}, handler);
  }

}


