/**
 * User: Clinton Begin
 * Date: Apr 11, 2003
 * Time: 10:56:30 PM
 */
package com.ibatis.db.sqlmap.typehandler;

import com.ibatis.db.sqlmap.value.*;
import com.ibatis.db.sqlmap.*;

import java.sql.*;
import java.io.*;

public class StringTypeHandler extends BaseTypeHandler {

  private static final int BUFFER_SIZE = 2048;

  protected Object getValueByName(ResultMapping mapping, ResultSet rs) throws SQLException {

    int type = mapping.getJdbcType();

    Object value = null;
    if (TypeRegistry.UNKNOWN_TYPE == type) {
      value = rs.getString(mapping.getColumnName());
    } else if (Types.CLOB == type) {
      Clob clob = rs.getClob(mapping.getColumnName());
      if (clob != null) {
        Reader reader = clob.getCharacterStream();
        value = readerToString(reader);
      }
    } else if (Types.LONGVARCHAR == type) {
      Reader reader = rs.getCharacterStream(mapping.getColumnName());
      value = readerToString(reader);
    } else {
      value = rs.getString(mapping.getColumnName());
    }
    return value;
  }

  protected Object getValueByIndex(ResultMapping mapping, ResultSet rs) throws SQLException {

    int type = mapping.getJdbcType();

    Object value = null;
    if (TypeRegistry.UNKNOWN_TYPE == type) {
      value = rs.getString(mapping.getColumnIndex().intValue());
    } else if (Types.CLOB == type) {
      Clob clob = rs.getClob(mapping.getColumnIndex().intValue());
      if (clob != null) {
        Reader reader = clob.getCharacterStream();
        value = readerToString(reader);
      }
    } else if (Types.LONGVARCHAR == type) {
        Reader reader = rs.getCharacterStream(mapping.getColumnIndex().intValue());
        value = readerToString(reader);
    } else {
      value = rs.getString(mapping.getColumnIndex().intValue());
    }
    return value;
  }

  protected Object getNullValue(String nullValue) throws SQLException {
    return nullValue;
  }

  public Object instantiateValue() {
    return new StringValue();
  }

  public boolean isEqualToNullValue(String nullValue, Object realValue) {
    return nullValue.equals(realValue);
  }

  public boolean isSimpleType() {
    return true;
  }

  public void setParameter(ParameterMapping mapping, PreparedStatement ps, int index, Object value) throws SQLException {

    int type = mapping.getJdbcType();

    String stringValue = (String) value;

    if (TypeRegistry.UNKNOWN_TYPE == type) {
      ps.setString(index, (stringValue));
    } else if (Types.CLOB == type || Types.LONGVARCHAR == type) {
      StringReader reader = new StringReader(stringValue);
      ps.setCharacterStream(index, reader, stringValue.length());
    } else {
      ps.setString(index, (stringValue));
    }

  }

  private static String readerToString(Reader reader) throws SQLException {
    String value = null;
    try {
      if (reader != null) {
        StringBuffer text = new StringBuffer();
        char[] buffer = new char[BUFFER_SIZE];
        int r = 0;
        while ((r = reader.read(buffer)) > 0) {
          text.append(buffer,0,r);
        }
        value = text.toString();
      }
    } catch (IOException e) {
      throw new SQLException ("Error reading character stream. Cause: " + e);
    }
    return value;
  }

}
