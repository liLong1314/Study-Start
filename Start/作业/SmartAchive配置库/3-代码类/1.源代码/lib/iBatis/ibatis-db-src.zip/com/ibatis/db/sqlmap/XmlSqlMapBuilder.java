package com.ibatis.db.sqlmap;

import org.jdom.*;
import org.jdom.input.*;

import java.io.*;
import java.util.*;

import com.ibatis.common.resources.*;
import com.ibatis.common.beans.*;
import com.ibatis.common.exception.*;
import com.ibatis.db.sqlmap.datasource.*;
import com.ibatis.db.sqlmap.dynamic.*;
import com.ibatis.db.sqlmap.cache.*;
import com.ibatis.db.sqlmap.typehandler.*;

import javax.sql.*;

/**
 *
 *
 * @author  clinton_begin
 *
 */
public class XmlSqlMapBuilder {

  private static final String LEGACY_CACHE_CLASS_NAME = "com.ibatis.db.sqlmap.cache.memory.MemoryCacheController";
  private static final Map cacheControllerAliases = new HashMap();

  private static final String PARAMETER_TOKEN = "#";

  private static final String DOT = ".";

  private static final String SETTINGS_ELEMENT = "settings";
  private static final String SQL_CONFIG_ELEMENT = "sql-map-config";
  private static final String DATASOURCE_ELEMENT = "datasource";
  private static final String PROPERTIES_ELEMENT = "properties";
  private static final String SQL_MAP_ELEMENT = "sql-map";
  private static final String RESULT_MAP_ELEMENT = "result-map";
  private static final String PARAMETER_MAP_ELEMENT = "parameter-map";
  private static final String MAPPED_STATEMENT_ELEMENT = "mapped-statement";
  private static final String CACHE_MODEL_ELEMENT = "cache-model";
  private static final String DYNAMIC_MAPPED_STATEMENT_ELEMENT = "dynamic-mapped-statement";
  private static final String PROPERTY_ELEMENT = "property";
  private static final String FLUSH_INTERVAL_ELEMENT = "flush-interval";
  private static final String FLUSH_ON_EXECUTE_ELEMENT = "flush-on-execute";
  private static final String CACHE_PROPERTY = "cache-property";

  private static Properties properties;
  private static boolean validationEnabled = true;

  static {
    cacheControllerAliases.put("MEMORY","com.ibatis.db.sqlmap.cache.memory.MemoryCacheController");
    cacheControllerAliases.put("LRU","com.ibatis.db.sqlmap.cache.lru.LruCacheController");
    cacheControllerAliases.put("FIFO","com.ibatis.db.sqlmap.cache.fifo.FifoCacheController");
    cacheControllerAliases.put("OSCACHE","com.ibatis.db.sqlmap.cache.oscache.OSCacheController");
  }

  public static boolean isValidationEnabled() {
    return validationEnabled;
  }

  public static void setValidationEnabled(boolean validationEnabled) {
    XmlSqlMapBuilder.validationEnabled = validationEnabled;
  }

  /**
   * @deprecated Use buildSqlMap(Reader reader)
   * @param file
   * @return
   */
  public static SqlMap buildSqlMap(File file) {
    SqlMap sqlMap = new SqlMap();

    properties = null;

    addDefaultLegacyCache(sqlMap, "STRONG");
    addDefaultLegacyCache(sqlMap, "SOFT");
    addDefaultLegacyCache(sqlMap, "WEAK");

    try {
      if (file != null) {
        if (file.isFile()) {
          parseSqlMapRoot(sqlMap, new FileReader(file), file.getAbsolutePath(), false);
        } else if (file.isDirectory()) {
          File[] files = file.listFiles();
          for (int i = 0; i < files.length; i++) {
            if (files[i].getName().endsWith(".xml")) {
              parseSqlMapRoot(sqlMap, new FileReader(files[i]), files[i].getAbsolutePath(), false);
            }
          }
        } else {
          throw new SqlMapException("Unkown error with input file/directory passed to XmlSqlMapBuilder.buildSqlMap().");
        }
      } else {
        throw new SqlMapException("Input file/directory passed to XmlSqlMapBuilder.buildSqlMap() was NULL.");
      }
    } catch (Exception e) {
      throw new SqlMapException("Error in XmlSqlMapBuilder.buildSqlMap(). \n\nCause: \n\n" + e, e);
    }

    registerCacheMappings(sqlMap);
    return sqlMap;
  }

  public static SqlMap buildSqlMap(Reader reader) {
    return buildSqlMap(reader, null, false);
  }

  public static SqlMap buildSqlMap(Reader reader, Properties props) {
    return buildSqlMap(reader, props, false);
  }

  public synchronized static SqlMap buildSqlMap(Reader reader, Properties props, boolean forValidationOnly) {
    properties = props;
    try {
      SqlMap sqlMap = new SqlMap();

      addDefaultLegacyCache(sqlMap, "STRONG");
      addDefaultLegacyCache(sqlMap, "SOFT");
      addDefaultLegacyCache(sqlMap, "WEAK");

      parseSqlMapRoot(sqlMap, reader, "[Reader passed to buildSqlMap()]", forValidationOnly);
      registerCacheMappings(sqlMap);
      return sqlMap;
    } catch (Exception e) {
      e.printStackTrace();
      throw new SqlMapException("Error while building SqlMap.  \n\nCause: \n\n" + e, e);
    }
  }

  /**
   * This method parses an SQL Map config root, or an individiaul Sql Map root.
   * It is not recommended that this method be called directly.  Instead one
   * of the build methods should be used.  This method is made public to
   * support 3rd party plugin support for managing SqlMap builds.
   * @param sqlMap
   * @param reader
   * @param resourceName
   * @param forValidationOnly
   * @throws IOException
   * @throws JDOMException
   */
  public static void parseSqlMapRoot(SqlMap sqlMap, Reader reader, String resourceName, boolean forValidationOnly)
      throws IOException, JDOMException {

    SAXBuilder builder = new SAXBuilder();
    builder.setEntityResolver(new SqlMapJarEntityResolver());
    builder.setValidation(validationEnabled);

    Document doc = builder.build(reader);

    Element root = doc.getRootElement();

    String rootname = root.getName();
    if (SQL_MAP_ELEMENT.equals(rootname)) {
      includeSqlMap(sqlMap, root, resourceName);
    } else if (SQL_CONFIG_ELEMENT.equals(rootname)) {
      parseSqlMapConfig(sqlMap, root, resourceName, forValidationOnly);
    } else {
      throw new IOException("The root tag of the SqlMap XML document must be '" + SQL_MAP_ELEMENT + "' or '" + SQL_CONFIG_ELEMENT + "'.");
    }

  }

  private static void registerCacheMappings(SqlMap sqlMap) {
    Iterator i = sqlMap.getCaches();
    while (i.hasNext()) {
      CacheModel cache = (CacheModel) i.next();
      Iterator j = cache.getFlushTriggerStatements();
      while (j.hasNext()) {
        try {
          String statementName = (String) j.next();
          MappedStatement mappedStatement = sqlMap.getMappedStatement(statementName);
          mappedStatement.addExecuteListener(cache);
        } catch (SqlMapException e) {
          throw new SqlMapException("Error registering cache '" + cache.getName() + "' in '" + cache.getResourceName() + "'. Cause: " + e.toString(), e);
        }
      }
    }
  }


  private static void parseSqlMapConfig(SqlMap sqlMap, Element element, String resourceName, boolean forValidationOnly)
      throws IOException, JDOMException {

    List children = element.getChildren();
    for (int i = 0; i < children.size(); i++) {
      Element child = (Element) children.get(i);

      if (SQL_MAP_ELEMENT.equals(child.getName())) {
        String resource = getAttributeValue(child, "resource", true);
        includeSqlMap(sqlMap, resource, forValidationOnly);
      } else if (PROPERTIES_ELEMENT.equals(child.getName())) {
        String resource = getAttributeValue(child, "resource", true);
        properties = Resources.getResourceAsProperties(resource);
      } else if (SETTINGS_ELEMENT.equals(child.getName())) {
        parseSettingsElement(sqlMap, child);
      } else if (DATASOURCE_ELEMENT.equals(child.getName())) {
        if (!forValidationOnly) {
          parseDataSource(sqlMap, child, resourceName);
        }
      } else {
        throw new SqlMapException("Uknown element '" + child.getName() + "' in " + resourceName);
      }
    }
  }

  private static void parseSettingsElement(SqlMap sqlMap, Element child) {
    int value = getAttributeValueAsInt(child, "maxExecute", false);
    if (value > 0) sqlMap.setMaxExecute(value);

    value = getAttributeValueAsInt(child, "maxExecutePerConnection", false);
    if (value > 0) sqlMap.setMaxExecutePerConnection(value);

    value = getAttributeValueAsInt(child, "maxTransactions", false);
    if (value > 0) sqlMap.setMaxTransactions(value);

    value = getAttributeValueAsInt(child, "statementCacheSize", false);
    if (value > 0) sqlMap.setStatementCacheSize(value);

    String utxName = getAttributeValue(child, "userTransactionJndiName", false);
    if (utxName != null && utxName.length() > 0) sqlMap.setUserTransactionJndiName(utxName);

    sqlMap.setUseGlobalTransaction("true".equals(getAttributeValue(child, "useGlobalTransactions", false)));

    String useBeansMetaClasses = getAttributeValue(child, "useBeansMetaClasses", false);
    if (useBeansMetaClasses != null) {
      StaticBeanProbe.setUseMetaClasses("true".equals(useBeansMetaClasses));
    } else {
      StaticBeanProbe.setUseMetaClasses(false);
    }

    String useFullyQualifiedStatementNames = getAttributeValue(child, "useFullyQualifiedStatementNames", false);
    if (useFullyQualifiedStatementNames != null) {
      sqlMap.setUseFullyQualifiedStatementNames("true".equals(useFullyQualifiedStatementNames));
    } else {
      sqlMap.setUseFullyQualifiedStatementNames(false);
    }

    String cacheModelsEnabled = getAttributeValue(child, "cacheModelsEnabled", false);
    if (cacheModelsEnabled != null) {
      sqlMap.setCacheModelsEnabled("true".equals(cacheModelsEnabled));
    } else {
      sqlMap.setCacheModelsEnabled(true);
    }

    String startTransactionBeforeConnection = getAttributeValue(child, "startTransactionBeforeConnection", false);
    if (startTransactionBeforeConnection != null) {
      sqlMap.setStartTransactionBeforeConnection("true".equals(startTransactionBeforeConnection));
    } else {
      sqlMap.setStartTransactionBeforeConnection(true);
    }

    String driverHintsEnabled = getAttributeValue(child, "driverHintsEnabled", false);
    if (driverHintsEnabled != null) {
      sqlMap.setDriverHintsEnabled("true".equals(driverHintsEnabled));
    } else {
      sqlMap.setDriverHintsEnabled(false);
    }
  }

  private static void parseDataSource(SqlMap sqlMap, Element element, String resourceName) {

    String dataSourceName = getAttributeValue(element, "name", true);
    String factoryClass = getAttributeValue(element, "factory-class", true);

    Properties props = new Properties();
    List children = element.getChildren();
    for (int i = 0; i < children.size(); i++) {
      Element child = (Element) children.get(i);
      if (PROPERTY_ELEMENT.equals(child.getName())) {
        String name = getAttributeValue(child, "name", true);
        String value = getAttributeValue(child, "value", true);
        props.setProperty(name, value);
      } else {
        throw new SqlMapException("Uknown element '" + child.getName() + "' in " + resourceName);
      }
    }

    try {
      Class type = Class.forName(factoryClass);
      DataSourceFactory factory = (DataSourceFactory) type.newInstance();
      factory.initialize(props);
      DataSource dataSource = factory.getDataSource();

      sqlMap.addDataSource(dataSourceName, dataSource);

    } catch (ClassNotFoundException e) {
      throw new SqlMapException("Invalid DataSourceFactory class. Cause: " + e, e);
    } catch (InstantiationException e) {
      throw new SqlMapException("Could not instantiate DataSourceFactory. Cause: " + e, e);
    } catch (IllegalAccessException e) {
      throw new SqlMapException("Could not access constructor for DataSourceFactory class. Cause: " + e, e);
    }

    boolean defaultDataSource = "true".equals(getAttributeValue(element, "default", false));
    if (defaultDataSource) {
      if (sqlMap.getCurrentDataSource() == null) {
        sqlMap.setCurrentDataSourceName(dataSourceName);
      } else {
        throw new SqlMapException("Error.  There can be only one default Data Source for a SQL Map.");
      }
    }

  }


  private static void includeSqlMap(SqlMap sqlMap, String resource, boolean forValidationOnly)
      throws IOException, JDOMException {
    parseSqlMapRoot(sqlMap, new InputStreamReader(Resources.getResourceAsStream(resource)), resource, forValidationOnly);
  }

  private static void includeSqlMap(SqlMap sqlMap, Element element, String resourceName) {

    String sqlMapName = getAttributeValue(element, "name", true);

    List children = element.getChildren();
    for (int i = 0; i < children.size(); i++) {
      Element child = (Element) children.get(i);

      if (PARAMETER_MAP_ELEMENT.equals(child.getName())) {
        ParameterMap parameterMap = buildParameterMap(child, sqlMapName, resourceName);
        sqlMap.addParameterMap(parameterMap);
      } else if (RESULT_MAP_ELEMENT.equals(child.getName())) {
        ResultMap resultMap = buildResultMap(sqlMap, child, sqlMapName, resourceName);
        sqlMap.addResultMap(resultMap);
      } else if (CACHE_MODEL_ELEMENT.equals(child.getName())) {
        if (sqlMap.isCacheModelsEnabled()) {
          CacheModel cache = buildCache(child, resourceName);
          sqlMap.addCache(cache);
        }
      } else if (DYNAMIC_MAPPED_STATEMENT_ELEMENT.equals(child.getName())) {
        DynamicMappedStatement dynStatement = buildDynamicMappedStatement(child, sqlMap, sqlMapName, resourceName);
        if (sqlMap.isUseFullyQualifiedStatementNames()) {
          dynStatement.setName(sqlMapName + "." + dynStatement.getName());
        }
        sqlMap.addMappedStatement(dynStatement);
      } else if (MAPPED_STATEMENT_ELEMENT.equals(child.getName())) {
        MappedStatement mappedStatement = buildMappedStatement(child, sqlMap, sqlMapName, resourceName);
        if (sqlMap.isUseFullyQualifiedStatementNames()) {
          mappedStatement.setName(sqlMapName + "." + mappedStatement.getName());
        }
        sqlMap.addMappedStatement(mappedStatement);
      } else {
        throw new SqlMapException("Uknown element '" + child.getName() + "' in " + resourceName);
      }

    }

  }

  private static void addDefaultLegacyCache (SqlMap sqlMap, String refType) {
    Properties props = new Properties();
    props.setProperty("reference-type",refType);
    CacheModel cache = new CacheModel();
    cache.setName(refType);
    cache.setControllerClassName(LEGACY_CACHE_CLASS_NAME);
    cache.configureController(props);
    sqlMap.addCache(cache);
  }

  private static CacheModel buildCache(Element element, String resourceName) {
    String name = getAttributeValue(element, "name", true);
    String implementation = getAttributeValue(element, "implementation", false);
    String refType = getAttributeValue(element, "reference-type", false);

    if (implementation == null && refType == null) {
      throw new SqlMapException ("Error building the cache-model named '"+name+"' in resource '"+resourceName+"'.  Cause: Either an implementation (preferred) or a reference-type (legacy) attribute must be specified.");
    }

    Properties props = new Properties ();

    // Backward compatibility
    if (implementation == null ) {
      implementation = LEGACY_CACHE_CLASS_NAME;
    }
    if (refType != null) {
      props.put("reference-type", refType);
    }

    String alias = (String)cacheControllerAliases.get(implementation);
    if (alias != null) {
      implementation = alias;
    }

    CacheModel cache = new CacheModel();
    cache.setName(name);
    cache.setResourceName(resourceName);
    cache.setControllerClassName(implementation);

    List children = element.getChildren();
    for (int i = 0; i < children.size(); i++) {
      Element child = (Element) children.get(i);

      if (FLUSH_INTERVAL_ELEMENT.equals(child.getName())) {
        long t = 0;
        try {
          String milliseconds = getAttributeValue(child, "milliseconds", false);
          String seconds = getAttributeValue(child, "seconds", false);
          String minutes = getAttributeValue(child, "minutes", false);
          String hours = getAttributeValue(child, "hours", false);
          if (milliseconds != null) t += Integer.parseInt(milliseconds);
          if (seconds != null) t += Integer.parseInt(seconds) * 1000;
          if (minutes != null) t += Integer.parseInt(minutes) * 60 * 1000;
          if (hours != null) t += Integer.parseInt(hours) * 60 * 60 * 1000;
          if (t < 1) throw new NestedRuntimeException("A flush interval must specify one or more of milliseconds, seconds, minutes or hours.");
          cache.setFlushInterval(t);
        } catch (NumberFormatException e) {
          throw new SqlMapException("Error building cache '" + cache.getName() + "' in '" + resourceName + "'.  Flush interval milliseconds must be a valid long integer value.  Cause: " + e, e);
        }
      } else if (FLUSH_ON_EXECUTE_ELEMENT.equals(child.getName())) {
        cache.addFlushTriggerStatement(getAttributeValue(child, "statement", true));
      } else if (CACHE_PROPERTY.equals(child.getName())) {
        props.setProperty(getAttributeValue(child, "name", true),getAttributeValue(child, "value", true));
      } else {
        throw new SqlMapException("Uknown element '" + child.getName() + "' in " + resourceName);
      }
    }

    cache.configureController(props);

    return cache;
  }

  private static ParameterMap buildParameterMap(Element element, String sqlMapName, String resourceName) {
    ParameterMap parameterMap = new ParameterMap();

    parameterMap.setName(getAttributeValue(element, "name", true));

    List children = element.getChildren();
    for (int i = 0; i < children.size(); i++) {
      Element child = (Element) children.get(i);

      if (PROPERTY_ELEMENT.equals(child.getName())) {

        String prop = getAttributeValue(child, "name", true);
        String type = getAttributeValue(child, "type", false);
        String nullValue = getAttributeValue(child, "null", false);
        String outParam = getAttributeValue(child, "out-param", false);

        ParameterMapping mapping = new ParameterMapping();
        mapping.setResourceName(resourceName);
        mapping.setPropertyName(prop);

        if (type != null) {
          mapping.setType(type);
        }

        if (nullValue != null) {
          mapping.setNullValue(nullValue);
        }

        if (outParam != null) {
          mapping.setOutputParameter("true".equals(outParam));
        } else {
          mapping.setOutputParameter(false);
        }

        parameterMap.addParameterMapping(mapping);

      } else {
        throw new SqlMapException("Uknown element '" + child.getName() + "' in " + resourceName);
      }
    }

    parameterMap.setName(sqlMapName + DOT + parameterMap.getName());

    return parameterMap;
  }

  private static ResultMap buildResultMap(SqlMap sqlMap, Element element, String sqlMapName, String resourceName) {
    ResultMap resultMap = new ResultMap();

    resultMap.setName(getAttributeValue(element, "name", true));
    resultMap.setClassName(getAttributeValue(element, "class", true));
    String extendsMap = getAttributeValue(element, "extends", false);

    if (extendsMap != null && !"".equals(extendsMap)) {
      try {
        ResultMap superMap = sqlMap.getResultMap(sqlMapName +"."+ extendsMap);
        Iterator i = superMap.getMappedPropertyNames();
        while (i.hasNext()) {
          String propName = (String)i.next();
          resultMap.addResultMapping(superMap.getResultMapping(propName));
        }
      } catch (Exception e) {
        throw new SqlMapException ("Error building SQL Map.  There was a problem with 'extends' in map named "+resultMap.getName()+".  Cause: "+e);
      }
    }

    List children = element.getChildren();
    for (int i = 0; i < children.size(); i++) {
      Element child = (Element) children.get(i);

      if (PROPERTY_ELEMENT.equals(child.getName())) {
        String name = getAttributeValue(child, "name", true);
        String column = getAttributeValue(child, "column", false);

        ResultMapping mapping = new ResultMapping();

        mapping.setPropertyName(name);
        mapping.setColumnName(column);
        mapping.setResourceName(resourceName);

        String columnIndex = getAttributeValue(child, "columnIndex", false);
        if (columnIndex != null && columnIndex.length() > 0) {
          mapping.setColumnIndex(new Integer(columnIndex));
        }

        String statement = getAttributeValue(child, "mapped-statement", false);
        if (statement != null && statement.length() > 0) {
          mapping.setStatementName(statement);
        }

        String lazyLoad = getAttributeValue(child, "lazy-load", false);
        if (lazyLoad != null && lazyLoad.length() > 0) {
          mapping.setLazyLoad("true".equals(lazyLoad));
        } else {
          // default to true
          mapping.setLazyLoad(true);
        }

        String type = getAttributeValue(child, "type", false);
        if (type != null && type.length() > 0) {
          mapping.setType(type);
        }

        String nullValue = getAttributeValue(child, "null", false);
        if (nullValue != null) {
          mapping.setNullValue(nullValue);
        }

        String propertyType = getAttributeValue(child, "javaType", false);
        if (propertyType != null && propertyType.length() > 0) {
          try {
            Class cls = Class.forName(propertyType);
            TypeHandler handler = TypeHandlerFactory.getTypeHandler(cls);
            mapping.setPropertyType(cls);
            mapping.setTypeHandler(handler);
          } catch (Exception e) {
            throw new SqlMapException("Uknown class \n" + e + "\n" + child.getName() + "' in " + resourceName, e);
          }
        }
        
        resultMap.addResultMapping(mapping);

      } else {
        throw new SqlMapException("Uknown element '" + child.getName() + "' in " + resourceName);
      }
    }

    resultMap.setName(sqlMapName + DOT + resultMap.getName());

    return resultMap;
  }

  private static DynamicMappedStatement buildDynamicMappedStatement(Element element, SqlMap sqlMap, String sqlMapName, String resourceName) {
    DynamicMappedStatement dynStatement = new DynamicMappedStatement();
    dynStatement.setResourceName(resourceName);

    dynStatement.setName(getAttributeValue(element, "name", true));

    dynStatement.setParameterClass(getAttributeValue(element, "parameter-class", false));
    dynStatement.setResultClass(getAttributeValue(element, "result-class", false));

    dynStatement.setResultMapName(getAttributeValue(element, "result-map", false));
    dynStatement.setStoredProcedure("true".equals(getAttributeValue(element, "is-stored-procedure", false)));

    if (sqlMap.isCacheModelsEnabled()) {
      String cacheName = getAttributeValue(element, "cache-model", false);
      if (cacheName != null) {
        try {
          dynStatement.setCache(sqlMap.getCache(cacheName));
        } catch (SqlMapException e) {
          throw new SqlMapException("Error building mapped statement '" + dynStatement.getName() + "' in '" + resourceName + "'.  Cause: " + e.toString(), e);
        }
      }
    }

    dynStatement.setInline(true);
    dynStatement.addAllChildFragment(buildFragmentList(element));

    dynStatement.setSqlMap(sqlMap);

    if (dynStatement.isInline()) {
      dynStatement.setParameterMapName(sqlMapName + DOT + dynStatement.getName() + "-inline");
    }

    String parameterMapName = dynStatement.getParameterMapName();
    if (parameterMapName != null && parameterMapName.indexOf(DOT) < 0) {
      dynStatement.setParameterMapName(sqlMapName + DOT + dynStatement.getParameterMapName());
    }

    String resultMapName = dynStatement.getResultMapName();
    if (resultMapName != null && resultMapName.indexOf(DOT) < 0) {
      dynStatement.setResultMapName(sqlMapName + DOT + dynStatement.getResultMapName());
    }

    return dynStatement;
  }

  private static List buildFragmentList(Element element) {
    List fragmentList = new ArrayList();
    Iterator children = element.getContent().iterator();
    while (children.hasNext()) {
      Object child = children.next();
      if (child instanceof Element) {
        Element childElement = (Element) child;
        if ("dynamic".equals(childElement.getName())) {
          DynamicFragment fragment = new DynamicFragment();
          fragment.setPrepend(getAttributeValue(childElement, "prepend", false));
          fragment.addAllChildFragment(buildFragmentList(childElement));
          fragmentList.add(fragment);
        } else {
          BaseFragment fragment = null;
          if ("isEqual".equals(childElement.getName())) {
            fragment = new IsEqualFragment();
          } else if ("isNotEqual".equals(childElement.getName())) {
            fragment = new IsNotEqualFragment();
          } else if ("isParameterPresent".equals(childElement.getName())) {
            fragment = new IsParameterPresentFragment();
          } else if ("isNotParameterPresent".equals(childElement.getName())) {
            fragment = new IsNotParameterPresentFragment();
          } else if ("isEmpty".equals(childElement.getName())) {
            fragment = new IsEmptyFragment();
          } else if ("isNotEmpty".equals(childElement.getName())) {
            fragment = new IsNotEmptyFragment();
          } else if ("isNull".equals(childElement.getName())) {
            fragment = new IsNullFragment();
          } else if ("isNotNull".equals(childElement.getName())) {
            fragment = new IsNotNullFragment();
          } else if ("isPropertyAvailable".equals(childElement.getName())) {
            fragment = new IsPropertyAvailableFragment();
          } else if ("isNotPropertyAvailable".equals(childElement.getName())) {
            fragment = new IsNotPropertyAvailableFragment();
          } else if ("isGreaterThan".equals(childElement.getName())) {
            fragment = new IsGreaterThanFragment();
          } else if ("isGreaterEqual".equals(childElement.getName())) {
            fragment = new IsGreaterEqualFragment();
          } else if ("isLessThan".equals(childElement.getName())) {
            fragment = new IsLessThanFragment();
          } else if ("isLessEqual".equals(childElement.getName())) {
            fragment = new IsLessEqualFragment();
          } else if ("iterate".equals(childElement.getName())) {
            fragment = new IterateFragment();
          } else {
            throw new SqlMapException("Unknown conditional tag: " + element.getName());
          }
          if (fragment instanceof ConditionalFragment) {
            ConditionalFragment conditionalFragment = (ConditionalFragment) fragment;
            conditionalFragment.setPrepend(getAttributeValue(childElement, "prepend", false));
            conditionalFragment.setPropertyName(getAttributeValue(childElement, "property", false));
            conditionalFragment.setCompareValue(getAttributeValue(childElement, "compareValue", false));
            conditionalFragment.setComparePropertyName(getAttributeValue(childElement, "compareProperty", false));
            conditionalFragment.setSqlFragment(childElement.getText());
            conditionalFragment.addAllChildFragment(buildFragmentList(childElement));
          } else if (fragment instanceof IterateFragment) {
            IterateFragment iterateFragment = (IterateFragment) fragment;
            iterateFragment.setPrepend(getAttributeValue(childElement, "prepend", false));
            iterateFragment.setPropertyName(getAttributeValue(childElement, "property", false));
            iterateFragment.setClose(getAttributeValue(childElement, "close", false));
            iterateFragment.setOpen(getAttributeValue(childElement, "open", false));
            iterateFragment.setConjunction(getAttributeValue(childElement, "conjunction", false));
            iterateFragment.setSqlFragment(childElement.getText());
            iterateFragment.addAllChildFragment(buildFragmentList(childElement));
          }
          fragmentList.add(fragment);
        }
      } else if (child instanceof CDATA) {
        StaticFragment fragment = new StaticFragment();
        String sql = ((CDATA) child).getText();
        sql = parsePropertyTokens(sql, properties);
        fragment.setSqlFragment(sql);
        fragmentList.add(fragment);
      } else if (child instanceof Text) {
        StaticFragment fragment = new StaticFragment();
        String sql = ((Text) child).getText();
        sql = parsePropertyTokens(sql, properties);
        fragment.setSqlFragment(sql);
        fragmentList.add(fragment);
      }
    }
    return fragmentList;
  }

  private static MappedStatement buildMappedStatement(Element element, SqlMap sqlMap, String sqlMapName, String resourceName) {
    MappedStatement mappedStatement = new MappedStatement();
    mappedStatement.setResourceName(resourceName);

    mappedStatement.setName(getAttributeValue(element, "name", true));
    mappedStatement.setParameterMapName(getAttributeValue(element, "parameter-map", false));
    mappedStatement.setResultMapName(getAttributeValue(element, "result-map", false));
    mappedStatement.setStoredProcedure("true".equals(getAttributeValue(element, "is-stored-procedure", false)));

    if (sqlMap.isCacheModelsEnabled()) {
      String cacheName = getAttributeValue(element, "cache-model", false);
      if (cacheName != null) {
        try {
          mappedStatement.setCache(sqlMap.getCache(cacheName));
        } catch (SqlMapException e) {
          throw new SqlMapException("Error building mapped statement '" + mappedStatement.getName() + "' in '" + resourceName + "'.  Cause: " + e.toString(), e);
        }
      }
    }

    mappedStatement.setParameterClass(getAttributeValue(element, "parameter-class", false));
    mappedStatement.setResultClass(getAttributeValue(element, "result-class", false));

    String isInline = getAttributeValue(element, "inline-parameters", false);
    if (isInline == null && mappedStatement.getParameterMapName() == null) {
      mappedStatement.setInline(true);
    } else {
      mappedStatement.setInline("true".equals(isInline));
    }

    String text = element.getText();
    if (text != null && text.trim().length() > 0) {
      String sql = text.trim();
      sql = parsePropertyTokens(sql, properties);
      mappedStatement.setSql(sql);
    } else {
      throw new SqlMapException("A mapped statement element requires body content in " + resourceName);
    }

    mappedStatement.setSqlMap(sqlMap);

    if (mappedStatement.isInline()) {
      mappedStatement.setParameterMapName(sqlMapName + DOT + mappedStatement.getName() + "-inline");
      processInlineParameterMap(mappedStatement, resourceName);
    }

    String parameterMapName = mappedStatement.getParameterMapName();
    if (parameterMapName != null && parameterMapName.indexOf(DOT) < 0) {
      mappedStatement.setParameterMapName(sqlMapName + DOT + mappedStatement.getParameterMapName());
    }

    String resultMapName = mappedStatement.getResultMapName();
    if (resultMapName != null && resultMapName.indexOf(DOT) < 0) {
      mappedStatement.setResultMapName(sqlMapName + DOT + mappedStatement.getResultMapName());
    }

    return mappedStatement;
  }


  private static void processInlineParameterMap(MappedStatement mappedStatement, String resourceName) {

    ParameterMap parameterMap = new ParameterMap();
    parameterMap.setName(mappedStatement.getParameterMapName());

    StringTokenizer parser = new StringTokenizer(mappedStatement.getSql(null), PARAMETER_TOKEN, true);
    StringBuffer newSql = new StringBuffer();


    String token = null;
    String lastToken = null;
    while (parser.hasMoreTokens()) {
      token = parser.nextToken();

      if (PARAMETER_TOKEN.equals(lastToken)) {
        if (PARAMETER_TOKEN.equals(token)) {
          newSql.append(PARAMETER_TOKEN);
          token = null;
        } else {
          if (token.indexOf(':') > -1) {
            StringTokenizer paramParser = new StringTokenizer(token, ":", true);
            int n = paramParser.countTokens();
            if (n == 3) {
              String name = paramParser.nextToken();
              paramParser.nextToken(); //ignore ":"
              String type = paramParser.nextToken();
              ParameterMapping mapping = new ParameterMapping();
              mapping.setResourceName(resourceName);
              mapping.setPropertyName(name);
              mapping.setType(type);
              parameterMap.addParameterMapping(mapping);
            } else if (n >= 5) {
              String name = paramParser.nextToken();
              paramParser.nextToken(); //ignore ":"
              String type = paramParser.nextToken();
              paramParser.nextToken(); //ignore ":"
              String nullValueOrOutParam = paramParser.nextToken();
              String nullValue = null;
              boolean outParam = false;
              if ("OUT!".equals(nullValueOrOutParam)) {
                outParam=true;
              } else {
                nullValue = nullValueOrOutParam;
                while (paramParser.hasMoreTokens()) {
                  nullValue = nullValue + paramParser.nextToken();
                }
              }
              ParameterMapping mapping = new ParameterMapping();
              mapping.setResourceName(resourceName);
              mapping.setPropertyName(name);
              mapping.setType(type);
              mapping.setNullValue(nullValue);
              mapping.setOutputParameter(outParam);
              parameterMap.addParameterMapping(mapping);
            } else if (n >= 7) {
              String name = paramParser.nextToken();
              paramParser.nextToken(); //ignore ":"
              String type = paramParser.nextToken();
              paramParser.nextToken(); //ignore ":"
              String outParam = paramParser.nextToken();
              paramParser.nextToken(); //ignore ":"
              String nullValue = paramParser.nextToken();
              while (paramParser.hasMoreTokens()) {
                nullValue = nullValue + paramParser.nextToken();
              }
              ParameterMapping mapping = new ParameterMapping();
              mapping.setResourceName(resourceName);
              mapping.setPropertyName(name);
              mapping.setType(type);
              mapping.setNullValue(nullValue);
              mapping.setOutputParameter("OUT!".equals(outParam));
              parameterMap.addParameterMapping(mapping);
            } else {
              throw new SqlMapException("Incorrect inline parameter map format: " + token);
            }
          } else {
            ParameterMapping mapping = new ParameterMapping();
            mapping.setResourceName(resourceName);
            mapping.setPropertyName(token);
            parameterMap.addParameterMapping(mapping);
          }
          newSql.append("?");
          token = parser.nextToken();
          if (!PARAMETER_TOKEN.equals(token)) {
            throw new SqlMapException("Unterminated inline parameter in mapped statement (" + mappedStatement.getName() + ").");
          }
          token = null;
        }
      } else {
        if (!PARAMETER_TOKEN.equals(token)) {
          newSql.append(token);
        }
      }

      lastToken = token;
    }

    mappedStatement.setSql(newSql.toString());

    mappedStatement.getSqlMap().addParameterMap(parameterMap);

  }

  private static int getAttributeValueAsInt(Element element, String attributeName, boolean required) {
    String val = getAttributeValue(element, attributeName, required);
    try {
      if (val != null && !"".equals(val)) {
        return Integer.parseInt(val);
      } else {
        return -1;
      }
    } catch (NumberFormatException e) {
      throw new SqlMapException("Error configuring SqlMap.  The attribute named '" + attributeName + "' must be an integer (was " + val + ").  Cause: " + e, e);
    }
  }

  private static String getAttributeValue(Element element, String attributeName, boolean required) {
    String value = null;

    Attribute attrib = element.getAttribute(attributeName);
    if (attrib != null) {
      value = attrib.getValue();
    }

    value = parsePropertyTokens (value, properties);

    if (required && (value == null)) {
      throw new SqlMapException("Error while building SQL Map.  A '" + element.getName() + "' element requires a '" + attributeName + "' attribute.");
    }

    return value;
  }

  private static String parsePropertyTokens(String string, Properties props) {
    final String OPEN = "${";
    final String CLOSE = "}";
    String newString = string;
    if (newString != null && props != null) {
      int start = newString.indexOf(OPEN);
      int end = newString.indexOf(CLOSE);

      while (start > -1 && end > start) {
        String prepend = newString.substring(0, start);
        String append = newString.substring(end + CLOSE.length());
        String propName = newString.substring(start + OPEN.length(), end);
        String propValue = props.getProperty(propName);
        if (propValue == null) {
          newString = prepend + append;
        } else {
          newString = prepend + propValue + append;
        }
        start = newString.indexOf(OPEN);
        end = newString.indexOf(CLOSE);
      }
    }
    return newString;
  }

}
