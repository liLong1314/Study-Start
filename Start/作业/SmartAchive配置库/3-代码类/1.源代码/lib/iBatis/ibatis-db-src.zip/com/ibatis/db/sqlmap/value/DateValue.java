/**
 * User: Clinton Begin
 * Date: Feb 20, 2003
 * Time: 7:43:35 PM
 */
package com.ibatis.db.sqlmap.value;

import java.util.*;

public class DateValue extends BaseValue {

  public DateValue() {
  }

  public DateValue(Date value) {
    super(value);
  }

  public Date getValue() {
    return (Date) value;
  }

  public void setValue(Date value) {
    this.value = value;
  }

}
