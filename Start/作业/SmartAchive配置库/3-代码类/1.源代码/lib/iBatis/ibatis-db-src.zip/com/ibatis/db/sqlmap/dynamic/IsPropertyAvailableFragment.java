/**
 * User: Clinton Begin
 * Date: Mar 3, 2003
 * Time: 7:36:04 PM
 */
package com.ibatis.db.sqlmap.dynamic;

import com.ibatis.common.beans.StaticBeanProbe;

public class IsPropertyAvailableFragment extends ConditionalFragment {

  public boolean isCondition(Object parameterObject) {
    return StaticBeanProbe.hasReadableProperty(parameterObject, getPropertyName());
  }

}
