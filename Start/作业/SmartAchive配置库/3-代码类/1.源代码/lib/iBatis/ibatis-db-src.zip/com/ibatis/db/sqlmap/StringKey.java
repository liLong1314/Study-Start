package com.ibatis.db.sqlmap;

/**
 * @deprecated
 */
public class StringKey {

  /** Holds value of property key. */
  private String key;

  /** Creates a new instance of StringKey */
  public StringKey() {
  }

  public StringKey(String key) {
    this.key = key;
  }

  /** Getter for property key.
   * @return Value of property key.
   */
  public String getKey() {
    return this.key;
  }

  /** Setter for property key.
   * @param key New value of property key.
   */
  public void setKey(String key) {
    this.key = key;
  }

  public boolean equals(Object o) {
    if (this == o) return true;
    if (!(o instanceof StringKey)) return false;

    final StringKey stringKey = (StringKey) o;

    if (key != null ? !key.equals(stringKey.key) : stringKey.key != null) return false;

    return true;
  }

  public int hashCode() {
    return (key != null ? key.hashCode() : 0);
  }
}
