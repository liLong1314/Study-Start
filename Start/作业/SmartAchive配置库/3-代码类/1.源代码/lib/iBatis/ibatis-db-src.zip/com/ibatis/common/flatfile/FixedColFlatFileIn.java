package com.ibatis.common.flatfile;

import java.io.*;
import java.util.*;

/**
 *
 *
 * @author  clinton_begin
 *
 */

public class FixedColFlatFileIn extends Object implements FlatFileIn {

  private LineNumberReader reader = null;
  private ArrayList values = new ArrayList();
  private int[] coldef = null;
  private int linelength = 0;

  /** Creates new FixedColFlatFileIn */
  public FixedColFlatFileIn(String filename, int[] coldef) throws IOException {
    this.reader = new LineNumberReader(new FileReader(filename));
    this.coldef = coldef;
    for (int i = 0; i < coldef.length; i++) {
      linelength += coldef[i];
    }
  }

  public int getColumnCount() throws IOException {
    return coldef.length;
  }

  public String getValueAt(int col) throws IOException {
    return (String) values.get(col);
  }

  public void close() throws IOException {
    reader.close();
  }

  public boolean nextRecord() throws IOException {
    values.clear();

    String line = reader.readLine();

    if (line == null) {
      return false;
    }

    if (line.length() != linelength) {
      throw new IOException("Inconsistent length of row.");
    }

    int pos = 0;
    for (int i = 0; i < coldef.length; i++) {
      values.add(line.substring(pos, coldef[i] + pos).trim());
      pos += coldef[i];
    }

    return true;
  }

}
