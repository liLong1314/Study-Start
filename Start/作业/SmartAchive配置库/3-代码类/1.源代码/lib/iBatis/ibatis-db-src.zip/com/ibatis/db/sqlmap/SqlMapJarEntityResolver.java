/**
 * User: Clinton Begin
 * Date: Feb 22, 2003
 * Time: 6:57:50 PM
 */
package com.ibatis.db.sqlmap;

import org.xml.sax.*;

import java.io.*;

import com.ibatis.common.resources.*;

/** Custom EntityResolver that maps DTD requests for iBATIS DTDs to
 *  local resources.
 * @author Clinton Begin
 */
public class SqlMapJarEntityResolver implements EntityResolver {

  private static final String SYSTEM_ID_SQL_MAP_CONFIG = "http://www.ibatis.com/dtd/sql-map-config.dtd";
  private static final String SYSTEM_ID_SQL_MAP = "http://www.ibatis.com/dtd/sql-map.dtd";
  private static final String DTD_PATH_SQL_MAP_CONFIG = "com/ibatis/db/sqlmap/sql-map-config.dtd";
  private static final String DTD_PATH_SQL_MAP = "com/ibatis/db/sqlmap/sql-map.dtd";

  /** Converts a public DTD into a local one
   * @param publicId Unused but required by EntityResolver interface
   * @param systemId The DTD that is being requested
   * @throws SAXException If anything goes wrong
   * @return The InputSource for the DTD
   */
  public InputSource resolveEntity(String publicId, String systemId)
      throws SAXException {
    InputSource source;

    try {
      if (systemId.equals(SYSTEM_ID_SQL_MAP_CONFIG)) {
        InputStream in = Resources.getResourceAsStream(DTD_PATH_SQL_MAP_CONFIG);
        source = new InputSource(in);
      } else if (systemId.equals(SYSTEM_ID_SQL_MAP)) {
        InputStream in = Resources.getResourceAsStream(DTD_PATH_SQL_MAP);
        source = new InputSource(in);
      } else {
        source = null;
      }
    } catch (Exception e) {
      throw new SAXException(e.toString());
    }

    return source;
  }

}
