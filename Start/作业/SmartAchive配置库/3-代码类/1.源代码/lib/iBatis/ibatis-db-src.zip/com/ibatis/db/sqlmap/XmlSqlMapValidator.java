package com.ibatis.db.sqlmap;

import com.ibatis.db.sqlmap.*;
import com.ibatis.db.sqlmap.typehandler.*;
import com.ibatis.db.sqlmap.dynamic.DynamicMappedStatement;
import com.ibatis.common.beans.StaticBeanProbe;
import com.ibatis.common.resources.*;

import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.io.Reader;
import java.io.FileReader;

public class XmlSqlMapValidator {

  public static List validateSqlMap(SqlMap sqlMap) {
    int index = 0;

    List errors = new ArrayList();

    Iterator statementNames = sqlMap.getMappedStatementNames();

    while (statementNames.hasNext()) {
      String statementName = (String) statementNames.next();
      MappedStatement ms = sqlMap.getMappedStatement(statementName);

      // Result Class Validation
      String resultClassName = ms.getResultClass();
      if (resultClassName != null) {
        try {
          Class clazz = Class.forName(resultClassName);
          TypeHandler th = TypeHandlerFactory.getTypeHandler(clazz);
          if (th == null) {
            clazz.newInstance();
          } else {
            if (th.isSimpleType()) {
              th.instantiateValue();
            } else {
              clazz.newInstance();
            }
          }
        } catch (Exception e) {
          errors.add(++index + ") Error in " + ms.getResourceName() + " (" + statementName + ")\n   The result-class '" + resultClassName + "' is invalid. \n   Cause:  " + e.toString());
        }
      }

      // Result Map Validation
      String resultMapName = ms.getResultMapName();
      if (resultMapName != null) {
        ResultMap resultMap = null;
        try {
          resultMap = sqlMap.getResultMap(resultMapName);
        } catch (Exception e) {
          errors.add(++index + ") Error in " + ms.getResourceName() + " (" + statementName + ")\n   The result-map named '"+resultMapName+"' was invalid (likely does not exist).\n   Cause:  " + e.toString());
        }
        if (resultMap != null) {
          boolean isSimpleType = false;
          Object testObject = null;
          try {
            Class clazz = Class.forName(resultMap.getClassName());
            TypeHandler th = TypeHandlerFactory.getTypeHandler(clazz);
            if (th == null) {
              testObject = clazz.newInstance();
            } else {
              isSimpleType = th.isSimpleType();
              if (isSimpleType) {
                testObject = th.instantiateValue();
              } else {
                testObject = clazz.newInstance();
              }
            }
          } catch (Exception e) {
            errors.add(++index + ") Error in " + ms.getResourceName() + " (" + statementName + ")\n   The result-map named '"+resultMap.getName()+"' failed because class '" + resultMap.getClassName()  + "' is invalid.\n   Cause:  " + e.toString());
          }
          if (testObject != null && !(testObject instanceof Map)) {
            Iterator propNames = resultMap.getMappedPropertyNames();
            while (propNames.hasNext()) {
              String propName = (String) propNames.next();
              if (!StaticBeanProbe.hasWritableProperty(testObject, propName)) {
                if (isSimpleType) {
                  errors.add(++index + ") Error in " + ms.getResourceName() + " (" + statementName + ")\n   The result-map named '"+resultMap.getName()+"' failed because type handler for class '" + resultMap.getClassName() + "' does not have a WRITABLE property named '" + propName+"'.  Be sure to use a property name of 'value' or 'val' for simple types (String, Integer etc.).");
                } else {
                  errors.add(++index + ") Error in " + ms.getResourceName() + " (" + statementName + ")\n   The result-map named '"+resultMap.getName()+"' failed because class '" + resultMap.getClassName() + "' does not have a WRITABLE property named '" + propName+"'.");
                }
              }
            }
          }
          Iterator i = resultMap.getMappedPropertyNames();
          while (i.hasNext()) {
            ResultMapping mapping = resultMap.getResultMapping((String)i.next());
            if (mapping.getType() != null && mapping.getJdbcType() == TypeRegistry.UNKNOWN_TYPE) {
              errors.add(++index + ") Error in " + ms.getResourceName() + " (" + statementName + ")\n. In the result-map named '"+resultMap.getName()+"' the property named '" +mapping.getPropertyName()+ "' uses an invalid/unknown type: " + mapping.getType());
            }
          }
        }
      }

      if (!(ms instanceof DynamicMappedStatement)) {
        // Parameter Map Validation
        String parameterMapName = ms.getParameterMapName();
        if (parameterMapName != null) {
          ParameterMap parameterMap = null;
          try {
            parameterMap = sqlMap.getParameterMap(parameterMapName);
          } catch (Exception e) {
            errors.add(++index + ") Error in " + ms.getResourceName() + " (" + statementName + ")\n   The parameter-map named '"+parameterMapName+"' was invalid (likely does not exist).\n   Cause:  " + e.toString());
          }
          if (parameterMap != null) {
            Object testObject = null;
            // Parameter Class Validation
            String parameterClassName = ms.getParameterClass();
            boolean isSimpleType = false;
            if (parameterClassName != null) {
              try {
                Class clazz = Class.forName(parameterClassName);
                TypeHandler th = TypeHandlerFactory.getTypeHandler(clazz);
                if (th == null) {
                  testObject = clazz.newInstance();
                } else {
                  isSimpleType = th.isSimpleType();
                  if (isSimpleType) {
                    testObject = th.instantiateValue();
                  } else {
                    testObject = clazz.newInstance();
                  }
                }
              } catch (Exception e) {
                errors.add(++index + ") Error in " + ms.getResourceName() + " (" + statementName + ")\n   The parameter-class '" + parameterClassName + "' was invalid.  \n   Cause:  " + e.toString());
              }
            }
            if (testObject != null && !(testObject instanceof Map)) {
              String[] propNames = parameterMap.getPropertyNameArray();
              for (int i = 0; i < propNames.length; i++) {
                String propName = propNames[i];
                if (!StaticBeanProbe.hasReadableProperty(testObject, propName)) {
                  if (isSimpleType) {
                    errors.add(++index + ") Error in " + ms.getResourceName() + " (" + statementName + ")\n   The type handler for class '" + parameterClassName + "' does not have a READABLE property named '" + propName + "'.  Be sure to use a property name of 'value' or 'val' for simple types (String, Integer etc.).");
                  } else {
                    errors.add(++index + ") Error in " + ms.getResourceName() + " (" + statementName + ")\n   The class '" + parameterClassName + "' does not have a READABLE property named '" + propName + "'.");
                  }
                }
              }
            }
            int count = parameterMap.getCountOfPropertyMappings();
            for (int i = 0; i < count; i++) {
              ParameterMapping mapping = parameterMap.getParameterMapping(i);
              if (mapping.getType() != null && mapping.getJdbcType() == TypeRegistry.UNKNOWN_TYPE) {
                errors.add(++index + ") Error in " + ms.getResourceName() + " (" + statementName + ")\n. In the parameter-map named '"+parameterMap.getName()+"' the property named '" +mapping.getPropertyName()+ "' uses an invalid/unknown type: " + mapping.getType());
              }
            }
          }
        }
      }
    }

    return errors;
  }

  /**
   * Starts the iBatis sql-map check.
   * @param args  args should contain the filenames of the sql-map-config.xml files.
   */
  public static void main(String[] args) throws Exception {
    // get config filename
    if (args.length == 0) {
      System.out.println("*** ERROR no iBATIS SQL Map config XML files specified.");
      System.out.println("USAGE: ");
      System.out.println("For CLASSPATH resources...");
      System.out.println("\tjava "+XmlSqlMapValidator.class.getName()+" com/domain/app/sql-map-config1.xml com/domain/app/sql-map-config2.xml");
      System.out.println("For FILE resources...");
      System.out.println("\tjava "+XmlSqlMapValidator.class.getName()+" file:C:/devt/myapp/com/domain/app/sql-map-config1.xml file:C:/devt/myapp/com/domain/app/sql-map-config2.xml");
      System.out.println("For both...");
      System.out.println("\tjava "+XmlSqlMapValidator.class.getName()+" file:C:/devt/myapp/com/domain/app/sql-map-config1.xml com/domain/app/sql-map-config2.xml");
      System.exit(1);
    }

    // check each file
    for (int i = 0; i < args.length; i++) {
      String arg = args[i];
      Reader reader = null;
      if (arg.startsWith("file:")) {
        arg = arg.substring(5);
        reader = new FileReader(arg);
        System.out.println("Validating file: " + arg);
      } else {
        reader = Resources.getResourceAsReader(arg);
        System.out.println("Validating resource: " + arg);
      }
      SqlMap sqlMap = XmlSqlMapBuilder.buildSqlMap(reader, null, true);
      List messages = validateSqlMap(sqlMap);
      for (int j = 0; j < messages.size(); j++) {
        System.out.println(messages.get(j));
      }
      if (messages.size() > 0) {
        System.out.println("SQL Map validation complete. "+messages.size()+" ERRORS WERE FOUND.");
      } else {
        System.out.println("SQL Map validation complete. No errors found.");
      }
    }

  }

}