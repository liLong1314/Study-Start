package com.ibatis.db.sqlmap.value;

/**
 * User: clinton_begin
 * Date: Jul 17, 2003
 * Timestamp: 3:52:58 PM
 */
public class SqlTimestampValue extends BaseValue {

  public SqlTimestampValue() {
  }

  public SqlTimestampValue(java.sql.Timestamp value) {
    super(value);
  }

  public java.sql.Timestamp getValue() {
    return (java.sql.Timestamp) value;
  }

  public void setValue(java.sql.Timestamp value) {
    this.value = value;
  }

}

