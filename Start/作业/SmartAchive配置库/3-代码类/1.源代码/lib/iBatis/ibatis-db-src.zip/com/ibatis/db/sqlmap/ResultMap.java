package com.ibatis.db.sqlmap;

import java.util.*;

/** The ResultMap object is used to map the results of an SQL statement to a bean or
 * collection of beans.
 * @author clinton_begin
 */
public class ResultMap {

  public static final int UNKNOWN_COLUMN_INDEX = -999999;

  private String name;
  private String className;

  private Map mappings = new HashMap();
  private List mappedPropertyNames = new ArrayList();

  /** Default constructor */
  public ResultMap() {
  }

  /** Getter for the name property
   * @return The name of the ResultMap object
   */
  public String getName() {
    return name;
  }

  /** Setter for the name property
   * @param name The new name of the object
   */
  public void setName(String name) {
    this.name = name;
  }

  /** Getter for the className property
   * @return The name of the class of objects that this object maps data into
   */
  public String getClassName() {
    return className;
  }

  /** Setter for the className property
   * @param className The new name of the class to map data into
   */
  public void setClassName(String className) {
    this.className = className;
  }

  /** Adds a result mapping to this result map.
   * @param mapping The mapping to add.
   */
  public void addResultMapping(ResultMapping mapping) {
    mappings.put(mapping.getPropertyName(), mapping);
    mappedPropertyNames.add(mapping.getPropertyName());
  }

  /** Returns a result mapping for the provided property name.
   * @param propertyName The property name for which to look up the result mapping
   * @return The result mapping for the provided property name
   */
  public ResultMapping getResultMapping(String propertyName) {
    return (ResultMapping) mappings.get(propertyName);
  }

  /** Returns an iterator that provides acces to all of the names of the mapped
   * properties
   * @return The iterator
   */
  public Iterator getMappedPropertyNames() {
    return mappedPropertyNames.iterator();
  }

}
