package com.ibatis.db.jta;

import javax.transaction.*;

public class JtaTransaction {

  private UserTransaction userTransaction;
  private boolean newTransaction;
  private boolean started;

  public JtaTransaction(UserTransaction utx) {
    userTransaction = utx;
  }

  public void begin() throws JtaTransactionException {
    try {
      newTransaction = userTransaction.getStatus() == Status.STATUS_NO_TRANSACTION;
      if (newTransaction) {
        userTransaction.begin();
      }
    } catch (Exception e) {
      throw new JtaTransactionException("Could not start transaction.  Cause: ", e);
    }
    started = true;
  }

  public void commit() throws JtaTransactionException {
    if (!started) {
      throw new JtaTransactionException("Could not commit.  A transaction has not started.  Call begin() first.");
    }
    try {
      if (newTransaction) {
        userTransaction.commit();
      }
    } catch (Exception e) {
      throw new JtaTransactionException("Could not commit.  Cause: ", e);
    }
  }

  public void rollback() throws JtaTransactionException {
    if (!started) {
      throw new JtaTransactionException("Could not rollback.  A transaction has not started.  Call begin() first.");
    }
    try {
      if (newTransaction) {
        userTransaction.rollback();
      } else {
        userTransaction.setRollbackOnly();
      }
    } catch (Exception e) {
      throw new JtaTransactionException("Could not rollback.  Cause: ", e);
    }
  }

}
