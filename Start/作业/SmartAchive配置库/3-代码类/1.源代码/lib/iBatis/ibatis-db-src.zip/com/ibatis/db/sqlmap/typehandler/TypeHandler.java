/**
 * User: Clinton Begin
 * Date: Apr 11, 2003
 * Time: 11:04:46 PM
 */
package com.ibatis.db.sqlmap.typehandler;

import com.ibatis.db.sqlmap.*;

import java.sql.*;

public interface TypeHandler {

  void setBeanProperty(ResultMapping mapping, ResultSet rs, Object object) throws SQLException;

  Object instantiateValue();

  boolean isEqualToNullValue(String nullValue, Object realValue);

  boolean isSimpleType();

  void setParameter(ParameterMapping mapping, PreparedStatement ps, int index, Object value) throws SQLException;
}
