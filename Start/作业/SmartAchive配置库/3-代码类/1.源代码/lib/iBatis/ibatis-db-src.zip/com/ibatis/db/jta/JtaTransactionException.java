package com.ibatis.db.jta;

import com.ibatis.common.exception.NestedException;

/**
 * User: clinton_begin
 * Date: Jul 17, 2003
 * Time: 9:36:02 AM
 */
public class JtaTransactionException extends NestedException {

  public JtaTransactionException() {
  }

  public JtaTransactionException(String msg) {
    super(msg);
  }

  public JtaTransactionException(Throwable cause) {
    super(cause);
  }

  public JtaTransactionException(String msg, Throwable cause) {
    super(msg, cause);
  }
}
