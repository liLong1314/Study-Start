/**
 * Created by IntelliJ IDEA.
 * User: Clinton Begin
 * Date: Nov 8, 2002
 * Time: 8:45:36 PM
 * To change this template use Options | File Templates.
 */
package com.ibatis.common.util;

import java.util.*;

/**
 * Class to provide paged access to a list
 * @author Clinton Begin
 * @deprecated Use PaginatedArrayList - This class uses incorrect
 * semantics and does not properly implement the new PaginatedList
 * contract.
 */

public class PagedList extends ArrayList {

  private int pageSize = 10;
  private int index = 1;

  /** Create a PagedList with the default page size
   */
  public PagedList() {
    super();
  }

  /** Create a PagedList with a preset page size
   * @param pageSize The size of the pages in the collection
   */
  public PagedList(int pageSize) {
    super();
    this.pageSize = pageSize;
  }

  /** Create a PagedList with a preset page size and initial capacity
   * @param initialCapacity The total size of the collection
   * @param pageSize The size of the pages in the collection
   */
  public PagedList(int initialCapacity, int pageSize) {
    super(initialCapacity);
    this.pageSize = pageSize;
  }

  /** Create a PagedList with a preset page size from an existing collection
   * @param pageSize The size of the pages in the collection
   * @param c The collection to start with
   */
  public PagedList(Collection c, int pageSize) {
    super(c);
    this.pageSize = pageSize;
  }

  /** Gets an Iterator of a sub list that represents a page in the PagedList
   * @return An Iterator with the elements on the current page
   */
  public Iterator getPageIterator() {
    if (index * pageSize > size()) {
      return subList((index - 1) * pageSize, size()).iterator();
    } else {
      return subList((index - 1) * pageSize, ((index - 1) * pageSize) + pageSize).iterator();
    }
  }

  /** Gets a List that represents a page in the PagedList
   * @return A List with the elements on the current page
   */
  public List getPageList() {
    if (index * pageSize > size()) {
      return subList((index - 1) * pageSize, size());
    } else {
      return subList((index - 1) * pageSize, ((index - 1) * pageSize) + pageSize);
    }
  }

  /** Skip ahead to the next page in the collection */
  public void nextPage() {
    index++;
    if ((index - 1) * pageSize >= size()) {
      index = 1;
    }
  }

  /** Skip back to the previous page in the collection */
  public void previousPage() {
    index--;
    if (index < 1) {
      index = (size() / pageSize);
      if (size() % pageSize != 0) {
        index++;
      }
    }
  }

  /** Is the current page the last page?
   * @return True if the current page is the last page
   */
  public boolean isLastPage() {
    return (index * pageSize >= size());
  }

  /** Is the current page the first page?
   * @return True if the current page is the first page
   */
  public boolean isFirstPage() {
    return (index <= 1);
  }

  /** Is the current page a middle page? (i.e. not first or last)
   * @return True if the current page is a middle page
   */
  public boolean isMiddlePage() {
    return !(isFirstPage() || isLastPage());
  }

  /**
   * @return The maximum number of items in a page.
   */
  public int getPageSize() {
    return pageSize;
  }

  /**
   * @return True if a page exists after to the current page.  Otherwise false.
   */
  public boolean hasNextPage() {
    return !isLastPage();
  }

  /**
   * @return True if a page exists previous to the current page.  Otherwise false.
   */
  public boolean hasPrevPage() {
    return !isFirstPage();
  }

  /**
   * Go to a specific page number.  Pages are zero based.
   * @param pageNumber
   */
  public void gotoPage(int pageNumber) {
    if (pageNumber < 0 || (size() - (pageNumber * pageSize) < 0)) {
      throw new ArrayIndexOutOfBoundsException("Attempt to access a page of PagedList that did not exist.");
    }
  }

}
