/**
 * User: Clinton Begin
 * Date: Mar 3, 2003
 * Time: 6:55:55 PM
 */
package com.ibatis.db.sqlmap.dynamic;

import com.ibatis.db.sqlmap.*;

import java.util.*;

public class DynamicMappedStatement extends MappedStatement {

  private static final String PARAMETER_TOKEN = "#";

  private List childFragmentList = new ArrayList();

  public boolean isDynamic() {
    return true;
  }

  public void addChildFragment(BaseFragment fragment) {
    childFragmentList.add(fragment);
  }

  public BaseFragment getChildFragment(int i) {
    return (BaseFragment) childFragmentList.get(i);
  }

  public int getChildFragmentCount() {
    return childFragmentList.size();
  }

  public void addAllChildFragment(Collection c) {
    childFragmentList.addAll(c);
  }

  public Iterator getChildFragments() {
    return childFragmentList.iterator();
  }

  public String getSql(Object parameterObject) {
    StringBuffer buffer = new StringBuffer();

    Iterator i = getChildFragments();
    while (i.hasNext()) {
      BaseFragment fragment = (BaseFragment) i.next();
      String s = fragment.getSqlFragment(parameterObject);
      if (s.length() > 0) {
        buffer.append(" ");
        buffer.append(s);
        buffer.append(" ");
      }
    }

    return buffer.toString();
  }

  protected SqlStatement getSqlStatement(Object parameterObject) {

    ParameterMap parameterMap = new ParameterMap();

    StringTokenizer parser = new StringTokenizer(getSql(parameterObject), PARAMETER_TOKEN, true);
    StringBuffer newSql = new StringBuffer();

    String token = null;
    String lastToken = null;
    while (parser.hasMoreTokens()) {
      token = parser.nextToken();

      if (PARAMETER_TOKEN.equals(lastToken)) {
        if (PARAMETER_TOKEN.equals(token)) {
          newSql.append(PARAMETER_TOKEN);
          token = null;
        } else {
          if (token.indexOf(':') > -1) {
            StringTokenizer paramParser = new StringTokenizer(token, ":", true);
            int n = paramParser.countTokens();
            if (n == 3) {
              String name = paramParser.nextToken();
              paramParser.nextToken(); //ignore ":"
              String type = paramParser.nextToken();
              ParameterMapping mapping = new ParameterMapping();
              mapping.setPropertyName(name);
              mapping.setType(type);
              parameterMap.addParameterMapping(mapping);
            } else if (n >= 5) {
              String name = paramParser.nextToken();
              paramParser.nextToken(); //ignore ":"
              String type = paramParser.nextToken();
              paramParser.nextToken(); //ignore ":"
              String nullValue = paramParser.nextToken();
              while (paramParser.hasMoreTokens()) {
                nullValue = nullValue + paramParser.nextToken();
              }
              ParameterMapping mapping = new ParameterMapping();
              mapping.setPropertyName(name);
              mapping.setType(type);
              mapping.setNullValue(nullValue);
              parameterMap.addParameterMapping(mapping);
            } else {
              throw new SqlMapException("Incorrect inline parameter map format: " + token);
            }
          } else {
            ParameterMapping mapping = new ParameterMapping();
            mapping.setPropertyName(token);
            parameterMap.addParameterMapping(mapping);
          }
          newSql.append("?");
          token = parser.nextToken();
          if (!PARAMETER_TOKEN.equals(token)) {
            throw new SqlMapException("Unterminated inline parameter in mapped statement (" + getName() + ").");
          }
          token = null;
        }
      } else {
        if (!PARAMETER_TOKEN.equals(token)) {
          newSql.append(token);
        }
      }

      lastToken = token;
    }

    SqlStatement sqlStatement = new SqlStatement();
    sqlStatement.setSql(newSql.toString());
    sqlStatement.setParameterMap(parameterMap);

    return sqlStatement;

  }


}
