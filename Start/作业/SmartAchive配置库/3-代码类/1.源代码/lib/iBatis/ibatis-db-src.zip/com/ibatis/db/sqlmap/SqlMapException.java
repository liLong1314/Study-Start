package com.ibatis.db.sqlmap;

import com.ibatis.common.exception.*;

/** An unchecked exception generally thrown due to a misconfiguration
 * or invalid syntax in an SQL Map.  These exceptions would generally
 * be:
 * <ul>
 *    <li>  due to programmer error,
 *    <li>  unrecoverable (fatal),
 *    <li>  thrown close to system initialization.
 * </ul>
 *
 * @author clinton_begin
 */
public class SqlMapException extends NestedRuntimeException {

  /** Default constructor */
  public SqlMapException() {
  }


  /** Constructor that allows setting a message
   * @param s The message for the exception
   */
  public SqlMapException(String s) {
    super(s);
  }

  public SqlMapException(Throwable cause) {
    super(cause);
  }

  public SqlMapException(String msg, Throwable cause) {
    super(msg, cause);
  }
}
