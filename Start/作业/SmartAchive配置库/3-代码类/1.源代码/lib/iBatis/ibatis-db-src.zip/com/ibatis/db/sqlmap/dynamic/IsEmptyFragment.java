/**
 * User: Clinton Begin
 * Date: Mar 26, 2003
 * Time: 9:06:01 PM
 */
package com.ibatis.db.sqlmap.dynamic;

import com.ibatis.common.beans.StaticBeanProbe;

import java.util.Collection;

public class IsEmptyFragment extends ConditionalFragment {

  public boolean isCondition(Object parameterObject) {
    if (parameterObject == null) {
      return true;
    } else {
      Object value = StaticBeanProbe.getObject(parameterObject, getPropertyName());
      if (value instanceof Collection) {
        return value == null || ((Collection)value).size() < 1;
      } else if ( value instanceof Object[] ) {
          return value == null || ((Object[])value).length < 1;
      } else if (value instanceof boolean[]){
          return value ==  null ||((boolean[])value).length < 1;
      } else if (value instanceof byte[]){
          return value == null || ((byte[])value).length < 1;
      } else if (value instanceof double[]){
          return value == null || ((double[])value).length < 1;
      } else if (value instanceof float[]){
          return value == null || ((float[])value).length < 1;
      } else if (value instanceof int[]){
          return  value == null || ((int[])value).length < 1;
      } else if (value instanceof long[]){
          return value ==  null || ((long[])value).length < 1;
      } else if (value instanceof short[]){
          return  value == null || ((short[])value).length < 1;
      } else {
          return value == null || String.valueOf(value).length() < 1;
      }
    }
  }

}
