package com.ibatis.common.flatfile;

import java.io.*;

/**
 *
 *
 * @author  clinton_begin
 *
 */

public interface FlatFileOut {

  public int getColumnCount() throws IOException;

  public void nextRecord() throws IOException;

  public void setValueAt(int col, String value) throws IOException;

  public void close() throws IOException;

}

