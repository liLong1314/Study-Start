package com.ibatis.db.sqlmap.cache;

import com.ibatis.db.sqlmap.cache.*;
import com.ibatis.db.sqlmap.*;

import java.util.*;

public class CacheModel implements ExecuteListener {

  private Object STATS_LOCK = new Object();
  private int requests = 0;
  private int hits = 0;

  /** Constant to turn off periodic cache flushes */
  private static final long NO_FLUSH_INTERVAL = -99999;

  private String name;
  private String resourceName;
  private CacheController controller;
  private long flushInterval;
  private long flushIntervalSeconds;
  private long lastFlush;
  private Set flushTriggerStatements;

  public CacheModel() {
    this.flushInterval = NO_FLUSH_INTERVAL;
    this.flushIntervalSeconds = NO_FLUSH_INTERVAL;
    this.lastFlush = System.currentTimeMillis();
    this.flushTriggerStatements = new HashSet();
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public void setControllerClassName(String implementation) {
    try {
      Class clazz = Class.forName(implementation);
      if (clazz == null) {
        throw new SqlMapException ("Error instantiating cache controller for cache named '"+name+"' in resource '"+resourceName+"'.  Cause: The class for name '"+implementation+"' could not be found.");
      }
      controller = (CacheController)clazz.newInstance();
    } catch (Exception e) {
      throw new SqlMapException ("Error instantiating cache controller for cache named '"+name+"' in resource '"+resourceName+"'.  Cause: " + e, e);
    }
  }

  public String getResourceName() {
    return resourceName;
  }

  public void setResourceName(String resourceName) {
    this.resourceName = resourceName;
  }

  /** Getter for flushInterval property
   * @return The flushInterval (in milliseconds)
   */
  public long getFlushInterval() {
    return flushInterval;
  }

  /** Getter for flushInterval property
   * @return The flushInterval (in milliseconds)
   */
  public long getFlushIntervalSeconds() {
    return flushIntervalSeconds;
  }

  /** Setter for flushInterval property
   * @param flushInterval The new flushInterval (in milliseconds)
   */
  public void setFlushInterval(long flushInterval) {
    this.flushInterval = flushInterval;
    this.flushIntervalSeconds = flushInterval/1000;
  }

  /** Adds a flushTriggerStatment. When a flushTriggerStatment is executed, the
   * cache is flushed (cleared).
   * @param statementName The statement to add.
   */
  public void addFlushTriggerStatement(String statementName) {
    flushTriggerStatements.add(statementName);
  }

  /** Gets an Iterator containing all flushTriggerStatment objects for this cache.
   * @return The Iterator
   */
  public Iterator getFlushTriggerStatements() {
    return flushTriggerStatements.iterator();
  }

  /** ExecuteListener event.  This will be called by a MappedStatement
   * for which this cache is registered as a ExecuteListener.  It will
   * be called each time an executeXXXXXX method is called.  In the
   * case of the Cache class, it is registered in order to flush the
   * cache whenever a certain statement is executed.
   * (i.e. the flushOnExecute cache policy)
   * @param statement The statement to execute
   */
  public void onExecuteStatement(MappedStatement statement) {
    flush();
  }

  /** Clears the cache */
  public void flush() {
    lastFlush = System.currentTimeMillis();
    controller.flush(this);
  }

  /** Get an object out of the cache.
   * A side effect of this method is that is may clear the cache if it has not been
   * cleared in the flushInterval.
   * @param key The key of the object to be returned
   * @return The cached object (or null)
   */
  public Object getObject (Object key) {
    synchronized (this) {
      if (flushInterval != NO_FLUSH_INTERVAL
          && System.currentTimeMillis() - lastFlush > flushInterval) {
        flush();
      }
    }

    Object value = controller.getObject(this, key);

    synchronized (STATS_LOCK) {
      requests++;
      if (value != null) {
        hits++;
      }
    }

    return value;
  }

  /** Add an object to the cache
   * @param key The key of the object to be cached
   * @param value The object to be cached
   */
  public void putObject (Object key, Object value) {
    controller.putObject(this, key, value);
  }

  public double getHitRatio () {
    return (double)hits/(double)requests;
  }

  public void configureController(Properties props) {
    try {
      controller.configure(props);
    } catch (NullPointerException e) {
      throw new SqlMapException ("Error configuring controller named '"+name+"' in resource '"+resourceName+"'.  The controller is null.  Call setControllerClassName() with a valid value before attempting to configure the controller.",e);
    } catch (Exception e) {
      throw new SqlMapException ("Error configuring controller named '"+name+"' in resource '"+resourceName+"'.  Cause: " + e,e);
    }
  }

}
