/**
 * User: Clinton Begin
 * Date: Feb 20, 2003
 * Time: 7:44:31 PM
 */
package com.ibatis.db.sqlmap.value;

public class FloatValue extends BaseValue {

  public FloatValue() {
  }

  public FloatValue(Float value) {
    super(value);
  }

  public FloatValue(float value) {
    super(new Float(value));
  }

  public Float getValue() {
    return (Float) value;
  }

  public void setValue(Float value) {
    this.value = value;
  }

}
