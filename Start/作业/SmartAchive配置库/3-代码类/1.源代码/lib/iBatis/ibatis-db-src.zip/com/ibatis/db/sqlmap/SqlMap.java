package com.ibatis.db.sqlmap;

import com.ibatis.common.util.*;
import com.ibatis.common.exception.*;
import com.ibatis.db.jta.*;
import com.ibatis.db.sqlmap.cache.*;

import javax.sql.*;
import javax.transaction.*;
import javax.naming.*;
import java.io.*;
import java.util.*;
import java.sql.*;

/** The SqlMap class ties everything together. It defines the ParameterMap objects,
 * ResultMap objects, and MappedStatements that are used in the iBATIS database
 * layer. It is generally configured in an XML file that is loaded at run time.
 * @author clinton_begin
 */
public class SqlMap {

  private Map mappedStatements = new HashMap();
  private Map resultMaps = new HashMap();
  private Map parameterMaps = new HashMap();
  private Map dataSourceMap = new HashMap();
  private String currentDataSourceName;
  private StatementFactory statementFactory = new StatementFactory();
  private boolean useGlobalTransaction = false;
  private boolean useFullyQualifiedStatementNames = false;
  private boolean driverHintsEnabled = false;
  private boolean cacheModelsEnabled = true;
  private boolean startTransactionBeforeConnection = true;

  private String userTransactionJndiName;
  private JtaTransaction userTransaction;

  private PrintWriter logWriter = null;

  private ThreadLocal localTransaction = new ThreadLocal();
  private ThreadLocal localBatch = new ThreadLocal();

  private HashMap cacheMap = new HashMap();

  private Throttle executePerConnThrottle;
  private Throttle executeThrottle;
  private Throttle transactionThrottle;

  /** Creates new SqlMap */
  public SqlMap() {
  }

  public void setMaxExecutePerConnection(int limit) {
    if (limit > 0) {
      executePerConnThrottle = new Throttle(limit);
    } else {
      executePerConnThrottle = null;
    }
  }

  public void setMaxExecute(int limit) {
    if (limit > 0) {
      executeThrottle = new Throttle(limit);
    } else {
      executeThrottle = null;
    }
  }

  public void setMaxTransactions(int limit) {
    if (limit > 0) {
      transactionThrottle = new Throttle(limit);
    } else {
      transactionThrottle = null;
    }
  }

  public String getUserTransactionJndiName() {
    return userTransactionJndiName;
  }

  public void setUserTransactionJndiName(String userTransactionJndiName) {
    try {
      InitialContext initCtx = new InitialContext();
      UserTransaction utx = (UserTransaction) initCtx.lookup(userTransactionJndiName);
      userTransaction = new JtaTransaction(utx);

      this.userTransactionJndiName = userTransactionJndiName;
    } catch (NamingException e) {
      throw new NestedRuntimeException("Error setting userTransactionJndiName.  Cause: " + e, e);
    }
  }

  /** Gets a PrintWriter (like System.out) to be used for logging
   * @return A PrintWriter to be used for logging
   * @deprecated Use commons-logging
   */
  public PrintWriter getLogWriter() {
    return logWriter;
  }

  /** Sets a PrintWriter (like System.out) to be used for logging
   * @param logWriter The PrintWriter to use for logging
   * @deprecated Use commons-logging
   */
  public void setLogWriter(PrintWriter logWriter) {
    this.logWriter = logWriter;
  }

  /** When enabled (default), this property causes transactions to be
   * retrieved within the context of a transaction.  Most application
   * servers behave this way.  Some, such as IBM WebSphere when combined
   * with the Oracle database driver, require the connection to be
   * retrieved and manipulated (setAutoCommit(false)) outside of the
   * transaction scope.
   *
   * @return true if enabled.
   */
  public boolean isStartTransactionBeforeConnection() {
    return startTransactionBeforeConnection;
  }

  /** When enabled (default), this property causes transactions to be
   * retrieved within the context of a transaction.  Most application
   * servers behave this way.  Some, such as IBM WebSphere when combined
   * with the Oracle database driver, require the connection to be
   * retrieved and manipulated (setAutoCommit(false)) outside of the
   * transaction scope.
   *
   * @param startTransactionBeforeConnection
   */
  public void setStartTransactionBeforeConnection(boolean startTransactionBeforeConnection) {
    this.startTransactionBeforeConnection = startTransactionBeforeConnection;
  }

  /** Sends a message to the log
   * @param s The message to log
   * @deprecated Use commons-logging
   */
  public void log(String s) {
    if (logWriter != null) {
      logWriter.println(s);
      logWriter.flush();
    }
  }

  /**
   * A flag that determines whether cache models were enabled when this
   * SqlMap was built.
   * @return true if enabled, false otherwise.
   */
  public boolean isCacheModelsEnabled() {
    return cacheModelsEnabled;
  }

  /**
   * This is set by the builder of the SqlMap to flag whether
   * cache models were enabled at the time of configuration.
   * <p>
   * <B>Important: Setting this property to true will not dynamically
   * enable cache models.  This will only be set by the builder at build
   * time, as a flag to determine whether caching was enabled.<B>
   * @param cacheModelsEnabled Will be set by the builder.
   */
  public void setCacheModelsEnabled(boolean cacheModelsEnabled) {
    this.cacheModelsEnabled = cacheModelsEnabled;
  }

  /**
   * Gets the status of whether executions should make use of driver hints
   * for the size of result sets etc.  (Some drivers don't support this).
   * @return True if driverHintsEnabled.  False otherwise.
   */
  public boolean isDriverHintsEnabled() {
    return driverHintsEnabled;
  }

  /**
   * Sets the status of whether executions should make use of driver hints
   * for the size of result sets etc.  (Some drivers don't support this).
   */
  public void setDriverHintsEnabled(boolean driverHintsEnabled) {
    this.driverHintsEnabled = driverHintsEnabled;
  }

  /**
   * Returns true if global transaction support is enabled.
   * @return True if global transactions are enabled, false if transactions
   *  are to be locally controlled.
   */
  public boolean isUseGlobalTransaction() {
    return useGlobalTransaction;
  }

  /**
   * Set to true if global transactions are available and should be used.
   * Otherwise if transactions are locally controlled, set to false.
   * @param useGlobalTransaction true or false to enable or disable global
   * transactions respectively.
   */
  public void setUseGlobalTransaction(boolean useGlobalTransaction) {
    this.useGlobalTransaction = useGlobalTransaction;
  }

  /**
   * Flag to determine whether fully qualified statement names are being used.
   * @return True if statement names are fully qualified (sqlMapName.statementName)
   */
  public boolean isUseFullyQualifiedStatementNames() {
    return useFullyQualifiedStatementNames;
  }

  /**
   * Sets fully qualified names or not. NOTE: This is not a dynamic property.  If
   * you change it after the initial building of the SQL Map, changes will not be
   * applied.  This property is only valid during the building of the SQL Map.
   * @param useFullyQualifiedStatementNames Set to true by SqlMap builder if statement names are fully qualified,
   * otherwise set to false.
   */
  public void setUseFullyQualifiedStatementNames(boolean useFullyQualifiedStatementNames) {
    this.useFullyQualifiedStatementNames = useFullyQualifiedStatementNames;
  }

  /**
   * @return getStatementCacheSize > 0
   * @deprecated Use getStatementCacheSize()
   */
  public boolean isCachePreparedStatement() {
    return getStatementCacheSize() > 0;
  }

  /**
   * @param cachePreparedStatement setStatementCacheSize(0) if false.
   * @deprecated Use setStatementCacheSize(int size)
   */
  public void setCachePreparedStatement(boolean cachePreparedStatement) {
    if (!cachePreparedStatement) {
      setStatementCacheSize(0);
    }
  }

  /** Getter for size of statement cache
   * @return Current size of cache
   */
  public int getStatementCacheSize() {
    return statementFactory.getMaxTotalCachedStatements();
  }

  /** Setter for size of statement cache
   * @param statementCacheSize New size for the cache
   */
  public void setStatementCacheSize(int statementCacheSize) {
    statementFactory.setMaxTotalCachedStatements(statementCacheSize);
  }

  public String getDataCacheStats() {
    StringBuffer buffer = new StringBuffer();
    Iterator i = mappedStatements.keySet().iterator();
    while (i.hasNext()) {
      MappedStatement statement = (MappedStatement) mappedStatements.get(i.next());
      buffer.append(statement.getName());
      buffer.append(": ");
      Double d = statement.getDataCacheHitRatio();
      if (d != null) {
        buffer.append(Math.round(d.doubleValue() * 100));
        buffer.append("%");
      } else {
        buffer.append("No Cache.");
      }
      buffer.append("\n");
    }
    return buffer.toString();
  }

  public Double getStatementCacheHitRatio() {
    return statementFactory.getCacheHitRatio();
  }

  /** Flushes all cached objects that belong to this SqlMap */
  public void flushCache() {
    Iterator i = cacheMap.keySet().iterator();
    while (i.hasNext()) {
      ((CacheModel) cacheMap.get(i.next())).flush();
    }
  }

  public void addExecuteListener(ExecuteListener listener) {
    Iterator i = mappedStatements.values().iterator();
    while (i.hasNext()) {
      MappedStatement ms = (MappedStatement) i.next();
      ms.addExecuteListener(listener);
    }
  }

  /** Adds a named datasource to the list of available datasources
   * @param name The name of the data source
   * @param dataSource The data source
   */
  public void addDataSource(String name, DataSource dataSource) {
    dataSourceMap.put(name, dataSource);
  }

  /** Gets a named datasource from the list of available datasources
   * @param name The name of the data source
   * @return The datasource
   */
  public DataSource getDataSource(String name) {
    return (DataSource) dataSourceMap.get(name);
  }

  /** Returns the current data source
   * @return The data source
   */
  public DataSource getCurrentDataSource() {
    return (DataSource) dataSourceMap.get(currentDataSourceName);
  }

  /** Getter for the StatementFactory
   * @return The StatementFactory
   */
  public StatementFactory getStatementFactory() {
    return statementFactory;
  }

  /** Gets a MappedStatement by name
   * @param name The name of the statement
   * @return The MappedStatement
   */
  public MappedStatement getMappedStatement(String name) {
    if (!mappedStatements.containsKey(name)) {
      throw new SqlMapException("This SQL map does not contain an MappedStatement named " + name);
    }
    return (MappedStatement) mappedStatements.get(name);
  }

  /**
   * Returns a Iterator containing the names of the mapped statements
   * owned by this SqlMap
   * @return Iterator of mapped statement names.
   */
  public Iterator getMappedStatementNames() {
    return mappedStatements.keySet().iterator();
  }

  /** Adds a (named) MappedStatement.
   * @param mappedStatement The statement to add
   */
  public void addMappedStatement(MappedStatement mappedStatement) {
    if (mappedStatements.containsKey(mappedStatement.getName())) {
      throw new SqlMapException("This SQL map already contains an MappedStatement named " + mappedStatement.getName());
    }
    mappedStatements.put(mappedStatement.getName(), mappedStatement);
  }


  /** Gets a cache by name
   * @param name The name of the cache to get
   * @return The cache object
   */
  public CacheModel getCache(String name) {
    if (!cacheMap.containsKey(name)) {
      throw new SqlMapException("This SQL map does not contain an Cache named " + name);
    }
    return (CacheModel) cacheMap.get(name);
  }

  /** Adds a (named) cache.
   * @param cache The cache to add
   */
  public void addCache(CacheModel cache) {
    if (cacheMap.containsKey(cache.getName())) {
      throw new SqlMapException("This SQL map already contains an Cache named " + cache.getName());
    }
    cacheMap.put(cache.getName(), cache);
  }

  /** Returns an iterator to step through the available caches for the SqlMap
   * @return The iterator
   */
  public Iterator getCaches() {
    return cacheMap.values().iterator();
  }

  /** Gets a ParameterMap by name
   * @param name The name of the ParameterMap
   * @return The ParameterMap
   */
  public ParameterMap getParameterMap(String name) {
    if (!parameterMaps.containsKey(name)) {
      String message = "This SQL map does not contain an ParameterMap named " + name + ".  ";
      if (name != null && name.endsWith(".inline")) {
        message = message + "The name 'inline' is no longer supported for inline parameters.  Use inline-parameters=\"true\" instead (or don't specify use default of true).";
      }
      throw new SqlMapException(message);
    }
    return (ParameterMap) parameterMaps.get(name);
  }

  /** Adds a (named) ParameterMap.
   * @param parameterMap the ParameterMap to add
   */
  public void addParameterMap(ParameterMap parameterMap) {
    if (parameterMaps.containsKey(parameterMap.getName())) {
      throw new SqlMapException("This SQL map already contains an ParameterMap named " + parameterMap.getName());
    }
    parameterMaps.put(parameterMap.getName(), parameterMap);
  }

  /** Gets a ResultMap by name
   * @param name The name of the result map
   * @return The ResultMap
   */
  public ResultMap getResultMap(String name) {
    if (!resultMaps.containsKey(name)) {
      throw new SqlMapException("This SQL map does not contain an ResultMap named " + name);
    }
    return (ResultMap) resultMaps.get(name);
  }

  /** Adds a (named) ResultMap
   * @param resultMap The ResultMap to add
   */
  public void addResultMap(ResultMap resultMap) {
    if (resultMaps.containsKey(resultMap.getName())) {
      throw new SqlMapException("This SQL map already contains an ResultMap named " + resultMap.getName());
    }
    resultMaps.put(resultMap.getName(), resultMap);
  }

  /** Getter for the current data source name
   * @return The name of the current data source
   */
  public String getCurrentDataSourceName() {
    return currentDataSourceName;
  }

  /** Setter for the current data source
   * @param currentDataSourceName The new current data source
   */
  public void setCurrentDataSourceName(String currentDataSourceName) {
    if (dataSourceMap.containsKey(currentDataSourceName)) {
      this.currentDataSourceName = currentDataSourceName;
    } else {
      throw new SqlMapException("Could not set current DataSource.  Invalid name '" + currentDataSourceName + "'.  ");
    }
  }

  private Connection getConnectionFromCurrentDataSource() throws SQLException {
    DataSource dataSource = getCurrentDataSource();
    if (dataSource == null) {
      throw new SQLException("Current DataSource was null (Use setCurrentDataSource())).");
    }
    Connection connection = dataSource.getConnection();
    return connection;
  }

  private void closeConnection(Connection connection) throws SQLException {
    if (connection != null && !connection.isClosed()) {
      connection.close();
    }
  }

  private void setCurrentLocalConnection(Connection connection) {
    localTransaction.set(connection);
  }

  public Connection getCurrentLocalConnection() {
    return (Connection) localTransaction.get();
  }

  private Connection removeCurrentLocalConnection() {
    Connection conn = (Connection) localTransaction.get();
    localTransaction.set(null);
    return conn;
  }

  /** Starts a new transaction.
   *
   * @throws SQLException If a transaction has already been started, or if a database exception is thrown.
   */
  public void startTransaction()
      throws SQLException {

    if (getCurrentLocalConnection() != null) {
      throw new SQLException("A transaction has already been started.  Call commit() or rollback() before starting a new one.");
    }

    try {

      incrementTransactionThrottle();

      if (startTransactionBeforeConnection) {
        if (useGlobalTransaction && userTransaction != null) {
          userTransaction.begin();
        }
      }

      Connection connection = getConnectionFromCurrentDataSource();
      if (connection.getAutoCommit()) {
        connection.setAutoCommit(false);
      }
      setCurrentLocalConnection(connection);

      if (!startTransactionBeforeConnection) {
        if (useGlobalTransaction && userTransaction != null) {
          userTransaction.begin();
        }
      }

    } catch (JtaTransactionException e) {
      try {
        userTransaction.rollback();
      } catch (Exception e2) {
        //ignore
      }
      Connection removedConnection = removeCurrentLocalConnection();
      if (removedConnection != null) {
        decrementTransactionThrottle();
      }
      throw new SQLException("An error occurred while trying to START the GLOBAL transaction.  Cause: " + e);
    } catch (SQLException e) {
      try {
        userTransaction.rollback();
      } catch (Exception e2) {
        //ignore
      }
      Connection removedConnection = removeCurrentLocalConnection();
      if (removedConnection != null) {
        decrementTransactionThrottle();
      }
      throw e;
    }
  }

  /** Commits the current transaction
   * @throws SQLException If a database exception is thrown, or no transaction is in progress
   */
  public void commitTransaction()
      throws SQLException {

    Connection connection = getCurrentLocalConnection();

    if (connection == null) {
      throw new SQLException("Could not commit transaction.  No transaction was started.  Call startTransaction() first.");
    }

    try {
      if (useGlobalTransaction) {
        if (userTransaction != null) {
          try {
            userTransaction.commit();
          } catch (Exception e) {
            try {
              userTransaction.rollback();
            } catch (Exception e2) {
              // ignore
            }
            throw new SQLException("An error occurred while trying to COMMIT the GLOBAL transaction.  Cause: " + e);
          }
        }
        closeConnection(connection);
      } else {
        connection.commit();
        closeConnection(connection);
      }
    } finally {
      Connection removedConnection = removeCurrentLocalConnection();
      if (removedConnection != null) {
        decrementTransactionThrottle();
      }
    }
  }

  /** Rolls back the current transaction
   * @throws SQLException If a database exception is thrown
   */
  public void rollbackTransaction()
      throws SQLException {

    try {
      Connection connection = getCurrentLocalConnection();
      if (connection != null) {
        if (useGlobalTransaction) {
          if (userTransaction != null) {
            try {
              userTransaction.rollback();
            } catch (Exception e) {
              throw new SQLException("An error occurred while trying to ROLLBACK the GLOBAL transaction.  Cause: " + e);
            }
          }
          closeConnection(connection);
        } else {
          connection.rollback();
          closeConnection(connection);
        }
      }

    } finally {
      Connection removedConnection = removeCurrentLocalConnection();
      if (removedConnection != null) {
        decrementTransactionThrottle();
      }
    }
  }

  /** Executes a update using a MappedStatement and a parameter object
   * @param statementName The name of the MappedStatement to execute
   * @param parameterObject The parameter object used by the MappedStatement
   * @throws SQLException If a transaction has not been started, or a database exception is thrown
   * @return The number of rows updated
   */
  public int executeUpdate(String statementName, Object parameterObject)
      throws SQLException {

    boolean transaction = true;
    boolean autoCommit = !useGlobalTransaction;

    Connection connection = getCurrentLocalConnection();
    if (connection == null) {
      transaction = false;
      connection = getConnectionFromCurrentDataSource();
      if (autoCommit != connection.getAutoCommit()) {
        connection.setAutoCommit(autoCommit);
      }
    }

    MappedStatement statement = getMappedStatement(statementName);
    int rows;
    try {
      rows = statement.executeUpdate(connection, parameterObject);
    } finally {
      if (!transaction) {
        closeConnection(connection);
      }
    }

    return rows;
  }

  /** Executes a MappedStatement that returns a single object
   * @param statementName The name of the MappedStatement
   * @param parameterObject The parameter object used by the MappedStatement
   * @throws SQLException If a transaction is not in progress, or the database throws an exception
   * @return The object
   */
  public Object executeQueryForObject(String statementName, Object parameterObject)
      throws SQLException {

    boolean transaction = true;
    boolean autoCommit = !useGlobalTransaction;

    Connection connection = getCurrentLocalConnection();
    if (connection == null) {
      transaction = false;
      connection = getConnectionFromCurrentDataSource();
      if (autoCommit != connection.getAutoCommit()) {
        connection.setAutoCommit(autoCommit);
      }
    }

    MappedStatement statement = getMappedStatement(statementName);
    Object result;

    try {
      result = statement.executeQueryForObject(connection, parameterObject);
    } finally {
      if (!transaction) {
        closeConnection(connection);
      }
    }

    return result;
  }

  /** Executes a MappedStatement that returns a single object of the type of the
   * resultObject parameter.
   * @return The object
   * @param resultObject An object of the type to be returned
   * @param statementName The name of the MappedStatement
   * @param parameterObject The parameter object used by the MappedStatement
   * @throws SQLException If a transaction is not in progress, or the database throws an exception
   */
  public Object executeQueryForObject(String statementName, Object parameterObject, Object resultObject)
      throws SQLException {
    boolean transaction = true;
    boolean autoCommit = !useGlobalTransaction;

    Connection connection = getCurrentLocalConnection();
    if (connection == null) {
      transaction = false;
      connection = getConnectionFromCurrentDataSource();
      if (autoCommit != connection.getAutoCommit()) {
        connection.setAutoCommit(autoCommit);
      }
    }

    MappedStatement statement = getMappedStatement(statementName);
    Object result;

    try {
      result = statement.executeQueryForObject(connection, parameterObject, resultObject);
    } finally {
      if (!transaction) {
        closeConnection(connection);
      }
    }

    return result;
  }

  /** Executes the SQL and retuns all rows selected in a map that is keyed on the property named
   * in the keyProperty parameter.  The value at each key will be the entire result object.
   * @param parameterObject The object used to set the parameters in the SQL
   * @param keyProperty The property of the result object to be used as the key
   * @throws SQLException If an exception occurs in the database
   * @return A Map of beans containing the rows keyed by keyProperty
   */
  public Map executeQueryForMap(String statementName, Object parameterObject, String keyProperty)
      throws SQLException {
    return executeQueryForMap(statementName, parameterObject, keyProperty, null);
  }

  /** Executes the SQL and retuns all rows selected in a map that is keyed on the property named
   * in the keyProperty parameter.  The value at each key will be the value of the property specified
   * in the valueProperty parameter.  If valueProperty is null, the entire result object will be entered.
   * @param parameterObject The object used to set the parameters in the SQL
   * @param keyProperty The property of the result object to be used as the key
   * @param valueProperty The property of the result object to be used as the value (or null)
   * @throws SQLException If an exception occurs in the database
   * @return A Map of beans containing the rows keyed by keyProperty
   */
  public Map executeQueryForMap(String statementName, Object parameterObject, String keyProperty, String valueProperty)
      throws SQLException {

    boolean transaction = true;
    boolean autoCommit = !useGlobalTransaction;

    Connection connection = getCurrentLocalConnection();
    if (connection == null) {
      transaction = false;
      connection = getConnectionFromCurrentDataSource();
      if (autoCommit != connection.getAutoCommit()) {
        connection.setAutoCommit(autoCommit);
      }
    }

    MappedStatement statement = getMappedStatement(statementName);
    Map map;

    try {
      map = statement.executeQueryForMap(connection, parameterObject, keyProperty, valueProperty);
    } finally {
      if (!transaction) {
        closeConnection(connection);
      }
    }

    return map;
  }

  /** Executes the SQL and retuns all rows selected.
   * @param statementName The name of the MappedStatement to execute
   * @param parameterObject The object used to set the parameters in the SQL
   * @throws SQLException If an exception occurs in the database
   * @return A List of beans containing the rows
   */
  public List executeQueryForList(String statementName, Object parameterObject)
      throws SQLException {

    boolean transaction = true;
    boolean autoCommit = !useGlobalTransaction;

    Connection connection = getCurrentLocalConnection();
    if (connection == null) {
      transaction = false;
      connection = getConnectionFromCurrentDataSource();
      if (autoCommit != connection.getAutoCommit()) {
        connection.setAutoCommit(autoCommit);
      }
    }

    MappedStatement statement = getMappedStatement(statementName);
    List list;

    try {
      list = statement.executeQueryForList(connection, parameterObject);
    } finally {
      if (!transaction) {
        closeConnection(connection);
      }
    }

    return list;
  }

  /** Executes the SQL and retuns all rows selected.
   * @param statementName The name of the MappedStatement to execute
   * @param parameterObject The object used to set the parameters in the SQL
   * @param skipResults The number of rows to skip over
   * @param maxResults The maximum number of rows to return
   * @throws SQLException If an exception occurs in the database
   * @return A List of beans containing the rows
   */
  public List executeQueryForList(String statementName, Object parameterObject, int skipResults, int maxResults)
      throws SQLException {

    boolean transaction = true;
    boolean autoCommit = !useGlobalTransaction;

    Connection connection = getCurrentLocalConnection();
    if (connection == null) {
      transaction = false;
      connection = getConnectionFromCurrentDataSource();
      if (autoCommit != connection.getAutoCommit()) {
        connection.setAutoCommit(autoCommit);
      }
    }

    MappedStatement statement = getMappedStatement(statementName);
    List list;

    try {
      list = statement.executeQueryForList(connection, parameterObject, skipResults, maxResults);
    } finally {
      if (!transaction) {
        closeConnection(connection);
      }
    }

    return list;
  }

  /** Executes the SQL and retuns a subset of the results in a dynamic PaginatedList that can be used to
   * automatically scroll through results from a database table.
   * @param parameterObject The object used to set the parameters in the SQL
   * @param pageSize The maximum number of objects to store in each page
   * @throws SQLException If an exception occurs in the database
   * @return A PaginatedList of beans containing the rows
   */
  public PaginatedList executeQueryForPaginatedList(String statementName, Object parameterObject, int pageSize)
      throws SQLException {
    MappedStatement statement = getMappedStatement(statementName);
    PaginatedList list = statement.executeQueryForPaginatedList(parameterObject, pageSize);
    return list;
  }

  /** Runs a query with a custom object that gets a chance to deal with each row as it
   * is processed.
   * @param statementName The name of the MappedStatement to execute
   * @param parameterObject The parameter object mapped the the statement
   * @param rowHandler The custom row handler object
   * @throws SQLException If an exception occurs in the database
   */
  public void executeQueryWithRowHandler(String statementName, Object parameterObject, RowHandler rowHandler)
      throws SQLException {

    boolean transaction = true;
    boolean autoCommit = !useGlobalTransaction;

    Connection connection = getCurrentLocalConnection();
    if (connection == null) {
      transaction = false;
      connection = getConnectionFromCurrentDataSource();
      if (autoCommit != connection.getAutoCommit()) {
        connection.setAutoCommit(autoCommit);
      }
    }

    MappedStatement statement = getMappedStatement(statementName);

    try {
      statement.executeQueryWithRowHandler(connection, parameterObject, rowHandler);
    } finally {
      if (!transaction) {
        closeConnection(connection);
      }
    }

  }

  /** Sets up a 'batch' of update statements to execute using a more efficient call
   * to the database.
   * @throws SQLException If the database throws an exception
   */
  public void startBatch()
      throws SQLException {
    localBatch.set(new HashMap());
  }

  /** Executes a 'batch' of statements as a single transaction
   * @throws SQLException If the database throws an exception
   */
  public void endBatch()
      throws SQLException {
    HashMap batchMap = (HashMap) localBatch.get();
    localBatch.set(null);

    Iterator i = batchMap.keySet().iterator();
    while (i.hasNext()) {
      PreparedStatement ps = null;
      try {
        ps = (PreparedStatement) batchMap.get(i.next());
        ps.executeBatch();
      } finally {
        if (ps != null) ps.close();
      }
    }

  }

  /** Flag indicating that we are in the middle of creating or running a batch
   * @return If we are in the middle of creating or running a batch
   */
  public boolean isInsideBatch() {
    return localBatch.get() != null;
  }

  private void incrementTransactionThrottle() {
    if (transactionThrottle != null) {
      transactionThrottle.increment(this);
    }
  }

  private void decrementTransactionThrottle() {
    if (transactionThrottle != null) {
      transactionThrottle.decrement(this);
    }
  }

  // package scope
  void registerStatementWithBatch(MappedStatement mappedStatement, PreparedStatement ps) {
    HashMap batchMap = (HashMap) localBatch.get();
    batchMap.put(mappedStatement, ps);
  }

  // package scope
  PreparedStatement getStatementFromBatch(MappedStatement mappedStatement) {
    HashMap batchMap = (HashMap) localBatch.get();
    return (PreparedStatement) batchMap.get(mappedStatement);
  }


  // package scope
  void incrementExecutionThrottle(Connection conn) {
    if (executePerConnThrottle != null) {
      executePerConnThrottle.increment(conn);
    }
    if (executeThrottle != null) {
      executeThrottle.increment(this);
    }
  }

  // package scope
  void decrementExecutionThrottle(Connection conn) {
    if (executePerConnThrottle != null) {
      executePerConnThrottle.decrement(conn);
    }
    if (executeThrottle != null) {
      executeThrottle.decrement(this);
    }
  }

}
