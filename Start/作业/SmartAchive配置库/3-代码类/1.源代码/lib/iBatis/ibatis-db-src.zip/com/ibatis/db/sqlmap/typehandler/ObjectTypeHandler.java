/**
 * User: Clinton Begin
 * Date: Apr 11, 2003
 * Time: 10:57:16 PM
 */
package com.ibatis.db.sqlmap.typehandler;

import com.ibatis.db.sqlmap.value.*;
import com.ibatis.db.sqlmap.*;

import java.sql.*;

public class ObjectTypeHandler extends BaseTypeHandler {

  protected Object getValueByName(ResultMapping mapping, ResultSet rs) throws SQLException {
    return rs.getObject(mapping.getColumnName());
  }

  protected Object getValueByIndex(ResultMapping mapping, ResultSet rs) throws SQLException {
    return rs.getObject(mapping.getColumnIndex().intValue());
  }

  protected Object getNullValue(String nullValue) throws SQLException {
    return nullValue;
  }

  public Object instantiateValue() {
    return new ObjectValue();
  }

  public boolean isEqualToNullValue(String nullValue, Object realValue) {
    return false;
  }

  public boolean isSimpleType() {
    return false;
  }

  public void setParameter(ParameterMapping mapping, PreparedStatement ps, int index, Object value) throws SQLException {
    ps.setObject(index, value);
  }

}
