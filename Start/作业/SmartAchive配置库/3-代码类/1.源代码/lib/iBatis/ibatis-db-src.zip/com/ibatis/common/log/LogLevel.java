package com.ibatis.common.log;

/**
 *
 *
 * @author  clinton_begin
 * @deprecated Use Jakarta commons logging
 */
public class LogLevel {

  public static final LogLevel LOG_DEBUG = new LogLevel(5);
  public static final LogLevel LOG_STDOUT = new LogLevel(4);
  public static final LogLevel LOG_INFO = new LogLevel(3);
  public static final LogLevel LOG_WARN = new LogLevel(2);
  public static final LogLevel LOG_ERROR = new LogLevel(1);
  public static final LogLevel LOG_CRITICAL = new LogLevel(0);

  private int level;

  private LogLevel(int level) {
    this.level = level;
  }

  public int getLevel() {
    return level;
  }

}
