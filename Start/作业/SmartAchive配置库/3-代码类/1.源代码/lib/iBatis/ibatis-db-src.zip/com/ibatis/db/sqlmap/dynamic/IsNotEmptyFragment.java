/**
 * User: Clinton Begin
 * Date: Mar 26, 2003
 * Time: 9:08:45 PM
 */
package com.ibatis.db.sqlmap.dynamic;

public class IsNotEmptyFragment extends IsEmptyFragment {

  public boolean isCondition(Object parameterObject) {
    return !super.isCondition(parameterObject);
  }

}
