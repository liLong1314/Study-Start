package com.ibatis.db.sqlmap.value;

/**
 * User: clinton_begin
 * Date: Jul 17, 2003
 * Time: 3:52:02 PM
 */
public class SqlTimeValue extends BaseValue {

  public SqlTimeValue() {
  }

  public SqlTimeValue(java.sql.Time value) {
    super(value);
  }

  public java.sql.Time getValue() {
    return (java.sql.Time) value;
  }

  public void setValue(java.sql.Time value) {
    this.value = value;
  }

}
