/**
 * User: Clinton Begin
 * Date: May 22, 2003
 * Time: 8:53:28 PM
 */
package com.ibatis.db.jdbc.logging;

import org.apache.commons.logging.*;

import java.util.*;

public class BaseLogProxy {

  private static int nextId = 100000;
  protected static final Set setMethods = new HashSet();
  protected static final Set getMethods = new HashSet();
  protected static final Set executeMethods = new HashSet();

  private Map columnMap = new HashMap();

  private List columnNames = new ArrayList();
  private List columnValues = new ArrayList();

  protected int id;

  public BaseLogProxy() {
    id = getNextId();
  }

  static {
    setMethods.add("setString");
    setMethods.add("setInt");
    setMethods.add("setByte");
    setMethods.add("setShort");
    setMethods.add("setLong");
    setMethods.add("setDouble");
    setMethods.add("setFloat");
    setMethods.add("setTimestamp");
    setMethods.add("setDate");
    setMethods.add("setTime");
    setMethods.add("setArray");
    setMethods.add("setBigDecimal");
    setMethods.add("setAsciiStream");
    setMethods.add("setBinaryStream");
    setMethods.add("setBlob");
    setMethods.add("setBoolean");
    setMethods.add("setBytes");
    setMethods.add("setCharacterStream");
    setMethods.add("setClob");
    setMethods.add("setObject");
    setMethods.add("setNull");

    getMethods.add("getString");
    getMethods.add("getInt");
    getMethods.add("getByte");
    getMethods.add("getShort");
    getMethods.add("getLong");
    getMethods.add("getDouble");
    getMethods.add("getFloat");
    getMethods.add("getTimestamp");
    getMethods.add("getDate");
    getMethods.add("getTime");
    getMethods.add("getArray");
    getMethods.add("getBigDecimal");
    getMethods.add("getAsciiStream");
    getMethods.add("getBinaryStream");
    getMethods.add("getBlob");
    getMethods.add("getBoolean");
    getMethods.add("getBytes");
    getMethods.add("getCharacterStream");
    getMethods.add("getClob");
    getMethods.add("getObject");
    getMethods.add("getNull");

    executeMethods.add("execute");
    executeMethods.add("executeUpdate");
    executeMethods.add("executeQuery");

  }

  protected void setColumn(Object key, Object value) {
    columnMap.put(key, value);
    columnNames.add(key);
    columnValues.add(value);
  }

  protected Object getColumn(Object key) {
    return columnMap.get(key);
  }

  protected String getValueString() {
    return columnValues.toString();
  }

  protected String getTypeString() {
    List typeList = new ArrayList(columnValues.size());
    for (int i = 0; i < columnValues.size(); i++) {
      Object value = columnValues.get(i);
      if (value == null) {
        typeList.add("null");
      } else {
        typeList.add(value.getClass().getName());
      }
    }
    return typeList.toString();
  }

  protected String getColumnString() {
    return columnNames.toString();
  }

  protected void clearColumnInfo() {
    columnMap.clear();
    columnNames.clear();
    columnValues.clear();
  }

  protected String removeBreakingWhitespace(String original) {
    return original.replace('\n', ' ').replace('\r', ' ').replace('\t', ' ');
  }

  protected synchronized static int getNextId() {
    return nextId++;
  }

}
