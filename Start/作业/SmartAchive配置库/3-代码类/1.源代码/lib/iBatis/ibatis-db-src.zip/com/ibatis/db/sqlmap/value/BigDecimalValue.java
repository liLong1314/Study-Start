/**
 * User: Clinton Begin
 * Date: Feb 20, 2003
 * Time: 7:40:27 PM
 */
package com.ibatis.db.sqlmap.value;

import java.math.*;

public class BigDecimalValue extends BaseValue {

  public BigDecimalValue() {
  }

  public BigDecimalValue(BigDecimal value) {
    super(value);
  }

  public BigDecimal getValue() {
    return (BigDecimal) value;
  }

  public void setValue(BigDecimal value) {
    this.value = value;
  }

}
