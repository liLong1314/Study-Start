/**
 * User: Clinton Begin
 * Date: Mar 4, 2003
 * Time: 7:33:10 PM
 */
package com.ibatis.db.sqlmap.dynamic;

public class StaticFragment extends BaseFragment {

}
