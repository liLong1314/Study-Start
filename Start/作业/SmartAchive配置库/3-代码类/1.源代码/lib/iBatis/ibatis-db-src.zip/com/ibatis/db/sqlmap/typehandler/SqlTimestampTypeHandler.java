package com.ibatis.db.sqlmap.typehandler;

import com.ibatis.db.sqlmap.ResultMapping;
import com.ibatis.db.sqlmap.ParameterMapping;
import com.ibatis.db.sqlmap.value.SqlTimestampValue;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;

/**
 * User: clinton_begin
 * Date: Jul 17, 2003
 * Timestamp: 3:55:07 PM
 */
public class SqlTimestampTypeHandler extends BaseTypeHandler {

  protected Object getValueByName(ResultMapping mapping, ResultSet rs) throws SQLException {
    return rs.getTimestamp(mapping.getColumnName());
  }

  protected Object getValueByIndex(ResultMapping mapping, ResultSet rs) throws SQLException {
    return rs.getTimestamp(mapping.getColumnIndex().intValue());
  }

  protected Object getNullValue(String nullValue) throws SQLException {
    return java.sql.Timestamp.valueOf(nullValue);
  }

  public Object instantiateValue() {
    return new SqlTimestampValue();
  }

  public boolean isEqualToNullValue(String nullValue, Object realValue) {
    return java.sql.Timestamp.valueOf(nullValue).equals(realValue);
  }

  public boolean isSimpleType() {
    return true;
  }

  public void setParameter(ParameterMapping mapping, PreparedStatement ps, int index, Object value) throws SQLException {
    ps.setTimestamp(index, (java.sql.Timestamp)value);
  }

}

