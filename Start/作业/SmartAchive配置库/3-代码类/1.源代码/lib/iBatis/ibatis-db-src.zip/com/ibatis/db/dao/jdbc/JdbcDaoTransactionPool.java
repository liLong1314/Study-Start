package com.ibatis.db.dao.jdbc;

/**
 * @deprecated Use SimpleDaoTransactionPool instead.
 */
public class JdbcDaoTransactionPool extends SimpleDaoTransactionPool {


}
