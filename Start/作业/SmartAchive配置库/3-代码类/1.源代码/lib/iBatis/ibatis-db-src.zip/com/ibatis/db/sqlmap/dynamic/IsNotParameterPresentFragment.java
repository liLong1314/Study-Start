/**
 * User: Clinton Begin
 * Date: Mar 26, 2003
 * Time: 9:05:33 PM
 */
package com.ibatis.db.sqlmap.dynamic;

public class IsNotParameterPresentFragment extends IsParameterPresentFragment {

  public boolean isCondition(Object parameterObject) {
    return !super.isCondition(parameterObject);
  }

}
