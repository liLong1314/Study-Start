package com.ibatis.common.beans;

import net.sf.cglib.*;

import java.lang.reflect.*;
import java.util.*;

/**
 * StaticBeanProbe provides methods that allow simple, reflective access to
 * JavaBeans style properties.  Methods are provided for all simple types as
 * well as object types.
 * <p>
 * Examples:
 * <p>
 * StaticBeanProbe.setObject(object, propertyName, value);
 * <P>
 * Object value = StaticBeanProbe.getObject(object, propertyName);
 *
 * @author clinton_begin
 *
 */
public class StaticBeanProbe extends Object {

  private static final Object[] NO_ARGUMENTS = new Object[0];
  private static boolean useMetaClasses = true;

  public static boolean isUseMetaClasses() {
    return useMetaClasses;
  }

  public static void setUseMetaClasses(boolean useMetaClasses) {
    StaticBeanProbe.useMetaClasses = useMetaClasses;
  }

  /** Provides direct access (set value) to class fields through reflection.
   * <P>
   * Warning: This is a dangerous method that should never be used in production.
   * However, it may be quite valueable for testing purposes.
   * @param object The object to modify
   * @param name The name of the property to modify
   * @param value The new value to set
   */
  public static void setField(Object object, String name, Object value) {
    try {
      Field field = object.getClass().getField(name);
      field.set(object, value);
    } catch (Exception e) {
      throw new BeansException("Error setting field.  Cause: " + e.toString(), e);
    }
  }

  /** Provides direct access (get value) to class fields through reflection.
   * <P>
   * Warning: This is a dangerous method that should never be used in production.
   * However, it may be quite valueable for testing purposes.
   * @param object The bean to get the value from
   * @param name The name of the property to read
   * @return The value in the field
   */
  public static Object getField(Object object, String name) {
    try {
      Field field = object.getClass().getField(name);
      return field.get(object);
    } catch (Exception e) {
      throw new BeansException("Error getting field.  Cause: " + e.toString(), e);
    }
  }

  /** Returns an array of the readable properties exposed by a bean
   * @param object The bean
   * @return The properties
   */
  public static String[] getReadablePropertyNames(Object object) {
    return ClassInfo.getInstance(object.getClass()).getReadablePropertyNames();
  }

  /** Returns an array of the writeable properties exposed by a bean
   * @param object The bean
   * @return The properties
   */
  public static String[] getWriteablePropertyNames(Object object) {
    return ClassInfo.getInstance(object.getClass()).getReadablePropertyNames();
  }

  /** Compares two beans to see if all properties/values are the same
   * @param object1 Bean one
   * @param object2 Bean two
   * @return True if the two beans are equal
   */
  public static boolean beanEquals(Object object1, Object object2) {
    return beanEquals(object1, object2, getReadablePropertyNames(object1), new HashSet());
  }

  /** Compares two beans to see if a subset of their properties/values are the same
   * @param object1 Bean one
   * @param object2 Bean two
   * @param properties The subset of properties to check
   * @return True if the two beans are equal
   */
  public static boolean beanEquals(Object object1, Object object2, String[] properties) {
    return beanEquals(object1, object2, properties, new HashSet());
  }

  private static boolean beanEquals(Object object1, Object object2, String[] properties, Set alreadyChecked) {
    if (object1 == object2) {
      return true;
    } else if (object1 != null && object1.equals(object2)) {
      return true;
    } else if (object1 == null && object2 != null) {
      return false;
    } else if (object1 != null && object2 == null) {
      return false;
    }

    boolean equal = true;
    for (int i = 0; i < properties.length; i++) {
      Object value1 = getObject(object1, properties[i]);
      Object value2 = getObject(object2, properties[i]);
      if (value1 == value2) {
        equal = true;
      } else if (value1 != null && value1.equals(value2)) {
        equal = true;
      } else if (value1 == null && value2 != null) {
        equal = false;
        break;
      } else if (value1 != null && value2 == null) {
        equal = false;
        break;
      } else {
        if (isSimpleType(value1)) {
          equal = value1.equals(value2);
        } else {
          // It's a bean (i.e. properties other than getClass())
          // Check to avoid endless loop (circular dependency)
          int hash = System.identityHashCode(value1) + System.identityHashCode(value2);
          String hashString = String.valueOf(hash);
          if (!alreadyChecked.contains(hashString)) {
            alreadyChecked.add(hashString);
            equal = beanEquals(value1, value2);
          }
        }
        if (!equal) {
          break;
        }
      }
    }
    return equal;
  }

  /** Calculates a hash code for all readable properties of a bean
   * @param object The bean to calculate the hash code for
   * @return The hash code
   */
  public static int beanHashCode(Object object) {
    return beanHashCode(object, getReadablePropertyNames(object), new HashSet());
  }

  /** Calculates a hash code for a subset of the readable properties of a bean
   * @return The hash code
   * @param object The bean to calculate the hash code for
   * @param properties A list of the properties to hash
   */
  public static int beanHashCode(Object object, String[] properties) {
    return beanHashCode(object, properties, new HashSet());
  }

  private static int beanHashCode(Object object, String[] properties, Set alreadyDigested) {
    int hashcode = object.getClass().getName().hashCode();
    for (int i = 0; i < properties.length; i++) {
      Object value = getObject(object, properties[i]);
      if (value != null) {
        if (isSimpleType(value)) {
          hashcode += value.hashCode();
        } else {
          // It's a bean (i.e. properties other than getClass())
          // Check to avoid endless loop (circular dependency)
          if (value != object) {
            if (!alreadyDigested.contains(value)) {
              alreadyDigested.add(value);
              hashcode += beanHashCode(value);
            }
          }
        }
        hashcode *= 29;
      }
    }
    return hashcode;
  }

  private static boolean isSimpleType(Object value) {
    if (ClassInfo.isSimpleType(value.getClass())) {
      return true;
    } else {
      return false;
    }
  }

  /** Returns the class that the setter expects to receive as a parameter when
   * setting a property value.
   * @param object The bean to check
   * @param name The name of the property
   * @return The type of the property
   */
  public static Class getPropertyTypeForSetter(Object object, String name) {
    Class type = object.getClass();

    if (object instanceof Map) {
      Map map = (Map) object;
      Object value = map.get(name);
      if (value == null) {
        type = Object.class;
      } else {
        type = value.getClass();
      }
    } else {
      if (name.indexOf('.') > -1) {
        StringTokenizer parser = new StringTokenizer(name, ".");
        while (parser.hasMoreTokens()) {
          name = parser.nextToken();
          type = ClassInfo.getInstance(type).getSetterType(name);
        }
      } else {
        type = ClassInfo.getInstance(type).getSetterType(name);
      }
    }

    return type;
  }

  /** Returns the class that the getter will return when reading a property value.
   * @param object The bean to check
   * @param name The name of the property
   * @return The type of the property
   */
  public static Class getPropertyTypeForGetter(Object object, String name) {
    Class type = object.getClass();

    if (object instanceof Map) {
      Map map = (Map) object;
      Object value = map.get(name);
      if (value == null) {
        type = Object.class;
      } else {
        type = value.getClass();
      }
    } else {
      if (name.indexOf('.') > -1) {
        StringTokenizer parser = new StringTokenizer(name, ".");
        while (parser.hasMoreTokens()) {
          name = parser.nextToken();
          type = ClassInfo.getInstance(type).getGetterType(name);
        }
      } else {
        type = ClassInfo.getInstance(type).getGetterType(name);
      }
    }

    return type;
  }


  private static Object getArrayProperty(Object object, String indexedName) {

    Object value = null;

    try {
      String name = indexedName.substring(0, indexedName.indexOf("["));
      int i = Integer.parseInt(indexedName.substring(indexedName.indexOf("[") + 1, indexedName.indexOf("]")));
      value = getProperty(object, name);
      if (value instanceof List) {
        value = ((List) value).get(i);
      } else {
        throw new BeansException("The '" + name + "' property of the " + object.getClass().getName() + " class is not a List.");
      }
    } catch (BeansException e) {
      throw e;
    } catch (Exception e) {
      throw new BeansException("Error getting ordinal value from JavaBean. Cause " + e, e);
    }

    return value;
  }

  private static Object getProperty(Object object, String name) {
    ClassInfo classCache = ClassInfo.getInstance(object.getClass());
    try {
      Object value = null;
      if (name.indexOf("[") > -1) {
        value = getArrayProperty(object, name);
      } else {
        if (object instanceof Map) {
          value = ((Map) object).get(name);
        } else {
          MetaClass meta = classCache.getMetaClass(name);
          if (meta != null) {
            Object[] values = meta.getPropertyValues(object);
            value = values[0];
          } else {
            Method method = classCache.getGetter(name);
            if (method == null) {
              throw new NoSuchMethodException("No GET method for property " + name + " on instance of " + object.getClass().getName());
            }
            value = method.invoke(object, NO_ARGUMENTS);
          }
        }
      }
      return value;
    } catch (BeansException e) {
      throw e;
    } catch (Exception e) {
      if (object == null) {
        throw new BeansException("Could not get property '" + name + "' from null reference.  Cause: " + e.toString(), e);
      } else {
        throw new BeansException("Could not get property '" + name + "' from " + object.getClass().getName() + ".  Cause: " + e.toString(), e);
      }
    }
  }

  private static void setArrayProperty(Object object, String indexedName, Object value) {

    try {
      String name = indexedName.substring(0, indexedName.indexOf("["));
      int i = Integer.parseInt(indexedName.substring(indexedName.indexOf("[") + 1, indexedName.indexOf("]")));
      Object list = getProperty(object, name);
      if (list instanceof List) {
        ((List) list).set(i, value);
      } else {
        throw new BeansException("The '" + name + "' property of the " + object.getClass().getName() + " class is not a List.");
      }
    } catch (BeansException e) {
      throw e;
    } catch (Exception e) {
      throw new BeansException("Error getting ordinal value from JavaBean. Cause " + e, e);
    }

  }

  private static void setProperty(Object object, String name, Object value) {
    ClassInfo classCache = ClassInfo.getInstance(object.getClass());
    try {
      if (name.indexOf("[") > -1) {
        setArrayProperty(object, name, value);
      } else {
        if (object instanceof Map) {
          ((Map) object).put(name, value);
        } else {
          MetaClass meta = classCache.getMetaClass(name);
          if (meta != null) {
            meta.setPropertyValues(object, new Object[]{value});
          } else {
            Method method = classCache.getSetter(name);
            if (method == null) {
              throw new NoSuchMethodException("No SET method for property " + name + " on instance of " + object.getClass().getName());
            }
            Object[] params = new Object[1];
            params[0] = value;
            method.invoke(object, params);
          }
        }
      }
    } catch (BeansException e) {
      throw e;
    } catch (Exception e) {
      if (object == null) {
        throw new BeansException("Could not set property '" + name + "' for null reference.  Cause: " + e.toString(), e);
      } else {
        throw new BeansException("Could not set property '" + name + "' for " + object.getClass().getName() + ".  Cause: " + e.toString(), e);
      }
    }
  }

  /** Gets an Object property from a bean
   * @param object The bean
   * @param name The property name
   * @return The property value (as an Object)
   */
  public static Object getObject(Object object, String name) {
    if (name.indexOf('.') > -1) {
      StringTokenizer parser = new StringTokenizer(name, ".");
      Object value = object;
      while (parser.hasMoreTokens()) {
        value = getProperty(value, parser.nextToken());

        if (value == null) {
          break;
        }

      }
      return value;
    } else {
      return getProperty(object, name);
    }
  }

  /** Sets the value of a bean property to an Object
   * @param object The bean to change
   * @param name The name of the property to set
   * @param value The new value to set
   */
  public static void setObject(Object object, String name, Object value) {
    if (name.indexOf('.') > -1) {
      StringTokenizer parser = new StringTokenizer(name, ".");
      String property = parser.nextToken();
      Object child = object;
      while (parser.hasMoreTokens()) {
        Class type = getPropertyTypeForSetter(child, property);
        Object parent = child;
        child = getProperty(parent, property);
        if (child == null) {
          try {
            child = type.newInstance();
            setObject(parent, property, child);
          } catch (Exception e) {
            throw new BeansException("Cannot set value of property '" + name + "' because '" + property + "' is null and cannot be instantiated on instance of " + type.getName() + ". Cause:" + e.toString(), e);
          }
        }
        property = parser.nextToken();
      }
      setProperty(child, property, value);
    } else {
      setProperty(object, name, value);
    }
  }

  //---String---
  /** Gets a String value from a bean
   * @param object The bean to get the value from
   * @param name The name of the property to get
   * @return The value of the property cast to a String
   */
  public static String getString(Object object, String name) {
    return (String) getObject(object, name);
  }

  /** Sets the value of a bean property to a String
   * @param object The bean to change
   * @param name The name of the property to set
   * @param value The new value to set
   */
  public static void setString(Object object, String name, String value) {
    setObject(object, name, value);
  }

  //---Integer---
  /** Gets a Integer value from a bean
   * @param object The bean to get the value from
   * @param name The name of the property to get
   * @return The value of the property cast to a String
   */
  public static int getInteger(Object object, String name) {
    return ((Integer) getObject(object, name)).intValue();
  }

  /** Sets the value of a bean property to a int
   * @param object The bean to change
   * @param name The name of the property to set
   * @param value The new value to set
   */
  public static void setInteger(Object object, String name, int value) {
    setObject(object, name, new Integer(value));
  }

  //---Long---
  /** Gets a long value from a bean
   * @param object The bean to get the value from
   * @param name The name of the property to get
   * @return The value of the property cast to a String
   */
  public static long getLong(Object object, String name) {
    return ((Long) getObject(object, name)).longValue();
  }

  /** Sets the value of a bean property to a long
   * @param object The bean to change
   * @param name The name of the property to set
   * @param value The new value to set
   */
  public static void setLong(Object object, String name, long value) {
    setObject(object, name, new Long(value));
  }

  //---Short---
  /** Gets a short value from a bean
   * @param object The bean to get the value from
   * @param name The name of the property to get
   * @return The value of the property cast to a String
   */
  public static short getShort(Object object, String name) {
    return ((Short) getObject(object, name)).shortValue();
  }

  /** Sets the value of a bean property to a short
   * @param object The bean to change
   * @param name The name of the property to set
   * @param value The new value to set
   */
  public static void setShort(Object object, String name, short value) {
    setObject(object, name, new Short(value));
  }

  //---Byte---
  /** Gets a byte value from a bean
   * @param object The bean to get the value from
   * @param name The name of the property to get
   * @return The value of the property cast to a String
   */
  public static byte getByte(Object object, String name) {
    return ((Byte) getObject(object, name)).byteValue();
  }

  /** Sets the value of a bean property to a byte
   * @param object The bean to change
   * @param name The name of the property to set
   * @param value The new value to set
   */
  public static void setByte(Object object, String name, byte value) {
    setObject(object, name, new Byte(value));
  }

  //---Character---
  /** Gets a char value from a bean
   * @param object The bean to get the value from
   * @param name The name of the property to get
   * @return The value of the property cast to a String
   */
  public char getCharacter(Object object, String name) {
    return ((Character) getObject(object, name)).charValue();
  }

  /** Sets the value of a bean property to a char
   * @param object The bean to change
   * @param name The name of the property to set
   * @param value The new value to set
   */
  public static void setCharacter(Object object, String name, char value) {
    setObject(object, name, new Character(value));
  }

  //---Double---
  /** Gets a double value from a bean
   * @param object The bean to get the value from
   * @param name The name of the property to get
   * @return The value of the property cast to a String
   */
  public static double getDouble(Object object, String name) {
    return ((Double) getObject(object, name)).doubleValue();
  }

  /** Sets the value of a bean property to a double
   * @param object The bean to change
   * @param name The name of the property to set
   * @param value The new value to set
   */
  public static void setDouble(Object object, String name, double value) {
    setObject(object, name, new Double(value));
  }

  //---Float---
  /** Gets a float value from a bean
   * @param object The bean to get the value from
   * @param name The name of the property to get
   * @return The value of the property cast to a String
   */
  public static float getFloat(Object object, String name) {
    return ((Float) getObject(object, name)).floatValue();
  }

  /** Sets the value of a bean property to a float
   * @param object The bean to change
   * @param name The name of the property to set
   * @param value The new value to set
   */
  public static void setFloat(Object object, String name, float value) {
    setObject(object, name, new Float(value));
  }


  //---Boolean---
  /** Gets a boolean value from a bean
   * @param object The bean to get the value from
   * @param name The name of the property to get
   * @return The value of the property cast to a String
   */
  public static boolean getBoolean(Object object, String name) {
    return ((Boolean) getObject(object, name)).booleanValue();
  }

  /** Sets the value of a bean property to a boolean
   * @param object The bean to change
   * @param name The name of the property to set
   * @param value The new value to set
   */
  public static void setBoolean(Object object, String name, boolean value) {
    setObject(object, name, new Boolean(value));
  }

  //---Date---
  /** Gets a Date value from a bean
   * @param object The bean to get the value from
   * @param name The name of the property to get
   * @return The value of the property cast to a String
   */
  public static Date getDate(Object object, String name) {
    return ((Date) getObject(object, name));
  }

  /** Sets the value of a bean property to a Date
   * @param object The bean to change
   * @param name The name of the property to set
   * @param value The new value to set
   */
  public static void setDate(Object object, String name, Date value) {
    setObject(object, name, value);
  }


  /** Checks to see if a bean has a writable property be a given name
   * @param object The bean to check
   * @param propertyName The property to check for
   * @return True if the property exists and is writable
   */
  public static boolean hasWritableProperty(Object object, String propertyName) {
    if (object instanceof Map) {
      return ((Map) object).containsKey(propertyName);
    } else {
      return ClassInfo.getInstance(object.getClass()).hasWritableProperty(propertyName);
    }
  }

  /** Checks to see if a bean has a readable property be a given name
   * @param object The bean to check
   * @param propertyName The property to check for
   * @return True if the property exists and is readable
   */
  public static boolean hasReadableProperty(Object object, String propertyName) {
    if (object instanceof Map) {
      return ((Map) object).containsKey(propertyName);
    } else {
      return ClassInfo.getInstance(object.getClass()).hasReadableProperty(propertyName);
    }
  }
  
}


