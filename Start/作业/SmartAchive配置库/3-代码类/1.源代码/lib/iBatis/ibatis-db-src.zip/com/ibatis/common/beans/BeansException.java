package com.ibatis.common.beans;

import com.ibatis.common.exception.*;

/**
 * BeansException for use for by BeanProbe and StaticBeanProbe.
 *
 * @author  clinton_begin
 */
public class BeansException extends NestedRuntimeException {

  /** Default constructor */
  public BeansException() {
  }

  /** Constructor to set the message for the exception
   * @param s The message for the exception
   */
  public BeansException(String s) {
    super(s);
  }

  public BeansException(Throwable cause) {
    super(cause);
  }

  public BeansException(String msg, Throwable cause) {
    super(msg, cause);
  }

}
