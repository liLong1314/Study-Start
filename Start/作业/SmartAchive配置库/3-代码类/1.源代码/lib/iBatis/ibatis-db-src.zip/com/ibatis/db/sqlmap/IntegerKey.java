package com.ibatis.db.sqlmap;

/**
 * @deprecated
 */
public class IntegerKey {

  /** Holds value of property key. */
  private int key;

  /** Creates a new instance of IntegerKey */
  public IntegerKey() {
  }

  public IntegerKey(int key) {
    this.key = key;
  }

  /** Getter for property key.
   * @return Value of property key.
   */
  public int getKey() {
    return this.key;
  }

  /** Setter for property key.
   * @param key New value of property key.
   */
  public void setKey(int key) {
    this.key = key;
  }

  public boolean equals(Object o) {
    if (this == o) return true;
    if (!(o instanceof IntegerKey)) return false;

    final IntegerKey integerKey = (IntegerKey) o;

    if (key != integerKey.key) return false;

    return true;
  }

  public int hashCode() {
    return key;
  }

}
