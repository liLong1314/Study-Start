/**
 * User: Clinton Begin
 * Date: Feb 20, 2003
 * Time: 7:45:31 PM
 */
package com.ibatis.db.sqlmap.value;

public class LongValue extends BaseValue {

  public LongValue() {
  }

  public LongValue(Long value) {
    super(value);
  }

  public LongValue(long value) {
    super(new Long(value));
  }

  public Long getValue() {
    return (Long) value;
  }

  public void setValue(Long value) {
    this.value = value;
  }

}
