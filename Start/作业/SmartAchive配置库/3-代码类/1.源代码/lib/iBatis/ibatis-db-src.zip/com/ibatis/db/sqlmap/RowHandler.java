/**
 * User: Clinton Begin
 * Date: Feb 9, 2003
 * Time: 6:40:51 PM
 */
package com.ibatis.db.sqlmap;

import java.sql.*;

/** Interface for objects used to handle row-by-row processing */
public interface RowHandler {

  /** Called for each row in a returned ResultSet
   * @param object The bean containing data from the resultset
   * @throws SQLException If something goes wrong
   */
  public void handleRow(Object object)
      throws SQLException;

}
