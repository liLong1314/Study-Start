/**
 * User: Clinton Begin
 * Date: Apr 11, 2003
 * Time: 10:55:50 PM
 */
package com.ibatis.db.sqlmap.typehandler;

import com.ibatis.db.sqlmap.value.*;
import com.ibatis.db.sqlmap.*;

import java.sql.*;

public class LongTypeHandler extends BaseTypeHandler {

  protected Object getValueByName(ResultMapping mapping, ResultSet rs) throws SQLException {
    return new Long(rs.getLong(mapping.getColumnName()));
  }

  protected Object getValueByIndex(ResultMapping mapping, ResultSet rs) throws SQLException {
    return new Long(rs.getLong(mapping.getColumnIndex().intValue()));
  }

  protected Object getNullValue(String nullValue) throws SQLException {
    return Long.valueOf(nullValue);
  }

  public Object instantiateValue() {
    return new LongValue();
  }

  public boolean isEqualToNullValue(String nullValue, Object realValue) {
    return Long.valueOf(nullValue).equals(realValue);
  }

  public boolean isSimpleType() {
    return true;
  }

  public void setParameter(ParameterMapping mapping, PreparedStatement ps, int index, Object value) throws SQLException {
    ps.setLong(index, ((Long) value).longValue());
  }
}
