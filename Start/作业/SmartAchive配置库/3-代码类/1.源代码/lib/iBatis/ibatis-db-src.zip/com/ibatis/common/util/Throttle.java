/**
 * User: Clinton Begin
 * Date: Apr 20, 2003
 * Time: 5:13:16 PM
 */
package com.ibatis.common.util;

import com.ibatis.common.exception.*;

import java.util.*;

public class Throttle {
  private Map throttleMap = new HashMap();
  private int count;

  private int limit;
  private long maxWait;

  public Throttle(int limit) {
    this.limit = limit;
    this.maxWait = 0;
  }

  public Throttle(int limit, long maxWait) {
    this.limit = limit;
    this.maxWait = maxWait;
  }

  private Throttle getThrottle(Object object) {
    synchronized (throttleMap) {
      Throttle throttle = (Throttle) throttleMap.get(object);
      if (throttle == null) {
        throttle = new Throttle(limit, maxWait);
        throttleMap.put(object, throttle);
      }
      return throttle;
    }
  }

  public void increment(Object object) {
    Throttle throttle = getThrottle(object);
    synchronized (throttle) {
      if (throttle.count >= throttle.limit) {
        if (maxWait > 0) {
          long waitTime = System.currentTimeMillis();
          try {
            throttle.wait(maxWait);
          } catch (InterruptedException e) {
            //ignore
          }
          waitTime = System.currentTimeMillis() - waitTime;
          if (waitTime > maxWait) {
            throw new NestedRuntimeException("Throttle waited too long (" + waitTime + ") for object '" + object + "'.");
          }
        } else {
          try {
            throttle.wait();
          } catch (InterruptedException e) {
            //ignore
          }
        }
      }
      throttle.count++;
    }
  }

  public void decrement(Object object) {
    Throttle throttle = getThrottle(object);
    synchronized (throttle) {
      throttle.count--;
      throttle.notify();
    }
  }
}
