/**
 * Created by IntelliJ IDEA.
 * User: Clinton Begin
 * Date: Nov 17, 2002
 * Time: 12:40:01 PM
 * To change this template use Options | File Templates.
 */
package com.ibatis.db.sqlmap.value;

public class StringValue extends BaseValue {

  public StringValue() {
  }

  public StringValue(String value) {
    super(value);
  }

  public String getValue() {
    return (String) value;
  }

  public void setValue(String value) {
    this.value = value;
  }

}
