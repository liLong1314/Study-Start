/**
 * User: Clinton Begin
 * Date: Apr 11, 2003
 * Time: 10:55:38 PM
 */
package com.ibatis.db.sqlmap.typehandler;

import com.ibatis.db.sqlmap.value.*;
import com.ibatis.db.sqlmap.*;

import java.sql.*;

public class IntegerTypeHandler extends BaseTypeHandler {

  protected Object getValueByName(ResultMapping mapping, ResultSet rs) throws SQLException {
    return new Integer(rs.getInt(mapping.getColumnName()));
  }

  protected Object getValueByIndex(ResultMapping mapping, ResultSet rs) throws SQLException {
    return new Integer(rs.getInt(mapping.getColumnIndex().intValue()));
  }

  protected Object getNullValue(String nullValue) throws SQLException {
    return Integer.valueOf(nullValue);
  }

  public Object instantiateValue() {
    return new IntegerValue();
  }

  public boolean isEqualToNullValue(String nullValue, Object realValue) {
    return Integer.valueOf(nullValue).equals(realValue);
  }

  public boolean isSimpleType() {
    return true;
  }

  public void setParameter(ParameterMapping mapping, PreparedStatement ps, int index, Object value) throws SQLException {
    ps.setInt(index, ((Integer) value).intValue());
  }

}
