/**
 * User: Clinton Begin
 * Date: Feb 20, 2003
 * Time: 7:47:14 PM
 */
package com.ibatis.db.sqlmap.value;

public class ShortValue extends BaseValue {

  public ShortValue() {
  }

  public ShortValue(Short value) {
    super(value);
  }

  public ShortValue(short value) {
    super(new Short(value));
  }

  public Short getValue() {
    return (Short) value;
  }

  public void setValue(Short value) {
    this.value = value;
  }

}
