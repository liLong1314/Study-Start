/**
 * User: Clinton Begin
 * Date: Mar 3, 2003
 * Time: 7:30:48 PM
 */
package com.ibatis.db.sqlmap.dynamic;

import com.ibatis.common.beans.StaticBeanProbe;

public class IsNullFragment extends ConditionalFragment {

  public boolean isCondition(Object parameterObject) {
    if (parameterObject == null) {
      return true;
    } else {
      return StaticBeanProbe.getObject(parameterObject, getPropertyName()) == null;
    }
  }


}
