/**
 * User: Clinton Begin
 * Date: Feb 20, 2003
 * Time: 7:41:27 PM
 */
package com.ibatis.db.sqlmap.value;

public class BooleanValue extends BaseValue {

  public BooleanValue() {
  }

  public BooleanValue(Boolean value) {
    super(value);
  }

  public BooleanValue(boolean value) {
    super(new Boolean(value));
  }

  public Boolean getValue() {
    return (Boolean) value;
  }

  public void setValue(Boolean value) {
    this.value = value;
  }

}
