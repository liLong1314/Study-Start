/**
 * User: Clinton Begin
 * Date: Mar 11, 2003
 * Time: 6:31:07 PM
 */
package com.ibatis.db.dao;

import org.jdom.input.SAXBuilder;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.Attribute;

import java.io.*;
import java.util.*;

import com.ibatis.common.resources.Resources;

public class XmlDaoManagerBuilder {

  private static final String DAO_CONFIG_ELEMENT = "dao-config";
  private static final String CONTEXT_ELEMENT = "context";
  private static final String TRANS_POOL_ELEMENT = "transaction-pool";
  private static final String DAO_FACTORY_ELEMENT = "dao-factory";
  private static final String PROPERTIES_ELEMENT = "properties";
  private static final String PROPERTY_ELEMENT = "property";
  private static final String EXTRA_PROPS_ELEMENT = "extra-properties";
  private static final String DAO_ELEMENT = "dao";

  private static Properties properties = null;
  private static boolean validationEnabled = true;

  public static DaoManager[] buildDaoManagers(Reader reader)
      throws DaoException {
    List daoManagerList = new ArrayList();
    try {

      SAXBuilder builder = new SAXBuilder();
      builder.setEntityResolver(new DaoJarEntityResolver());
      builder.setValidation(validationEnabled);


      Document doc = builder.build(reader);
      Element root = doc.getRootElement();

      String rootname = root.getName();
      if (!DAO_CONFIG_ELEMENT.equals(rootname)) {
        throw new IOException("Error while configuring DaoManager.  The root tag of the DAO configuration XML document must be '" + DAO_CONFIG_ELEMENT + "'.");
      }

      List children = root.getChildren();
      for (int i = 0; i < children.size(); i++) {
        Element child = (Element) children.get(i);

        if (CONTEXT_ELEMENT.equals(child.getName())) {
          DaoManager daoManager = parseContext(child);
          daoManagerList.add(daoManager);
        } else if (PROPERTIES_ELEMENT.equals(child.getName())) {
          String resource = getAttributeValue(child, "resource", true);
          properties = Resources.getResourceAsProperties(resource);
        }

      }

    } catch (Exception e) {
      throw new DaoException("Error while configuring DaoManager.  Cause: " + e.toString(), e);
    }
    return (DaoManager[]) daoManagerList.toArray(new DaoManager[daoManagerList.size()]);
  }

  public static boolean isValidationEnabled() {
    return validationEnabled;
  }

  public static void setValidationEnabled(boolean validationEnabled) {
    XmlDaoManagerBuilder.validationEnabled = validationEnabled;
  }

  private static String getAttributeValue(Element element, String attributeName, boolean required)
      throws DaoException {
    String value = null;

    Attribute attrib = element.getAttribute(attributeName);
    if (attrib != null) {
      value = attrib.getValue();
    }

    value = parsePropertyTokens(value, properties); 

    if (required && (value == null)) {
      throw new DaoException("Error while configuring DaoManager.  A '" + element.getName() + "' element requires a '" + attributeName + "' attribute.");
    }

    return value;
  }


  private static DaoManager parseContext(Element contextElement)
      throws DaoException {
    DaoManager daoManager = DaoManager.newInstance();

    daoManager.setName(getAttributeValue(contextElement, "name", true));

    daoManager.setDefault("true".equals(getAttributeValue(contextElement, "default", false)));

    Element poolElement = null;
    Element factoryElement = null;
    Element propsElement = null;

    List children = contextElement.getChildren();
    for (int i = 0; i < children.size(); i++) {
      Element child = (Element) children.get(i);

      if (TRANS_POOL_ELEMENT.equals(child.getName())) {
        poolElement = child;
      } else if (DAO_FACTORY_ELEMENT.equals(child.getName())) {
        factoryElement = child;
      } else if (EXTRA_PROPS_ELEMENT.equals(child.getName())) {
        propsElement = child;
      }
    }

    // This guarantees the order of the configuration lifecycle
    if (propsElement != null) parseExtraPropertyElements(daoManager, propsElement);
    if (poolElement != null) parseTransactionPool(daoManager, poolElement);
    if (factoryElement != null) parseDaoFactory(daoManager, factoryElement);

    return daoManager;

  }

  private static DaoTransactionPool parseTransactionPool(DaoManager daoManager, Element transPoolElement)
      throws DaoException {
    DaoTransactionPool transactionPool = null;

    String implementation = getAttributeValue(transPoolElement, "implementation", true);

    try {
      transactionPool = (DaoTransactionPool) Class.forName(implementation).newInstance();
    } catch (Exception e) {
      throw new DaoException("Error while configuring DaoManager.  Cause: " + e.toString(), e);
    }

    Properties props = parsePropertyElements(transPoolElement);

    transactionPool.configure(props);

    if (transactionPool == null) {
      throw new DaoException("Error while configuring DaoManager.  Some unknown condition caused the DaoTransactionPool to be null after configuration.");
    }

    daoManager.setTransactionPool(transactionPool);

    return transactionPool;
  }

  private static void parseDaoFactory(DaoManager daoManager, Element transPoolElement)
      throws DaoException {

    List children = transPoolElement.getChildren();
    for (int i = 0; i < children.size(); i++) {
      Element child = (Element) children.get(i);

      if (DAO_ELEMENT.equals(child.getName())) {

        String name = getAttributeValue(child, "name", true);
        String implementation = getAttributeValue(child, "implementation", true);

        daoManager.addDaoClass(name, implementation);

      }
    }

  }

  private static void parseExtraPropertyElements(DaoManager daoManager, Element propsParentElement)
      throws DaoException {

    List children = propsParentElement.getChildren();
    for (int i = 0; i < children.size(); i++) {
      Element child = (Element) children.get(i);

      if (PROPERTY_ELEMENT.equals(child.getName())) {

        String name = null;
        String value = null;

        name = getAttributeValue(child, "name", true);

        value = getAttributeValue(child, "value", true);

        daoManager.setExtraProperty(name, value);
      }

    }

  }

  private static Properties parsePropertyElements(Element propsParentElement)
      throws DaoException {

    Properties props = new Properties();

    List children = propsParentElement.getChildren();
    for (int i = 0; i < children.size(); i++) {
      Element child = (Element) children.get(i);

      if (PROPERTY_ELEMENT.equals(child.getName())) {

        String name = null;
        String value = null;

        name = getAttributeValue(child, "name", true);

        value = getAttributeValue(child, "value", true);

        props.setProperty(name, value);
      }

    }

    return props;
  }

  private static String parsePropertyTokens(String string, Properties props) {
    final String OPEN = "${";
    final String CLOSE = "}";
    String newString = string;
    if (newString != null && props != null) {
      int start = newString.indexOf(OPEN);
      int end = newString.indexOf(CLOSE);

      while (start > -1 && end > start) {
        String prepend = newString.substring(0, start);
        String append = newString.substring(end + CLOSE.length());
        String propName = newString.substring(start + OPEN.length(), end);
        String propValue = props.getProperty(propName);
        if (propValue == null) {
          newString = prepend + append;
        } else {
          newString = prepend + propValue + append;
        }
        start = newString.indexOf(OPEN);
        end = newString.indexOf(CLOSE);
      }
    }
    return newString;
  }

}
