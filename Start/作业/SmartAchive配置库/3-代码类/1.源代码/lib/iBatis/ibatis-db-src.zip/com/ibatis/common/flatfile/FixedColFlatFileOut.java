package com.ibatis.common.flatfile;

import java.io.*;
import java.util.*;

/**
 *
 *
 * @author  clinton_begin
 *
 */

public class FixedColFlatFileOut extends Object implements FlatFileOut {

  private Writer writer = null;
  private ArrayList values = new ArrayList();
  private int[] coldef = null;
  private int linelength = 0;
  private String spaces = "                                                                                                    ";

  /** Creates new FixedColFlatFileOut */
  public FixedColFlatFileOut(String filename, int[] coldef) throws IOException {
    this.coldef = coldef;
    this.writer = new BufferedWriter(new FileWriter(filename));
    for (int i = 0; i < coldef.length; i++) {
      linelength += coldef[i];
    }
  }

  public int getColumnCount() throws IOException {
    return coldef.length;
  }

  public void setValueAt(int col, String value) throws IOException {
    while (col + 1 > values.size()) {
      values.add("");
    }
    values.set(col, value);
  }

  public void close() throws IOException {
    writer.flush();
    writer.close();
  }

  public void nextRecord() throws IOException {
    if (coldef.length != values.size()) {
      throw new IOException("Inconsistent number of columns in row.");
    }
    for (int i = 0; i < values.size(); i++) {
      if (values.get(i) == null) {
        writer.write(spaces.substring(0, coldef[i] - 1));
      } else {
        String val = (String) values.get(i);
        if (val.length() > coldef[i]) {
          val = val.substring(0, coldef[i] - 1);
        }
        writer.write(val);
        writer.write(spaces.substring(0, coldef[i] - val.length()));
      }
    }
    writer.write("\r\n");
  }
}
