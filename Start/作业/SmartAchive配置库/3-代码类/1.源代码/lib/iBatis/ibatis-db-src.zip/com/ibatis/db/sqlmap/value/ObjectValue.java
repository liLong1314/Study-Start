/**
 * User: Clinton Begin
 * Date: Feb 20, 2003
 * Time: 7:46:48 PM
 */
package com.ibatis.db.sqlmap.value;

public class ObjectValue extends BaseValue {

  public ObjectValue() {
  }

  public ObjectValue(Object value) {
    super(value);
  }

  public Object getValue() {
    return value;
  }

  public void setValue(Object value) {
    this.value = value;
  }

}
