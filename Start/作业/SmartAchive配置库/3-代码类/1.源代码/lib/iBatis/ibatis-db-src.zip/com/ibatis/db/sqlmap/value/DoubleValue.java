/**
 * User: Clinton Begin
 * Date: Feb 20, 2003
 * Time: 7:44:06 PM
 */
package com.ibatis.db.sqlmap.value;

public class DoubleValue extends BaseValue {

  public DoubleValue() {
  }

  public DoubleValue(Double value) {
    super(value);
  }

  public DoubleValue(double value) {
    super(new Double(value));
  }

  public Double getValue() {
    return (Double) value;
  }

  public void setValue(Double value) {
    this.value = value;
  }


}
