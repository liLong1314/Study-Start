/**
 * User: Clinton Begin
 * Date: May 31, 2003
 * Time: 3:09:58 PM
 */
package com.ibatis.db.dao.jdbc;

import com.ibatis.db.dao.*;

import java.util.*;
import java.sql.*;

import org.apache.commons.dbcp.*;

import javax.sql.*;

/**
 * A DaoTransactionPool implementation that uses Jakarta Commons DBCP
 * to manage a pool of JDBC Connection objects.
 *
 * @author  clinton_begin
 */
public class DbcpDaoTransactionPool implements DaoTransactionPool {

  private DataSource dataSource = null;

  public DaoTransaction getTransaction()
      throws DaoException {
    if (dataSource == null) {
      throw new DaoException("DataSource is null in JdbcDaoTransactionPool (check the data source configuration).");
    }
    try {
      Connection conn = dataSource.getConnection();
      if (conn.getAutoCommit()) {
        conn.setAutoCommit(false);
      }
      return new JdbcDaoTransaction(this, conn);
    } catch (SQLException e) {
      throw new DaoException("Error getting transaction.  Cause: " + e, e);
    }
  }

  public void releaseTransaction(DaoTransaction trans)
      throws DaoException {
    if (dataSource == null) {
      throw new DaoException("DataSource is null in JdbcDaoTransactionPool (check the data source configuration).");
    }
    try {
      ((JdbcDaoTransaction) trans).getConnection().close();
    } catch (SQLException e) {
      throw new DaoException("Error releasing transaction.  Cause: " + e, e);
    }
  }

  public void configure(Map properties)
      throws DaoException {
    try {
      String driver = (String) properties.get("JDBC.Driver");
      String url = (String) properties.get("JDBC.ConnectionURL");
      String username = (String) properties.get("JDBC.Username");
      String password = (String) properties.get("JDBC.Password");
      String validationQuery = (String) properties.get("Pool.ValidationQuery");
      String maxActive = (String) properties.get("Pool.MaximumActiveConnections");
      String maxIdle = (String) properties.get("Pool.MaximumIdleConnections");
      String maxWait = (String) properties.get("Pool.MaximumWait");
      String removeAbandoned = (String) properties.get("Pool.RemoveAbandoned");
      String removeAbandonedTimeout = (String) properties.get("Pool.RemoveAbandonedTimeout");
      String logAbandoned = (String) properties.get("Pool.LogAbandoned");

      BasicDataSource basicDataSource = new BasicDataSource();

      basicDataSource.setUrl(url);
      basicDataSource.setDriverClassName(driver);
      basicDataSource.setUsername(username);
      basicDataSource.setPassword(password);

      if (notEmpty(validationQuery)) {
        basicDataSource.setValidationQuery(validationQuery);
      }

      if (notEmpty(maxActive)) {
        basicDataSource.setMaxActive(Integer.parseInt(maxActive));
      }

      if (notEmpty(maxIdle)) {
        basicDataSource.setMaxIdle(Integer.parseInt(maxIdle));
      }

      if (notEmpty(maxWait)) {
        basicDataSource.setMaxWait(Integer.parseInt(maxWait));
      }

      if (notEmpty(removeAbandonedTimeout)) {
        basicDataSource.setRemoveAbandonedTimeout(Integer.parseInt(removeAbandonedTimeout));
      }

      if (notEmpty(removeAbandoned)) {
        basicDataSource.setRemoveAbandoned("true".equals(removeAbandoned));
      }

      if (notEmpty(logAbandoned)) {
        basicDataSource.setLogAbandoned("true".equals(logAbandoned));
      }

      dataSource = basicDataSource;

    } catch (Exception e) {
      throw new DaoException("Error initializing DbcpDataSourceFactory.  Cause: " + e, e);
    }
  }

  private boolean notEmpty(String s) {
    return s != null && s.length() > 0;
  }

}
