/**
 * User: Clinton Begin
 * Date: Mar 10, 2003
 * Time: 8:34:10 PM
 */
package com.ibatis.db.dao.jdbc;

import com.ibatis.db.dao.DaoTransaction;
import com.ibatis.db.dao.DaoException;
import com.ibatis.db.sqlmap.SqlMap;

import java.sql.*;

public class SqlMapDaoTransaction implements DaoTransaction {

  private SqlMap sqlMap;

  public SqlMapDaoTransaction(SqlMap sqlMap) {
    this.sqlMap = sqlMap;
  }

  public void commit() throws DaoException {
    try {
      sqlMap.commitTransaction();
    } catch (SQLException e) {
      throw new DaoException("Error committing transaction. Cause: " + e, e);
    }
  }

  public void rollback() throws DaoException {
    try {
      sqlMap.rollbackTransaction();
    } catch (SQLException e) {
      throw new DaoException("Error rolling back transaction. Cause: " + e, e);
    }
  }

  public void release() throws DaoException {
    // No implementation required.
  }

  public SqlMap getSqlMap() {
    return sqlMap;
  }

}
