package com.ibatis.db.sqlmap;

/**
 * @deprecated
 */
public class ObjectKey {

  /** Holds value of property key. */
  private Object key;

  /** Creates a new instance of ObjectKey */
  public ObjectKey() {
  }

  /** Getter for property key.
   * @return Value of property key.
   */
  public Object getKey() {
    return this.key;
  }

  /** Setter for property key.
   * @param key New value of property key.
   */
  public void setKey(Object key) {
    this.key = key;
  }

  public boolean equals(Object o) {
    if (this == o) return true;
    if (!(o instanceof ObjectKey)) return false;

    final ObjectKey objectKey = (ObjectKey) o;

    if (key != null ? !key.equals(objectKey.key) : objectKey.key != null) return false;

    return true;
  }

  public int hashCode() {
    return (key != null ? key.hashCode() : 0);
  }

}
