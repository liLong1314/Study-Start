/**
 * User: Clinton Begin
 * Date: Feb 20, 2003
 * Time: 7:14:49 PM
 */
package com.ibatis.db.sqlmap.value;

public abstract class BaseValue {

  protected Object value;

  public BaseValue() {
  }

  public BaseValue(Object value) {
    this.value = value;
  }

  /**
   * @deprecated
   */
  public Object getResult() {
    return value;
  }

  /**
   * @deprecated
   */
  public void setResult(Object value) {
    this.value = value;
  }

  /**
   * @deprecated
   */
  public Object getKey() {
    return value;
  }

  /**
   * @deprecated
   */
  public void setKey(Object value) {
    this.value = value;
  }

  public void setVal(Object value) {
    this.value = value;
  }

  public boolean equals(Object o) {
    if (this == o) return true;
    if (!(o instanceof BaseValue)) return false;

    final BaseValue baseResult = (BaseValue) o;

    if (value != null ? !value.equals(baseResult.value) : baseResult.value != null) return false;

    return true;
  }

  public int hashCode() {
    return (value != null ? value.hashCode() : 0);
  }

}
