/**
 * User: Clinton Begin
 * Date: Apr 11, 2003
 * Time: 10:56:06 PM
 */
package com.ibatis.db.sqlmap.typehandler;

import com.ibatis.db.sqlmap.value.*;
import com.ibatis.db.sqlmap.*;

import java.sql.*;

public class DoubleTypeHandler extends BaseTypeHandler {

  protected Object getValueByName(ResultMapping mapping, ResultSet rs) throws SQLException {
    return new Double(rs.getDouble(mapping.getColumnName()));
  }

  protected Object getValueByIndex(ResultMapping mapping, ResultSet rs) throws SQLException {
    return new Double(rs.getDouble(mapping.getColumnIndex().intValue()));
  }

  protected Object getNullValue(String nullValue) throws SQLException {
    return Double.valueOf(nullValue);
  }

  public Object instantiateValue() {
    return new DoubleValue();
  }

  public boolean isEqualToNullValue(String nullValue, Object realValue) {
    return Double.valueOf(nullValue).equals(realValue);
  }

  public boolean isSimpleType() {
    return true;
  }

  public void setParameter(ParameterMapping mapping, PreparedStatement ps, int index, Object value) throws SQLException {
    ps.setDouble(index, ((Double) value).doubleValue());
  }

}
