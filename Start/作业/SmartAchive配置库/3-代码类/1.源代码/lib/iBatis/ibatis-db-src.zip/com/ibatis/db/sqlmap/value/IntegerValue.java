package com.ibatis.db.sqlmap.value;

public class IntegerValue extends BaseValue {

  public IntegerValue() {
  }

  public IntegerValue(Integer value) {
    super(value);
  }

  public IntegerValue(int value) {
    super(new Integer(value));
  }

  public Integer getValue() {
    return (Integer) value;
  }

  public void setValue(Integer value) {
    this.value = value;
  }

}
