/**
 * User: Clinton Begin
 * Date: Feb 22, 2003
 * Time: 6:57:50 PM
 */
package com.ibatis.db.dao;

import org.xml.sax.*;

import java.io.*;

import com.ibatis.common.resources.*;

public class DaoJarEntityResolver implements EntityResolver {

  private static final String SYSTEM_ID_DAO = "http://www.ibatis.com/dtd/dao.dtd";
  private static final String DTD_PATH_DAO = "com/ibatis/db/dao/dao.dtd";

  public InputSource resolveEntity(String publicId, String systemId)
      throws SAXException {
    InputSource source;

    try {
      if (systemId.equals(SYSTEM_ID_DAO)) {
        InputStream in = Resources.getResourceAsStream(DTD_PATH_DAO);
        source = new InputSource(in);
      } else {
        source = null;
      }
    } catch (Exception e) {
      throw new SAXException(e.getMessage());
    }

    return source;
  }

}
