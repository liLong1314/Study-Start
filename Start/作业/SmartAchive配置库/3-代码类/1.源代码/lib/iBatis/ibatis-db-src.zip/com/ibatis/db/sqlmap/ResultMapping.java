/**
 * User: Clinton Begin
 * Date: May 10, 2003
 * Time: 10:29:47 AM
 */
package com.ibatis.db.sqlmap;

import com.ibatis.db.sqlmap.typehandler.*;

public class ResultMapping {

  private String propertyName;
  private String columnName;
  private Integer columnIndex;
  private String statementName;
  private String resourceName;
  private String type;
  private int typeInt = TypeRegistry.UNKNOWN_TYPE;
  private String nullValue;
  private boolean lazyLoad;
  private TypeHandler typeHandler;
  private Class propertyType;

  public ResultMapping() {
  }

  public String getPropertyName() {
    return propertyName;
  }

  public void setPropertyName(String propertyName) {
    this.propertyName = propertyName;
  }

  public Integer getColumnIndex() {
    return columnIndex;
  }

  public void setColumnIndex(Integer columnIndex) {
    this.columnIndex = columnIndex;
  }

  public String getColumnName() {
    return columnName;
  }

  public void setColumnName(String columnName) {
    this.columnName = columnName;
  }

  public String getStatementName() {
    return statementName;
  }

  public void setStatementName(String statementName) {
    this.statementName = statementName;
  }

  public int getJdbcType() {
    return typeInt;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
    this.typeInt = TypeRegistry.getType(type);
  }

  public String getNullValue() {
    return nullValue;
  }

  public void setNullValue(String nullValue) {
    this.nullValue = nullValue;
  }

  public boolean isLazyLoad() {
    return lazyLoad;
  }

  public void setLazyLoad(boolean lazyLoad) {
    this.lazyLoad = lazyLoad;
  }

  public String getResourceName() {
    return resourceName;
  }

  public void setResourceName(String resourceName) {
    this.resourceName = resourceName;
  }

  public TypeHandler getTypeHandler() {
    return typeHandler;
  }

  public void setTypeHandler(TypeHandler typeHandler) {
    this.typeHandler = typeHandler;
  }

  public Class getPropertyType() {
    return propertyType;
  }

  public void setPropertyType(Class propertyType) {
    this.propertyType = propertyType;
  }
}
