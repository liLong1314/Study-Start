package com.ibatis.common.flatfile;

import java.io.*;
import java.util.*;

/**
 *
 *
 * @author  clinton_begin
 *
 */

public class DelimitedFlatFileOut extends Object implements FlatFileOut {

  private static final int UNKNOWN_COLUM_COUNT = -1;

  private Writer writer = null;
  private ArrayList values = new ArrayList();
  private String delimiter = " ";
  private int colCount = UNKNOWN_COLUM_COUNT;

  /** Creates new DelimitedFlatFileOut */
  public DelimitedFlatFileOut(String filename, String delimiter)
      throws IOException {
    this.delimiter = delimiter;
    writer = new BufferedWriter(new FileWriter(filename));
  }

  public void nextRecord() throws IOException {
    if (colCount == UNKNOWN_COLUM_COUNT) {
      colCount = values.size();
    } else if (colCount != values.size()) {
      throw new IOException("Inconsistent number of columns in row.");
    }
    for (int i = 0; i < values.size(); i++) {
      if (values.get(i) == null) {
        writer.write("");
      } else {
        writer.write((String) values.get(i));
      }
      if (i + 1 < values.size()) {
        writer.write(delimiter);
      }
    }
    writer.write("\r\n");
  }

  public void close() throws IOException {
    writer.flush();
    writer.close();
  }

  public int getColumnCount() throws IOException {
    return colCount;
  }

  public void setValueAt(int col, String value) throws IOException {
    while (col + 1 > values.size()) {
      values.add("");
    }
    values.set(col, value);
  }

}