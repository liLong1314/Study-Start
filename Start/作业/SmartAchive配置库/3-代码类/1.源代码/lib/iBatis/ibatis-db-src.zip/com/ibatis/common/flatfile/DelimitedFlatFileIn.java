package com.ibatis.common.flatfile;

import java.io.*;
import java.util.*;

/**
 *
 *
 * @author  clinton_begin
 *
 */
public class DelimitedFlatFileIn extends Object implements FlatFileIn {

  private static final int UNKNOWN_COLUM_COUNT = -1;

  private LineNumberReader reader = null;
  private ArrayList values = new ArrayList();
  private String delimiter = " ";
  private int colCount = UNKNOWN_COLUM_COUNT;

  /** Creates new DelimitedFlatFileIn */
  public DelimitedFlatFileIn(String filename, String delimiter) throws IOException {
    this.delimiter = delimiter;
    reader = new LineNumberReader(new FileReader(filename));
  }

  public boolean nextRecord() throws IOException {
    values.clear();

    String line = reader.readLine();

    if (line == null) {
      return false;
    }

    String token = null;
    String lastToken = null;
    StringTokenizer parser = new StringTokenizer(line, delimiter, true);
    while (parser.hasMoreTokens()) {
      token = parser.nextToken();
      if (lastToken == null) {
        if (delimiter.equals(token)) {
          values.add("");
        } else {
          values.add(token);
        }
      } else {
        if (delimiter.equals(token) && delimiter.equals(lastToken)) {
          values.add("");
        } else if (!delimiter.equals(token)) {
          values.add(token);
        }
      }
      lastToken = token;
    }
    if (colCount == UNKNOWN_COLUM_COUNT) {
      colCount = values.size();
    } else if (colCount != values.size()) {
      throw new IOException("Inconsistent number of columns in row.");
    }
    return true;
  }

  public int getColumnCount() throws IOException {
    return colCount;
  }

  public String getValueAt(int col) throws IOException {
    return (String) values.get(col);
  }

  public void close() throws IOException {
    reader.close();
  }

}