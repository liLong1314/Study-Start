/**
 * User: Clinton Begin
 * Date: Apr 11, 2003
 * Time: 10:56:39 PM
 */
package com.ibatis.db.sqlmap.typehandler;

import com.ibatis.db.sqlmap.*;

import java.sql.*;
import java.io.*;

public class ByteArrayTypeHandler extends BaseTypeHandler {

  protected Object getValueByName(ResultMapping mapping, ResultSet rs) throws SQLException {
    Object value = null;
    try {
      InputStream in = rs.getBinaryStream(mapping.getColumnName());
      ByteArrayOutputStream baos = new ByteArrayOutputStream();
      int ch;
      while ((ch = in.read()) != -1) {
        baos.write(ch);
      }
      value = baos.toByteArray();
      in.close();
    } catch (Exception e) {
      value = rs.getBytes(mapping.getColumnName());
    }

    return value;
  }

  protected Object getValueByIndex(ResultMapping mapping, ResultSet rs) throws SQLException {
    Object value = null;
    try {
      InputStream in = rs.getBinaryStream(mapping.getColumnIndex().intValue());
      ByteArrayOutputStream baos = new ByteArrayOutputStream();
      int ch;
      while ((ch = in.read()) != -1) {
        baos.write(ch);
      }
      value = baos.toByteArray();
      in.close();
    } catch (Exception e) {
      value = rs.getBytes(mapping.getColumnIndex().intValue());
    }

    return value;
  }

  protected Object getNullValue(String nullValue) throws SQLException {
    return null;
  }

  public Object instantiateValue() {
    return new byte[0];
  }

  public boolean isEqualToNullValue(String nullValue, Object realValue) {
    return false;
  }

  public boolean isSimpleType() {
    return true;
  }

  public void setParameter(ParameterMapping mapping, PreparedStatement ps, int index, Object value) throws SQLException {
    //ps.setBytes(index, (byte[]) value);

    byte[] bytes = (byte[]) value;

    ByteArrayInputStream bais = new ByteArrayInputStream(bytes);

    ps.setBinaryStream(index, bais, bytes.length);
  }
}
