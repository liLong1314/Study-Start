/**
 * User: Clinton Begin
 * Date: May 10, 2003
 * Time: 12:01:39 PM
 */
package com.ibatis.db.sqlmap;

import com.ibatis.db.sqlmap.typehandler.*;

public class ParameterMapping {

  private String propertyName;
  private String type;
  private int typeInt = TypeRegistry.UNKNOWN_TYPE;
  private String nullValue;
  private String resourceName;
  private boolean isOutputParameter;
  private TypeHandler typeHandler;
  private Class propertyType;

  public String getPropertyName() {
    return propertyName;
  }

  public void setPropertyName(String propertyName) {
    this.propertyName = propertyName;
  }

  public int getJdbcType() {
    return typeInt;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
    this.typeInt = TypeRegistry.getType(type);
  }

  public String getNullValue() {
    return nullValue;
  }

  public void setNullValue(String nullValue) {
    this.nullValue = nullValue;
  }

  public String getResourceName() {
    return resourceName;
  }

  public void setResourceName(String resourceName) {
    this.resourceName = resourceName;
  }

  public boolean isOutputParameter() {
    return isOutputParameter;
  }

  public void setOutputParameter(boolean outputParameter) {
    isOutputParameter = outputParameter;
  }

  public TypeHandler getTypeHandler() {
    return typeHandler;
  }

  public void setTypeHandler(TypeHandler typeHandler) {
    this.typeHandler = typeHandler;
  }

  public Class getPropertyType() {
    return propertyType;
  }

  public void setPropertyType(Class propertyType) {
    this.propertyType = propertyType;
  }
}
