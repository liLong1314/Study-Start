/**
 * User: Clinton Begin
 * Date: Jan 21, 2003
 * Time: 8:13:48 PM
 */
package com.ibatis.db.sqlmap.datasource;

import com.ibatis.db.sqlmap.*;
import com.ibatis.db.jdbc.*;

import javax.sql.*;
import javax.naming.*;
import java.util.*;

public class JndiDataSourceFactory implements DataSourceFactory {

  private DataSource dataSource;

  public void initialize(Map properties) {
    try {
      InitialContext initCtx = new InitialContext();
      if (properties.containsKey("DBFullJndiContext")) {
        dataSource = (DataSource) initCtx.lookup((String) properties.get("DBFullJndiContext"));
      } else {
        Context ctx = (Context) initCtx.lookup((String) properties.get("DBInitialContext"));
        dataSource = (DataSource) ctx.lookup((String) properties.get("DBLookup"));
      }
    } catch (NamingException e) {
      throw new SqlMapException("There was an error configuring JndiDataSourceDaoTransactionPool. Cause: " + e, e);
    }
  }

  public DataSource getDataSource() {
    return dataSource;
  }

  public String[] getExpectedProperties() {
    return new String[]{"DBFullJndiContext"};
  }

}
