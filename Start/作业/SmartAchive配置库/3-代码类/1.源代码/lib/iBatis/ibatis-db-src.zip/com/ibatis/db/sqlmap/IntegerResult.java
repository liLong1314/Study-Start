package com.ibatis.db.sqlmap;

/**
 * @deprecated
 */
public class IntegerResult {

  private int result;

  public int getResult() {
    return result;
  }

  public void setResult(int result) {
    this.result = result;
  }

}
