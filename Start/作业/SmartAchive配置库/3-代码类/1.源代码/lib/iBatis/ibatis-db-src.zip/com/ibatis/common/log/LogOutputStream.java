package com.ibatis.common.log;

import java.io.*;

/**
 *
 *
 * @author  clinton_begin
 * @deprecated Use Jakarta commons logging
 */
public class LogOutputStream extends OutputStream {

  private static final int INITIAL_BUFFER_SIZE = 80;
  private static final char CHAR_CR = '\r';
  private static final char CHAR_LF = '\n';

  Log log = null;
  LogLevel level = null;
  StringBuffer buffer = null;


  public LogOutputStream(Log log, LogLevel level) {
    this.log = log;
    this.level = level;
    this.buffer = new StringBuffer(INITIAL_BUFFER_SIZE);
  }

  public void write(int b)
      throws IOException {
    buffer.append((char) b);
    if (((char) b) == CHAR_LF || ((char) b) == CHAR_CR) {
      if (buffer.length() > 1) {
        log.log(new LogEntry(level, buffer));
      }
      buffer = new StringBuffer(INITIAL_BUFFER_SIZE);
    }
  }

  public void flush() throws IOException {
    log.log(new LogEntry(LogLevel.LOG_STDOUT, buffer));
    buffer = new StringBuffer(INITIAL_BUFFER_SIZE);
    super.flush();
  }

}
