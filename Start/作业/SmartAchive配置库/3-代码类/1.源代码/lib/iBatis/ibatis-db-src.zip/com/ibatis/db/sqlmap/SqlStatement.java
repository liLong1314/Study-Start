/**
 * User: Clinton Begin
 * Date: Mar 5, 2003
 * Time: 10:22:26 PM
 */
package com.ibatis.db.sqlmap;

public class SqlStatement {

  public String sql;
  public boolean dynamicElements;
  public ParameterMap parameterMap;

  public SqlStatement() {
  }

  public String getSql() {
    return sql;
  }

  public void setSql(String sql) {
    this.sql = sql;
    this.dynamicElements = sql.indexOf("$") > -1;
  }

  public ParameterMap getParameterMap() {
    return parameterMap;
  }

  public void setParameterMap(ParameterMap parameterMap) {
    this.parameterMap = parameterMap;
  }

  public boolean isDynamicElements() {
    return dynamicElements;
  }

}
