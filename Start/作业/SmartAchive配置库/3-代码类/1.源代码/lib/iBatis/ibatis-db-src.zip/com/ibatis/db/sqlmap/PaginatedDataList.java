/**
 * User: Clinton Begin
 * Date: Jun 23, 2003
 * Time: 9:37:29 PM
 */
package com.ibatis.db.sqlmap;

import com.ibatis.common.util.*;
import com.ibatis.common.exception.*;

import javax.sql.*;
import java.util.*;
import java.sql.*;
import java.io.*;

public class PaginatedDataList
    implements PaginatedList {

  private MappedStatement mappedStatement;
  private Object parameterObject;

  private int pageSize;
  private int pageIndex;

  private List prevPageList;
  private List currentPageList;
  private List nextPageList;

  //added by bigtimber
  private int rowAmount;
  private int pageAmount;

  public PaginatedDataList(MappedStatement mappedStatement,
                           Object parameterObject, int pageSize) throws
      SQLException {
    this.mappedStatement = mappedStatement;
    this.parameterObject = parameterObject;
    this.pageSize = pageSize;
    this.pageIndex = 1;
    pageTo(1);
  }

  private void pageForward() {
    try {
      prevPageList = currentPageList;
      currentPageList = nextPageList;
      nextPageList = getList(pageIndex + 1, pageSize);
    }
    catch (SQLException e) {
      throw new NestedRuntimeException(
          "Unexpected error while repaginating paged list.  Cause: " + e, e);
    }
  }

  private void pageBack() {
    try {
      nextPageList = currentPageList;
      currentPageList = prevPageList;
      if (pageIndex > 1) {
        prevPageList = getList(pageIndex - 1, pageSize);
      }
      else {
        prevPageList = new ArrayList();
      }
    }
    catch (SQLException e) {
      throw new NestedRuntimeException(
          "Unexpected error while repaginating paged list.  Cause: " + e, e);
    }
  }

  private void safePageTo(int idx) {
    try {
      pageTo(idx);
    }
    catch (SQLException e) {
      throw new NestedRuntimeException(
          "Unexpected error while repaginating paged list.  Cause: " + e, e);
    }
  }

//  private void slowPageTo(int idx) throws SQLException {
//    index = idx;
//    if (idx == 0) {
//      prevPageList = new ArrayList();
//    } else {
//      prevPageList = getList(index - 1, pageSize);
//    }
//    currentPageList = getList(index, pageSize);
//    nextPageList = getList(index + 1, pageSize);
//  }

  public void pageTo(int idx) throws SQLException {
    pageIndex = idx;

    List list;

    if (idx < 2) {
      list = getList(idx, pageSize * 2);
    }
    else {
      list = getList(idx - 1, pageSize * 3);
    }

    if (list.size() < 1) {
      prevPageList = new ArrayList(0);
      currentPageList = new ArrayList(0);
      nextPageList = new ArrayList(0);
    }
    else {
      if (idx < 2) {
        prevPageList = new ArrayList(0);
        if (list.size() <= pageSize) {
          currentPageList = list.subList(0, list.size());
          nextPageList = new ArrayList(0);
        }
        else {
          currentPageList = list.subList(0, pageSize);
          nextPageList = list.subList(pageSize, list.size());
        }
      }
      else {
        if (list.size() <= pageSize) {
          prevPageList = list.subList(0, list.size());
          currentPageList = new ArrayList(0);
          nextPageList = new ArrayList(0);
        }
        else if (list.size() <= pageSize * 2) {
          prevPageList = list.subList(0, pageSize);
          currentPageList = list.subList(pageSize, list.size());
          nextPageList = new ArrayList(0);
        }
        else {
          prevPageList = list.subList(0, pageSize);
          currentPageList = list.subList(pageSize, pageSize * 2);
          nextPageList = list.subList(pageSize * 2, list.size());
        }
      }
    }

  }

  private List getList(int idx, int localPageSize) throws SQLException {
    boolean transaction = true;
    boolean autoCommit = !mappedStatement.getSqlMap().isUseGlobalTransaction();

    DataSource ds = mappedStatement.getSqlMap().getCurrentDataSource();

    Connection connection = mappedStatement.getSqlMap().
        getCurrentLocalConnection();
    if (connection == null) {
      transaction = false;
      connection = ds.getConnection();
      if (autoCommit != connection.getAutoCommit()) {
        connection.setAutoCommit(autoCommit);
      }
    }

    List list;
    try {
      list = mappedStatement.executeQueryForList(connection, parameterObject,
                                                 (idx - 1) * pageSize,
                                                 localPageSize);

      rowAmount = mappedStatement.getRowAmount();

      //�õ��ܹ�ҳ��
      if ((rowAmount > 0) && (rowAmount % pageSize == 0)) {
        pageAmount = rowAmount / pageSize;
      }
      else {
        pageAmount = rowAmount / pageSize + 1;
      }
    }
    finally {
      if (!transaction) {
        connection.close();
      }
    }

    return list;
  }

  public void firsPage() {
    gotoPage(1);
  }

  public boolean previousPage() {
    if (isPreviousPageAvailable()) {
      pageIndex--;
      pageBack();
      return true;
    }
    else {
      return false;
    }
  }

  public boolean nextPage() {
    if (isNextPageAvailable()) {
      pageIndex++;
      pageForward();
      return true;
    }
    else {
      return false;
    }
  }

  public void lastPage() {
    gotoPage(pageAmount);
  }

  public void gotoPage(int pageNumber) {
    if (pageNumber > pageAmount) {
      pageNumber = pageAmount;
    }
    if (pageNumber < 1) {
      pageNumber = 1;
    }
    safePageTo(pageNumber);
  }

  public int getPageSize() {
    return pageSize;
  }

  public boolean isFirstPage() {
    return pageIndex == 1;
  }

  public boolean isMiddlePage() {
    return! (isFirstPage() || isLastPage());
  }

  public boolean isLastPage() {
    return nextPageList.size() < 1;
  }

  public boolean isNextPageAvailable() {
    return nextPageList.size() > 0;
  }

  public boolean isPreviousPageAvailable() {
    return prevPageList.size() > 0;
  }

  public int size() {
    return currentPageList.size();
  }

  public boolean isEmpty() {
    return currentPageList.isEmpty();
  }

  public boolean contains(Object o) {
    return currentPageList.contains(o);
  }

  public Iterator iterator() {
    return currentPageList.iterator();
  }

  public Object[] toArray() {
    return currentPageList.toArray();
  }

  public Object[] toArray(Object a[]) {
    return currentPageList.toArray(a);
  }

  public boolean containsAll(Collection c) {
    return currentPageList.containsAll(c);
  }

  public Object get(int index) {
    return currentPageList.get(index);
  }

  public int indexOf(Object o) {
    return currentPageList.indexOf(o);
  }

  public int lastIndexOf(Object o) {
    return currentPageList.lastIndexOf(o);
  }

  public ListIterator listIterator() {
    return currentPageList.listIterator();
  }

  public ListIterator listIterator(int index) {
    return currentPageList.listIterator(index);
  }

  public List subList(int fromIndex, int toIndex) {
    return currentPageList.subList(fromIndex, toIndex);
  }

  public boolean add(Object o) {
    return currentPageList.add(o);
  }

  public boolean remove(Object o) {
    return currentPageList.remove(o);
  }

  public boolean addAll(Collection c) {
    return currentPageList.addAll(c);
  }

  public boolean addAll(int index, Collection c) {
    return currentPageList.addAll(index, c);
  }

  public boolean removeAll(Collection c) {
    return currentPageList.removeAll(c);
  }

  public boolean retainAll(Collection c) {
    return currentPageList.retainAll(c);
  }

  public void clear() {
    currentPageList.clear();
  }

  public Object set(int index, Object element) {
    return currentPageList.set(index, element);
  }

  public void add(int index, Object element) {
    currentPageList.add(index, element);
  }

  public Object remove(int index) {
    return currentPageList.remove(index);
  }

  public int getPageIndex() {
    return pageIndex;
  }

  /**
   * Getter for the row amount used for other object
   * @return row amount of this amount
   */
  public int getRowAmount() {
    return rowAmount;
  }

  /**
   * Getter for the page amount used for other object
   * @return page amount of this amount
   */
  public int getPageAmount() {
    return this.pageAmount;
  }

  public void refresh() {
    safePageTo(1);
  }

}