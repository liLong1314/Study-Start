package com.ibatis.db.sqlmap.typehandler;

import com.ibatis.db.sqlmap.ResultMapping;
import com.ibatis.db.sqlmap.ParameterMapping;
import com.ibatis.db.sqlmap.value.SqlDateValue;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;

/**
 * User: clinton_begin
 * Date: Jul 17, 2003
 * Time: 3:42:04 PM
 */
public class SqlDateTypeHandler extends BaseTypeHandler {

  protected Object getValueByName(ResultMapping mapping, ResultSet rs) throws SQLException {
    return rs.getDate(mapping.getColumnName());
  }

  protected Object getValueByIndex(ResultMapping mapping, ResultSet rs) throws SQLException {
    return rs.getDate(mapping.getColumnIndex().intValue());
  }

  protected Object getNullValue(String nullValue) throws SQLException {
    return java.sql.Date.valueOf(nullValue);
  }

  public Object instantiateValue() {
    return new SqlDateValue();
  }

  public boolean isEqualToNullValue(String nullValue, Object realValue) {
    return java.sql.Date.valueOf(nullValue).equals(realValue);
  }

  public boolean isSimpleType() {
    return true;
  }

  public void setParameter(ParameterMapping mapping, PreparedStatement ps, int index, Object value) throws SQLException {
    ps.setDate(index, (java.sql.Date)value);
  }

}
