/**
 * User: Clinton Begin
 * Date: Aug 23, 2003
 * Time: 7:38:47 AM
 */
package com.ibatis.common.beans;

import net.sf.cglib.*;

import java.util.*;
import java.lang.reflect.*;
import java.math.*;

/**
 * This class represents a cached set of class definition information that
 * allows for easy mapping between property names and getter/setter methods.
 */
public class ClassInfo {

  private static final String[] EMPTY_STRING_ARRAY = new String[0];
  private static final Set simpleTypeSet = new HashSet();
  private static final Map classInfoMap = Collections.synchronizedMap(new HashMap());

  private String className;
  private String[] readablePropertyNames = EMPTY_STRING_ARRAY;
  private String[] writeablePropertyNames = EMPTY_STRING_ARRAY;
  private HashMap setMethods = new HashMap();
  private HashMap getMethods = new HashMap();
  private HashMap setTypes = new HashMap();
  private HashMap getTypes = new HashMap();
  private HashMap metaClassMap = new HashMap();

  static {
    simpleTypeSet.add(String.class);
    simpleTypeSet.add(Byte.class);
    simpleTypeSet.add(Short.class);
    simpleTypeSet.add(Character.class);
    simpleTypeSet.add(Integer.class);
    simpleTypeSet.add(Long.class);
    simpleTypeSet.add(Float.class);
    simpleTypeSet.add(Double.class);
    simpleTypeSet.add(Boolean.class);
    simpleTypeSet.add(Date.class);
    simpleTypeSet.add(Class.class);
    simpleTypeSet.add(BigInteger.class);
    simpleTypeSet.add(Collection.class);
    simpleTypeSet.add(HashMap.class);
    simpleTypeSet.add(TreeMap.class);
    simpleTypeSet.add(ArrayList.class);
    simpleTypeSet.add(LinkedList.class);
    simpleTypeSet.add(HashSet.class);
    simpleTypeSet.add(TreeSet.class);
    simpleTypeSet.add(Vector.class);
    simpleTypeSet.add(Hashtable.class);
    simpleTypeSet.add(Enumeration.class);
  }

  private ClassInfo(Class clazz) {
    className = clazz.getName();
    addMethods(clazz);
    Class superClass = clazz.getSuperclass();
    while (superClass != null) {
      addMethods(superClass);
      superClass = superClass.getSuperclass();
    }
    readablePropertyNames = (String[]) getMethods.keySet().toArray(new String[getMethods.keySet().size()]);
    writeablePropertyNames = (String[]) setMethods.keySet().toArray(new String[setMethods.keySet().size()]);
    initializeMetaClasses(clazz);
  }

  private void addMethods(Class cls) {
    Method[] methods = cls.getMethods();
    for (int i = 0; i < methods.length; i++) {
      String name = methods[i].getName();
      if (name.indexOf("set") == 0 && name.length() > 3) {
        if (methods[i].getParameterTypes().length == 1) {
          name = name.substring(3, 4).toLowerCase() + name.substring(4);
          setMethods.put(name, methods[i]);
          setTypes.put(name, methods[i].getParameterTypes()[0]);
        }
      } else if (name.indexOf("get") == 0 && name.length() > 3) {
        if (methods[i].getParameterTypes().length == 0) {
          name = name.substring(3, 4).toLowerCase() + name.substring(4);
          getMethods.put(name, methods[i]);
          getTypes.put(name, methods[i].getReturnType());
        }
      } else if (name.indexOf("is") == 0 && name.length() > 2) {
        if (methods[i].getParameterTypes().length == 0) {
          name = name.substring(2, 3).toLowerCase() + name.substring(3);
          getMethods.put(name, methods[i]);
          getTypes.put(name, methods[i].getReturnType());
        }
      }
      name = null;
    }
  }

  private void initializeMetaClasses(Class cls) {
    if (StaticBeanProbe.isUseMetaClasses()) {
      String[] properties = getReadablePropertyNames();
      for (int i = 0; i < properties.length; i++) {
        if (hasWritableProperty(properties[i])) {
          try {
            MetaClass meta = MetaClass.getInstance(cls.getClassLoader(),
                cls,
                new String[]{getGetter(properties[i]).getName()},
                new String[]{getSetter(properties[i]).getName()},
                new Class[]{getGetterType(properties[i])});
            metaClassMap.put(properties[i], meta);
          } catch (Throwable t) {
            throw new BeansException("Error creating MetaClass for " + cls + ".  Cause: " + t.toString(), t);
          }
        }
      }
    }
  }

  public String getClassName() {
    return className;
  }

  public MetaClass getMetaClass(String propertyName) {
    return (MetaClass) metaClassMap.get(propertyName);
  }

  public Method getSetter(String propertyName) {
    Method method = (Method) setMethods.get(propertyName);
    if (method == null) {
      throw new BeansException("There is no WRITEABLE property named '" + propertyName + "' in class '" + className + "'");
    }
    return method;
  }

  public Method getGetter(String propertyName) {
    Method method = (Method) getMethods.get(propertyName);
    if (method == null) {
      throw new BeansException("There is no READABLE property named '" + propertyName + "' in class '" + className + "'");
    }
    return method;
  }

  public Class getSetterType(String propertyName) {
    Class clazz = (Class) setTypes.get(propertyName);
    if (clazz == null) {
      throw new BeansException("There is no WRITEABLE property named '" + propertyName + "' in class '" + className + "'");
    }
    return clazz;
  }

  public Class getGetterType(String propertyName) {
    Class clazz = (Class) getTypes.get(propertyName);
    if (clazz == null) {
      throw new BeansException("There is no READABLE property named '" + propertyName + "' in class '" + className + "'");
    }
    return clazz;
  }

  public String[] getReadablePropertyNames() {
    return readablePropertyNames;
  }

  public String[] getWriteablePropertyNames() {
    return writeablePropertyNames;
  }

  public boolean hasWritableProperty(String propertyName) {
    return setMethods.keySet().contains(propertyName);
  }

  public boolean hasReadableProperty(String propertyName) {
    return getMethods.keySet().contains(propertyName);
  }

  public static boolean isSimpleType(Class clazz) {
    if (simpleTypeSet.contains(clazz)) {
      return true;
    } else if (Collection.class.isAssignableFrom(clazz)) {
      return true;
    } else if (Map.class.isAssignableFrom(clazz)) {
      return true;
    } else if (List.class.isAssignableFrom(clazz)) {
      return true;
    } else if (Set.class.isAssignableFrom(clazz)) {
      return true;
    } else if (Iterator.class.isAssignableFrom(clazz)) {
      return true;
    } else {
      return false;
    }
  }

  /**
   * Gets an instance of ClassInfo for the specified class.
   * @param clazz The class for which to lookup the method cache.
   * @return The method cache for the class
   */
  public static ClassInfo getInstance(Class clazz) {
    synchronized (clazz) {
      ClassInfo cache = (ClassInfo) classInfoMap.get(clazz);
      if (cache == null) {
        cache = new ClassInfo(clazz);
        classInfoMap.put(clazz, cache);
      }
      return cache;
    }
  }

}



