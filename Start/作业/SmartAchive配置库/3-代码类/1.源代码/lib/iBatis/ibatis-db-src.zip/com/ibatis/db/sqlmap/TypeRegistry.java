/**
 * User: Clinton Begin
 * Date: May 22, 2003
 * Time: 4:57:37 PM
 */
package com.ibatis.db.sqlmap;

import java.sql.*;
import java.util.*;

public class TypeRegistry {

  public static final int UNKNOWN_TYPE = -99999;

  private static final Map typeMap = new HashMap();

  static {
    initializeTypes();
  }

  private static void setType(String name, int value) {
    typeMap.put(name, new Integer(value));
  }

  public static int getType(String name) {
    if (name == null) {
      return UNKNOWN_TYPE;
    } else {
      Integer i = ((Integer) typeMap.get(name));
      if (i != null) {
        return i.intValue();
      } else {
        return UNKNOWN_TYPE;
      }
    }
  }

  private static void initializeTypes() {
    setType("ARRAY", Types.ARRAY);
    setType("BIGINT", Types.BIGINT);
    setType("BINARY", Types.BINARY);
    setType("BIT", Types.BIT);
    setType("BLOB", Types.BLOB);
    setType("CHAR", Types.CHAR);
    setType("CLOB", Types.CLOB);
    setType("DATE", Types.DATE);
    setType("DECIMAL", Types.DECIMAL);
    setType("DISTINCT", Types.DISTINCT);
    setType("DOUBLE", Types.DOUBLE);
    setType("FLOAT", Types.FLOAT);
    setType("INTEGER", Types.INTEGER);
    setType("JAVA_OBJECT", Types.JAVA_OBJECT);
    setType("LONGVARBINARY", Types.LONGVARBINARY);
    setType("LONGVARCHAR", Types.LONGVARCHAR);
    setType("NULL", Types.NULL);
    setType("NUMERIC", Types.NUMERIC);
    setType("OTHER", Types.OTHER);
    setType("REAL", Types.REAL);
    setType("REF", Types.REF);
    setType("SMALLINT", Types.SMALLINT);
    setType("STRUCT", Types.STRUCT);
    setType("TIME", Types.TIME);
    setType("TIMESTAMP", Types.TIMESTAMP);
    setType("TINYINT", Types.TINYINT);
    setType("VARBINARY", Types.VARBINARY);
    setType("VARCHAR", Types.VARCHAR);
  }

}
