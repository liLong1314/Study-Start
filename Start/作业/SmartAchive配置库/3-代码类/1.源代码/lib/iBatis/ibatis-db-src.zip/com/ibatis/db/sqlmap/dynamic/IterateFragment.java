/**
 * User: Clinton Begin
 * Date: Mar 30, 2003
 * Time: 9:20:49 PM
 */
package com.ibatis.db.sqlmap.dynamic;

import com.ibatis.common.beans.StaticBeanProbe;
import com.ibatis.db.sqlmap.SqlMapException;

import java.util.*;

public class IterateFragment extends DynamicFragment {

  private String propertyName;
  private String open;
  private String close;
  private String conjunction;


  public String getPropertyName() {
    return propertyName;
  }

  public void setPropertyName(String propertyName) {
    this.propertyName = propertyName;
  }

  public String getOpen() {
    return open;
  }

  public void setOpen(String open) {
    this.open = open;
  }

  public String getClose() {
    return close;
  }

  public void setClose(String close) {
    this.close = close;
  }

  public String getConjunction() {
    return conjunction;
  }

  public void setConjunction(String conjunction) {
    this.conjunction = conjunction;
  }

  public String getSqlFragment(Object parameterObject) {

    Object value = StaticBeanProbe.getObject(parameterObject, propertyName);


    StringBuffer buffer = new StringBuffer();
    if (value != null) {
      if (value instanceof List) {

        List list = (List) value;
        for (int index = 0, n = list.size(); index < n; index++) {
          if (index == 0) {
            if (open != null) {
              buffer.append(open);
            }
          } else {
            if (conjunction != null) {
              buffer.append(conjunction);
            }
          }
          StringBuffer childBuffer = new StringBuffer();
          Iterator i = getChildFragments();
          while (i.hasNext()) {
            BaseFragment fragment = (BaseFragment) i.next();
            if (fragment instanceof ConditionalFragment) {
              ConditionalFragment.handleConditionalFragment((ConditionalFragment) fragment, parameterObject, childBuffer);
            } else if (fragment instanceof IterateFragment) {
              IterateFragment.handleIterateFragment((IterateFragment) fragment, parameterObject, childBuffer);
            } else {
              BaseFragment.handleFragment(fragment, parameterObject, childBuffer);
            }
          }

          buffer.append(parseArrays(childBuffer.toString(), index));

          if (index == list.size() - 1) {
            if (close != null) {
              buffer.append(close);
            }
          }
        }

      } else {
        throw new SqlMapException("The '" + propertyName + "' property of class " + parameterObject.getClass().getName() + " is not an instance of java.util.List.");
      }
    }
    return buffer.toString();
  }

  public static void handleIterateFragment(IterateFragment iterateFragment, Object parameterObject, StringBuffer buffer) {
    buffer.append(iterateFragment.getSqlFragment(parameterObject));
  }

  private String parseArrays(String buffer, int index) {
    StringBuffer parsedFragment = new StringBuffer();
    StringTokenizer propParser = new StringTokenizer(buffer, "#$", true);
    while (propParser.hasMoreTokens()) {
      String propToken = propParser.nextToken();
      parsedFragment.append(propToken);
      if ("#".equals(propToken) || "$".equals(propToken)) {
        if (propParser.hasMoreTokens()) {
          String prop = propParser.nextToken();
          if (prop.indexOf("[") > -1) {
            StringBuffer indexedProp = new StringBuffer(prop.substring(0, prop.indexOf("[") + 1));
            indexedProp.append(index);
            indexedProp.append(prop.substring(prop.indexOf("]")));
            parsedFragment.append(indexedProp);
            if (propParser.hasMoreTokens()) {
              parsedFragment.append(propParser.nextToken());
            }
          } else if ("#".equals(prop) || "$".equals(prop)) {
            parsedFragment.append(prop);
          } else {
            parsedFragment.append(prop);
            if (propParser.hasMoreTokens()) {
              parsedFragment.append(propParser.nextToken());
            }
          }
        }
      }
    }
    return parsedFragment.toString();
  }

}
