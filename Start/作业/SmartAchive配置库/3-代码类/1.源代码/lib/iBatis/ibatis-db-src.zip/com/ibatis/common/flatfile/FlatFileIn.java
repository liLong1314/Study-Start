package com.ibatis.common.flatfile;

import java.io.*;

/**
 *
 *
 * @author  clinton_begin
 *
 */

public interface FlatFileIn {

  public int getColumnCount() throws IOException;

  public boolean nextRecord() throws IOException;

  public String getValueAt(int col) throws IOException;

  public void close() throws IOException;


}

