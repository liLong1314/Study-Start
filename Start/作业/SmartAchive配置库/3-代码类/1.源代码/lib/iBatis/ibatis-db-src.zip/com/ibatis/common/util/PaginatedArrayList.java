/**
 * User: Clinton Begin
 * Date: Jun 23, 2003
 * Time: 7:48:42 PM
 */
package com.ibatis.common.util;

import java.util.*;
import java.io.*;

public class PaginatedArrayList
    implements PaginatedList {

  private static final ArrayList EMPTY_LIST = new ArrayList(0);

  private List list;
  private List page;
  private int pageSize;
  private int pageIndex;

  //added by bigtimber
  private int rowAmount;
  private int pageAmount;

  public PaginatedArrayList(int pageSize) {
    this.pageSize = pageSize;
    this.pageIndex = 1;
    this.list = new ArrayList();

    this.rowAmount = this.list.size();
    if (rowAmount % pageSize == 0) {
      pageAmount = rowAmount / pageSize;
    }
    else {
      pageAmount = rowAmount / pageSize + 1;
    }

    repaginate();
  }

  public PaginatedArrayList(int initialCapacity, int pageSize) {
    this.pageSize = pageSize;
    this.pageIndex = 1;
    this.list = new ArrayList(initialCapacity);

    this.rowAmount = this.list.size();
    if (rowAmount % pageSize == 0) {
      pageAmount = rowAmount / pageSize;
    }
    else {
      pageAmount = rowAmount / pageSize + 1;
    }
    repaginate();
  }

  public PaginatedArrayList(Collection c, int pageSize) {
    this.pageSize = pageSize;
    this.pageIndex = 1;
    this.list = new ArrayList(c);

    this.rowAmount = this.list.size();
    if (rowAmount % pageSize == 0) {
      pageAmount = rowAmount / pageSize;
    }
    else {
      pageAmount = rowAmount / pageSize + 1;
    }
    repaginate();
  }

  private void repaginate() {
    if (list.isEmpty()) {
      page = EMPTY_LIST;
    }
    else {
      int start = (pageIndex-1) * pageSize;
      int end = start + pageSize - 1;
      if (end >= list.size()) {
        end = list.size() - 1;
      }
      if (start >= list.size()) {
        pageIndex = 1;
        repaginate();
      }
      else if (start < 0) {
        pageIndex = list.size() / pageSize + 1;
        if (list.size() % pageSize == 0) {
          pageIndex--;
        }
        repaginate();
      }
      else {
        page = list.subList(start, end + 1);
      }
    }
  }

  /* List accessors (uses page) */

  public int size() {
    return page.size();
  }

  public boolean isEmpty() {
    return page.isEmpty();
  }

  public boolean contains(Object o) {
    return page.contains(o);
  }

  public Iterator iterator() {
    return page.iterator();
  }

  public Object[] toArray() {
    return page.toArray();
  }

  public Object[] toArray(Object a[]) {
    return page.toArray(a);
  }

  public boolean containsAll(Collection c) {
    return page.containsAll(c);
  }

  public Object get(int index) {
    return page.get(index);
  }

  public int indexOf(Object o) {
    return page.indexOf(o);
  }

  public int lastIndexOf(Object o) {
    return page.lastIndexOf(o);
  }

  public ListIterator listIterator() {
    return page.listIterator();
  }

  public ListIterator listIterator(int index) {
    return page.listIterator(index);
  }

  public List subList(int fromIndex, int toIndex) {
    return page.subList(fromIndex, toIndex);
  }

  /* List mutators (uses master list) */

  public boolean add(Object o) {
    boolean b = list.add(o);
    repaginate();
    return b;
  }

  public boolean remove(Object o) {
    boolean b = list.remove(o);
    repaginate();
    return b;
  }

  public boolean addAll(Collection c) {
    boolean b = list.addAll(c);
    repaginate();
    return b;
  }

  public boolean addAll(int index, Collection c) {
    boolean b = list.addAll(index, c);
    repaginate();
    return b;
  }

  public boolean removeAll(Collection c) {
    boolean b = list.removeAll(c);
    repaginate();
    return b;
  }

  public boolean retainAll(Collection c) {
    boolean b = list.retainAll(c);
    repaginate();
    return b;
  }

  public void clear() {
    list.clear();
    repaginate();
  }

  public Object set(int index, Object element) {
    Object o = list.set(index, element);
    repaginate();
    return o;
  }

  public void add(int index, Object element) {
    list.add(index, element);
    repaginate();
  }

  public Object remove(int index) {
    Object o = list.remove(index);
    repaginate();
    return o;
  }

  /* Paginated List methods */

  public int getPageSize() {
    return pageSize;
  }

  public boolean isFirstPage() {
    return pageIndex == 1;
  }

  public boolean isMiddlePage() {
    return! (isFirstPage() || isLastPage());
  }

  public boolean isLastPage() {
    return list.size() - ( pageIndex * pageSize) < 1;
  }

  public boolean isNextPageAvailable() {
    return!isLastPage();
  }

  public boolean isPreviousPageAvailable() {
    return!isFirstPage();
  }

  public void firsPage() {
    gotoPage(pageAmount);
  }

  public boolean previousPage() {
    if (isPreviousPageAvailable()) {
      pageIndex--;
      repaginate();
      return true;
    }
    else {
      return false;
    }
  }

  public void lastPage() {
    gotoPage(pageAmount-1);
  }

  public boolean nextPage() {
    if (isNextPageAvailable()) {
      pageIndex++;
      repaginate();
      return true;
    }
    else {
      return false;
    }
  }

  public void gotoPage(int pageNumber) {
    pageIndex = pageNumber;
    repaginate();
  }

  public int getPageIndex() {
    return pageIndex;
  }

  public int getRowAmount() {
    return rowAmount;
  }

  public int getPageAmount() {
    return pageAmount;
  }

  public void refresh() {
    gotoPage(1);
  }

}