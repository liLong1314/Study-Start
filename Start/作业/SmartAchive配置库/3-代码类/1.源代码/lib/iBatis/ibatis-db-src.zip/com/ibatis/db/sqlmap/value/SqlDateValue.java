package com.ibatis.db.sqlmap.value;

/**
 * User: clinton_begin
 * Date: Jul 17, 2003
 * Time: 3:45:11 PM
 */
public class SqlDateValue extends BaseValue {

  public SqlDateValue() {
  }

  public SqlDateValue(java.sql.Date value) {
    super(value);
  }

  public java.sql.Date getValue() {
    return (java.sql.Date) value;
  }

  public void setValue(java.sql.Date value) {
    this.value = value;
  }

}
