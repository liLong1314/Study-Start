/**
 * User: Clinton Begin
 * Date: Aug 23, 2003
 * Time: 7:28:12 AM
 */
package com.ibatis.common.beans;

import java.lang.reflect.*;
import java.util.*;

public class PropertyAccessPlan {

  private static final Object[] NO_ARGUMENTS = new Object[0];

  private Class type;
  private ClassInfo info;

  private Method getter;
  private Method setter;

  private int arraySize;

  private PlanItem[] setters;
  private PlanItem[] getters;

  private PropertyAccessPlan[] memberPlans;

  public PropertyAccessPlan(Class clazz, String[]propertyNames) {
    this.type = clazz;
    this.getter = null;
    this.info = ClassInfo.getInstance(clazz);
    this.arraySize = propertyNames.length;
    Map propertyMap = new TreeMap();
    for (int i = 0; i < propertyNames.length; i++) {
      initAddPropertyNameToMap(propertyMap, propertyNames[i], i);
    }
    initProcessPropertyMap(propertyMap);
  }

  private PropertyAccessPlan(Class clazz, Method getter, Method setter, Map propertyMap) {
    this.type = clazz;
    this.getter = getter;
    this.setter = setter;
    this.info = ClassInfo.getInstance(clazz);
    this.arraySize = -1;
    initProcessPropertyMap(propertyMap);
  }

  private void initProcessPropertyMap(Map propertyMap) {
    List setterList = new ArrayList();
    List getterList = new ArrayList();
    List memberList = new ArrayList();

    Iterator propIterator = propertyMap.keySet().iterator();
    while (propIterator.hasNext()) {
      String propName = (String)propIterator.next();
      if (propertyMap.get(propName) instanceof Map) {
        Class memberType = info.getGetterType(propName);
        Method memberGetter = info.getGetter(propName);
        Method memberSetter = info.getSetter(propName);
        memberList.add(new PropertyAccessPlan(memberType, memberGetter, memberSetter, (Map)propertyMap.get(propName)));
      } else {
        if (info.hasWritableProperty(propName)){
          setterList.add(propertyMap.get(propName));
        }
        if (info.hasReadableProperty(propName)){
          getterList.add(propertyMap.get(propName));
        }
      }
    }

    setters = new PlanItem[setterList.size()];
    for (int i = 0, n=setterList.size(); i < n; i++) {
      PlanItem planItem = (PlanItem)setterList.get(i);
      planItem = planItem.copy();
      planItem.type = info.getSetterType(planItem.propertyName);
      planItem.method = info.getSetter(planItem.propertyName);
      planItem.methodName = planItem.method.getName();
      setters[i] = planItem;
    }

    getters = new PlanItem[getterList.size()];
    for (int i = 0, n=getterList.size(); i < n; i++) {
      PlanItem planItem = (PlanItem)setterList.get(i);
      planItem = planItem.copy();
      planItem.type = info.getGetterType(planItem.propertyName);
      planItem.method = info.getGetter(planItem.propertyName);
      planItem.methodName = planItem.method.getName();
      getters[i] = planItem;
    }

    memberPlans = new PropertyAccessPlan[memberList.size()];
    for (int i = 0, n=memberList.size(); i < n; i++) {
      memberPlans[i] = (PropertyAccessPlan) memberList.get(i);
    }
  }

  private void initAddPropertyNameToMap (Map map, String propertyName, int index) {
    PlanItem item = new PlanItem();
    item.fullPropertyName = propertyName;
    item.propertyIndex = index;
    Map localMap = map;
    String[] names = initTokenizePropertyName (propertyName);
    for (int i=0; i < names.length; i++) {
      if (i == names.length-1) {
        item.propertyName = names[i];
        localMap.put(names[i], item);
      } else {
        Map newMap = (Map)localMap.get(names[i]);
        if (newMap == null) {
          newMap = new TreeMap();
          localMap.put(names[i],newMap);
        }
        localMap = newMap;
      }
    }
  }

  private String[] initTokenizePropertyName (String propName) {
    StringTokenizer parser = new StringTokenizer(propName,".",false);
    String[] names = new String[parser.countTokens()];
    for (int i = 0; i < names.length && parser.hasMoreTokens(); i++) {
      names[i] = parser.nextToken();
    }
    return names;
  }

  public void setProperties (Object object, Object[] values) {
    try {
      for (int i=0; i < setters.length; i++) {
        Object val = values[setters[i].propertyIndex];
        setters[i].method.invoke(object, new Object[]{val});
      }
      for (int i=0; i < memberPlans.length; i++) {
        Object child = memberPlans[i].getter.invoke(object,NO_ARGUMENTS);
        if (child == null) {
          child = memberPlans[i].type.newInstance();
          memberPlans[i].setter.invoke(object, new Object[] {child});
        }
        memberPlans[i].setProperties(child, values);
      }
    } catch (Exception e) {
      e.printStackTrace();
      throw new BeansException ("Error getting property... Cause: " + e, e);
    }
  }

  public Object[] getProperties (Object object) {
    Object[] values = new Object[arraySize];
    getProperties(this, object, values);
    return values;
  }

  private void getProperties (PropertyAccessPlan plan, Object object, Object[] values) {
    try {
      for (int i=0; i < plan.getters.length; i++) {
        values[plan.getters[i].propertyIndex] = plan.getters[i].method.invoke(object, NO_ARGUMENTS);
      }
      for (int i=0; i < plan.memberPlans.length; i++) {
        Object child = memberPlans[i].getter.invoke(object,NO_ARGUMENTS);
        if (child != null) {
          plan.memberPlans[i].getProperties(plan.memberPlans[i], child, values);
        }
      }
    } catch (Exception e) {
      throw new BeansException ("Error getting property... Cause: " + e, e);
    }
  }

  private static class PlanItem {
    String fullPropertyName;
    String propertyName;
    int propertyIndex;
    Class type;
    Method method;
    String methodName;
    public PlanItem copy() {
      PlanItem item = new PlanItem();
      item.fullPropertyName = fullPropertyName;
      item.propertyName = propertyName;
      item.propertyIndex = propertyIndex;
      item.type = type;
      item.method = method;
      item.methodName = methodName;
      return item;
    }
  }

}
