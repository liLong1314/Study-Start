/**
 * Created by IntelliJ IDEA.
 * User: Clinton Begin
 * Date: Nov 10, 2002
 * Time: 12:54:49 AM
 * To change this template use Options | File Templates.
 */
package com.ibatis.db.dao.jdbc;

import com.ibatis.db.dao.*;

import javax.naming.*;
import javax.sql.*;
import java.sql.*;
import java.util.*;

public class JndiDataSourceDaoTransactionPool implements DaoTransactionPool {

  private DataSource dataSource;

  public void configure(Map properties)
      throws DaoException {
    try {
      InitialContext initCtx = new InitialContext();
      if (properties.containsKey("DBFullJndiContext")) {
        dataSource = (DataSource) initCtx.lookup((String) properties.get("DBFullJndiContext"));
      } else {
        Context ctx = (Context) initCtx.lookup((String) properties.get("DBInitialContext"));
        dataSource = (DataSource) ctx.lookup((String) properties.get("DBLookup"));
      }
    } catch (NamingException e) {
      throw new DaoException("There was an error configuring JndiDataSourceDaoTransactionPool. Cause:" + e, e);
    }
  }

  public void releaseTransaction(DaoTransaction trans)
      throws DaoException {
    if (dataSource == null) {
      throw new DaoException("DataSource is null in JdbcDaoTransactionPool (check the data source configuration).");
    }
    try {
      ((JdbcDaoTransaction) trans).getConnection().close();
    } catch (SQLException e) {
      throw new DaoException("Error releasing DAO transaction.  Cause: " + e, e);
    }
  }

  public DaoTransaction getTransaction()
      throws DaoException {
    if (dataSource == null) {
      throw new DaoException("DataSource is null in JdbcDaoTransactionPool (check the data source configuration).");
    }
    try {
      Connection conn = dataSource.getConnection();
      if (conn.getAutoCommit()) {
        conn.setAutoCommit(false);
      }
      return new JdbcDaoTransaction(this, conn);
    } catch (SQLException e) {
      throw new DaoException("Error getting DAO transaction.  Cause: " + e, e);
    }
  }
}
