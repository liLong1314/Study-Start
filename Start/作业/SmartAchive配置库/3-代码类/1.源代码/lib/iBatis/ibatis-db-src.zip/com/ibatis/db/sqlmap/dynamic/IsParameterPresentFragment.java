/**
 * User: Clinton Begin
 * Date: Mar 26, 2003
 * Time: 9:02:26 PM
 */
package com.ibatis.db.sqlmap.dynamic;

public class IsParameterPresentFragment extends ConditionalFragment {

  public boolean isCondition(Object parameterObject) {
    return parameterObject != null;
  }

}
