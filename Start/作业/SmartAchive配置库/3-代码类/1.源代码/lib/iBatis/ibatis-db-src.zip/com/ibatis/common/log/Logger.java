package com.ibatis.common.log;

import com.ibatis.common.resources.*;

import java.io.*;
import java.util.*;

/**
 *
 *
 * @author  clinton_begin
 * @deprecated Use Jakarta commons logging
 *
 */
public class Logger extends Object implements Log {

  private static final Logger instance;
  private static final List logs = new ArrayList();
  private static final List queue = new ArrayList();
  private static LogLevel logLevel;

  private Object channel;

  static {
    instance = new Logger();
    loadLogConfig();
    if (logs.size() < 1) {
      addLog(new SystemOutLog());
    }
    setLogLevel(LogLevel.LOG_DEBUG);
    new ProcessQueueThread().start();
  }

  /** Creates new Logger */
  private Logger() {
    channel = LogEntry.DEFAULT_CHANNEL;
  }

  private Logger(Object channel) {
    this.channel = channel;
  }


  public static Logger getInstance() {
    return instance;
  }

  public static Logger getInstance(Object channel) {
    return new Logger(channel);
  }

  private static void loadLogConfig() {
    Properties props = new Properties();
    try {
      props.load(Resources.getResourceAsStream("properties/Logger.properties"));
    } catch (IOException e) {
      // Ignore
    }
    Iterator keys = props.keySet().iterator();
    while (keys.hasNext()) {
      String logname = (String) keys.next();
      String classname = (String) props.get(logname);
      try {
        addLog((Log) Class.forName(classname).newInstance());
      } catch (Exception e) {
        System.out.println("Error loading Log (" + logname + "): " + e.toString());
      }
    }
  }

  public static void addLog(Log log) {
    synchronized (logs) {
      logs.add(log);
    }
  }

  /**
   * @ deprecated
   * @return System.out
   */
  public static PrintStream getStdOut() {
    return System.out;
  }

  public static LogLevel getLogLevel() {
    return logLevel;
  }

  public static void setLogLevel(LogLevel level) {
    logLevel = level;
  }

  public void log(LogEntry entry) {
    if (entry.getLogLevel().getLevel() <= this.logLevel.getLevel()) {
      synchronized (queue) {
        queue.add(entry);
        queue.notify();
      }
    }
  }

  public void log(LogLevel level, Object o) {
    log(new LogEntry(level, channel, o));
  }

  public void debug(Object msg) {
    log(LogLevel.LOG_DEBUG, msg);
  }

  public void stdout(Object msg) {
    log(LogLevel.LOG_STDOUT, msg);
  }

  public void info(Object msg) {
    log(LogLevel.LOG_INFO, msg);
  }

  public void warn(Object msg) {
    log(LogLevel.LOG_WARN, msg);
  }

  public void error(Object msg) {
    log(LogLevel.LOG_ERROR, msg);
  }

  public void critical(Object msg) {
    log(LogLevel.LOG_CRITICAL, msg);
  }

  /**
   * Forces all log entries in the queue to be immediately processed.
   */
  public void flush() {
    synchronized (queue) {
      while (queue.size() > 0) {
        LogEntry logEntry = (LogEntry) queue.remove(0);
        synchronized (logs) {
          for (int i = 0; i < logs.size(); i++) {
            ((Log) logs.get(i)).log(logEntry);
          }
        }
      }
      synchronized (logs) {
        for (int i = 0; i < logs.size(); i++) {
          Log log = (Log) logs.get(i);
          log.flush();
        }
      }
    }
  }

  /**
   * ProcessQueueThread processes regularly monitors the log queue and processes log entries
   * as they are placed on the queue.
   * <P>
   * Pattern Implemented: Guarded Suspension
   */
  private static class ProcessQueueThread extends Thread {

    public ProcessQueueThread() {
      setDaemon(true);
    }

    public void run() {
      while (true) {
        synchronized (queue) {
          while (queue.size() > 0) {
            LogEntry logEntry = (LogEntry) queue.remove(0);
            synchronized (logs) {
              for (int i = 0; i < logs.size(); i++) {
                ((Log) logs.get(i)).log(logEntry);
              }
            }
          }
          try {
            queue.wait();
          } catch (InterruptedException e) {
          }
        }
      }
    }
  }

}
